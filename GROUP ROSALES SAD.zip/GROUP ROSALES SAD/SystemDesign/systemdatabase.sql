-- phpMyAdmin SQL Dump
-- version 5.1.0
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Feb 18, 2022 at 01:59 PM
-- Server version: 10.4.18-MariaDB
-- PHP Version: 8.0.3

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `systemdatabase`
--

-- --------------------------------------------------------

--
-- Table structure for table `admin`
--

CREATE TABLE `admin` (
  `id` int(11) NOT NULL,
  `username` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `admin`
--

INSERT INTO `admin` (`id`, `username`, `password`) VALUES
(1, 'adminako', '1234');

-- --------------------------------------------------------

--
-- Table structure for table `floor`
--

CREATE TABLE `floor` (
  `floorid` int(11) NOT NULL,
  `floorname` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `floor`
--

INSERT INTO `floor` (`floorid`, `floorname`) VALUES
(7, 'Fifth Floor'),
(1, 'First Floor'),
(6, 'Fourth Floor'),
(2, 'Second Floor'),
(5, 'Third Floor');

-- --------------------------------------------------------

--
-- Table structure for table `room`
--

CREATE TABLE `room` (
  `roomid` int(11) NOT NULL,
  `roomname` varchar(255) NOT NULL,
  `abbreviation` varchar(255) NOT NULL,
  `roomcategoryid` int(11) NOT NULL DEFAULT 0,
  `uniqure_room` varchar(255) NOT NULL,
  `floorid` int(11) NOT NULL DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `room`
--

INSERT INTO `room` (`roomid`, `roomname`, `abbreviation`, `roomcategoryid`, `uniqure_room`, `floorid`) VALUES
(1, 'President Office', 'President / VP', 2, 'ROOM 1', 1),
(2, 'Accounting Office', 'Accounting', 2, 'ROOM 2', 1),
(3, 'Registrar Office', 'Registrar', 2, 'ROOM 3', 1),
(4, 'Cashier Office', 'Cashier', 2, 'ROOM 4', 1),
(5, 'AFA Building', 'AFAB', 4, 'ROOM 5', 1),
(6, 'HighSchool Library', 'HS Library', 2, 'ROOM 6', 1),
(10, 'SKULBOX (Canteen)', '(SB)Canteen', 6, 'ROOM 7', 1),
(11, 'CR1(MALE)', 'CR(MALE)', 5, 'ROOM 8', 1),
(12, 'CR2(FEMALE)', 'CR(FEMALE)', 5, 'ROOM 9', 1),
(13, 'SkulBox School Supplies', 'School Supplies', 8, 'ROOM 10', 1),
(14, 'Cafeteria', 'Cafeteria', 6, 'ROOM 11', 1),
(15, 'Canteen', 'Canteen', 6, 'ROOM 12', 1),
(17, 'TLE/FOOD Laboratory', 'TLE/FOOD ', 4, 'ROOM 13', 1),
(18, 'HS Library Extension', 'Library Extension', 3, 'ROOM 14', 1),
(19, 'Registrar Stockroom', 'RS', 4, 'ROOM 15', 1),
(20, 'Custodian Stockroom', 'CS', 4, 'ROOM 16', 1),
(21, 'Guidance Office', 'GUID', 2, 'ROOM 17', 1),
(22, 'Guidance Room', 'GUID Room', 4, 'ROOM 18', 1),
(23, 'Clinic', 'Clinic', 9, 'ROOM 19', 1),
(24, 'Travels and Tours Office', 'TATO', 2, 'ROOM 20', 1),
(25, 'SeniorHigh', 'SH', 4, 'ROOM 21', 1);

-- --------------------------------------------------------

--
-- Table structure for table `roomcategory`
--

CREATE TABLE `roomcategory` (
  `roomcategoryid` int(11) NOT NULL,
  `roomcategoryname` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `roomcategory`
--

INSERT INTO `roomcategory` (`roomcategoryid`, `roomcategoryname`) VALUES
(5, 'Comfort Room'),
(9, 'Infirmary'),
(3, 'Library'),
(10, 'NEW CATEGORY'),
(2, 'Office'),
(6, 'Refectory'),
(4, 'Room'),
(8, 'Store'),
(7, 'Vacant');

-- --------------------------------------------------------

--
-- Table structure for table `staff`
--

CREATE TABLE `staff` (
  `staffid` int(11) NOT NULL,
  `stafffn` varchar(255) NOT NULL,
  `staffln` varchar(255) NOT NULL,
  `staffmn` varchar(255) NOT NULL,
  `staffworkid` int(11) DEFAULT NULL,
  `roomid` int(11) DEFAULT NULL,
  `floorid` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `staff`
--

INSERT INTO `staff` (`staffid`, `stafffn`, `staffln`, `staffmn`, `staffworkid`, `roomid`, `floorid`) VALUES
(6, 'Jack Lester', 'Lepiten', 'R', 6, 3, 1),
(8, 'Junabe', 'Barco', 'V.', 10, 3, 1),
(9, 'Jarah', 'Banzon', 'H.', 10, 3, 1),
(10, 'Erson', 'Pugoy', 'N/A', 10, 3, 1),
(11, 'Alliah Faith', 'Dignos', 'N\\A', 11, 3, 1),
(12, 'Marie Jane', 'Cairo', 'N\\A', 12, 3, 1),
(13, 'Jessa', 'Piañar', 'C', 13, 2, 1),
(14, 'Cherry', 'Nadela', 'D.', 14, 2, 1),
(15, 'Raymund', 'Cometa', 'A.', 15, 2, 1),
(16, 'Melodina', 'Fernandez', 'P.', 16, 2, 1),
(17, 'Dolores', 'Jusay', 'S.', 17, 2, 1),
(18, 'Jaclyn', 'Sipalay', 'B.', 18, 2, 1),
(19, 'Virginia', 'Siclot', 'L.', 19, 4, 1),
(20, 'Elvie', 'Monsales', 'L.', 20, 2, 1),
(21, 'Michelle', 'Suson', 'P.', 21, 2, 1),
(22, 'Jesseca', 'Catadman', 'C.', 22, 2, 1),
(23, 'Emely', 'Sarsalejo', 'B.', 23, 4, 1),
(24, 'Martha', 'Ylanan', 'H.', 24, 5, 1),
(25, 'Danilo', 'Velasco', 'L.', 25, 5, 1),
(26, 'Lester', 'Perino', 'N/A', 9, 5, 1),
(27, 'Miraflor', 'Enclonar', 'N\\A', 26, 21, 1),
(28, 'Hedelyn', 'Balbido', 'N\\A', 8, 21, 1),
(29, 'John Kenneth', 'Erin', 'N\\A', 8, 21, 1),
(30, 'Lelith', 'Lepiten', 'N\\A', 27, 23, 1),
(31, 'MyGirl Yvone', 'Pequirda', 'N\\A', 8, 23, 1),
(32, 'Michael', 'Balabat', 'N\\A', 8, 23, 1),
(33, 'Lizeil', 'Sumanting', 'N\\A', 8, 23, 1),
(34, 'Victor Elliot', 'Lepiten', 'S.', 7, 1, 1),
(35, 'Christina', 'Lepiten', 'R.', 28, 1, 1);

-- --------------------------------------------------------

--
-- Table structure for table `staffworkposition`
--

CREATE TABLE `staffworkposition` (
  `staffworkid` int(11) NOT NULL,
  `staffworkpositionname` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `staffworkposition`
--

INSERT INTO `staffworkposition` (`staffworkid`, `staffworkpositionname`) VALUES
(14, 'ACCOUNTING HEAD'),
(23, 'ASSISTANT CASHIER'),
(18, 'BOOKEEPER'),
(20, 'BSED ASSESMENT OFFICER'),
(25, 'CES COORDINATOR'),
(21, 'COLLEGE ASSESMENT OFFICER'),
(22, 'FINANCE STAFF'),
(26, 'GUIDANCE COORDINATOR'),
(19, 'HEAD CASHIER'),
(13, 'INTERNAL AUDITOR'),
(24, 'NSTP COORDINATOR'),
(10, 'OFFICE STAFF'),
(17, 'PAYROLL AND AMOUNT OFFICE'),
(7, 'PRESIDENT'),
(6, 'REGISTRAR'),
(27, 'SCHOOL NURSE'),
(16, 'SENIOR ACCOUNTING STAFF'),
(11, 'STUDENT FILE KEEPER'),
(15, 'SYSTEM AND METHOD OFFICE'),
(12, 'TIME KEEPER'),
(28, 'VICE-PRESIDENT'),
(8, 'WORKING ASSISTANT'),
(9, 'WORKING STUDENT');

-- --------------------------------------------------------

--
-- Table structure for table `transaction`
--

CREATE TABLE `transaction` (
  `transactionid` int(11) NOT NULL,
  `transactiontitle` varchar(255) NOT NULL,
  `roomid` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `transaction`
--

INSERT INTO `transaction` (`transactionid`, `transactiontitle`, `roomid`) VALUES
(1, 'Enrollment', 3),
(2, 'GWA', 3),
(3, 'Unifast Signature', 2),
(4, 'Cobsap Signature', 2),
(5, 'Tuition', 2),
(6, 'Admision Slip', 2),
(9, 'Prospectus', 3);

-- --------------------------------------------------------

--
-- Table structure for table `transactionprocedure`
--

CREATE TABLE `transactionprocedure` (
  `tranprocedureid` int(11) NOT NULL,
  `transprocedure` varchar(255) NOT NULL,
  `transactionid` int(11) NOT NULL,
  `sequence` int(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `transactionprocedure`
--

INSERT INTO `transactionprocedure` (`tranprocedureid`, `transprocedure`, `transactionid`, `sequence`) VALUES
(20, 'YOU CAN GO TO CANTEEN BESIDE THE MAINGATE OR AT THE SKULBOX CANTEEN', 7, 1),
(89, 'Go to Accounting Office', 3, 1),
(90, 'Ask a working student to have a stamp of UNIFAST to your Enrollment Assesment Form.', 3, 2),
(95, 'Go to Accounting Office', 4, 1),
(96, 'Ask a working student to have a stamp of COBSAP to your Enrollment Assesment Form.', 4, 2),
(140, 'asdfasdf', 1, 1),
(141, 'Visit CRMC Registrar for subject validation.', 1, 2),
(142, 'Get your enrollment form with signature of the Dean.', 1, 3),
(143, 'Lastly cashier for the billing process.', 1, 4);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `admin`
--
ALTER TABLE `admin`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `username` (`username`);

--
-- Indexes for table `floor`
--
ALTER TABLE `floor`
  ADD PRIMARY KEY (`floorid`),
  ADD UNIQUE KEY `floorname` (`floorname`);

--
-- Indexes for table `room`
--
ALTER TABLE `room`
  ADD PRIMARY KEY (`roomid`),
  ADD UNIQUE KEY `roomname` (`roomname`),
  ADD KEY `roomcategoryid` (`roomcategoryid`),
  ADD KEY `floorid` (`floorid`);

--
-- Indexes for table `roomcategory`
--
ALTER TABLE `roomcategory`
  ADD PRIMARY KEY (`roomcategoryid`),
  ADD UNIQUE KEY `roomcategoryname` (`roomcategoryname`);

--
-- Indexes for table `staff`
--
ALTER TABLE `staff`
  ADD PRIMARY KEY (`staffid`),
  ADD KEY `staffworkid` (`staffworkid`),
  ADD KEY `roomid` (`roomid`),
  ADD KEY `floorid` (`floorid`);

--
-- Indexes for table `staffworkposition`
--
ALTER TABLE `staffworkposition`
  ADD PRIMARY KEY (`staffworkid`),
  ADD UNIQUE KEY `staffworkposition` (`staffworkpositionname`);

--
-- Indexes for table `transaction`
--
ALTER TABLE `transaction`
  ADD PRIMARY KEY (`transactionid`),
  ADD UNIQUE KEY `transacntiontitle` (`transactiontitle`),
  ADD KEY `roomid` (`roomid`);

--
-- Indexes for table `transactionprocedure`
--
ALTER TABLE `transactionprocedure`
  ADD PRIMARY KEY (`tranprocedureid`),
  ADD KEY `transactionid` (`transactionid`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `admin`
--
ALTER TABLE `admin`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `floor`
--
ALTER TABLE `floor`
  MODIFY `floorid` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT for table `room`
--
ALTER TABLE `room`
  MODIFY `roomid` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=26;

--
-- AUTO_INCREMENT for table `roomcategory`
--
ALTER TABLE `roomcategory`
  MODIFY `roomcategoryid` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;

--
-- AUTO_INCREMENT for table `staff`
--
ALTER TABLE `staff`
  MODIFY `staffid` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=36;

--
-- AUTO_INCREMENT for table `staffworkposition`
--
ALTER TABLE `staffworkposition`
  MODIFY `staffworkid` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=29;

--
-- AUTO_INCREMENT for table `transaction`
--
ALTER TABLE `transaction`
  MODIFY `transactionid` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;

--
-- AUTO_INCREMENT for table `transactionprocedure`
--
ALTER TABLE `transactionprocedure`
  MODIFY `tranprocedureid` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=144;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
