
import com.formdev.flatlaf.FlatIntelliJLaf;
import java.awt.Color;
import java.awt.Font;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.UIManager;
import javax.swing.table.DefaultTableModel;

public class popup_details extends javax.swing.JFrame {

   Connection con;
   Statement st;
     final String classfor = "com.mysql.jdbc.Driver";
    final String connect = "jdbc:mysql://localhost:3306/systemdatabase?zeroDateTimeBehavior=convertToNull";
    final String username = "root";
    final String password = "";
    
    
    public popup_details() {
        initComponents();
        
         getroom();
        tableCustom();
         getstaff();
       
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        details = new javax.swing.JPanel();
        jLabel2 = new javax.swing.JLabel();
        roomlabel = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();
        jScrollPane1 = new javax.swing.JScrollPane();
        staff_table = new javax.swing.JTable();
        roomtypelabel = new javax.swing.JLabel();
        roomabbreviation = new javax.swing.JLabel();
        jButton1 = new javax.swing.JButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setCursor(new java.awt.Cursor(java.awt.Cursor.DEFAULT_CURSOR));
        setUndecorated(true);
        setPreferredSize(new java.awt.Dimension(459, 540));
        setResizable(false);
        addMouseMotionListener(new java.awt.event.MouseMotionAdapter() {
            public void mouseMoved(java.awt.event.MouseEvent evt) {
                formMouseMoved(evt);
            }
        });
        getContentPane().setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        details.setBackground(new java.awt.Color(29, 164, 108));
        details.addMouseMotionListener(new java.awt.event.MouseMotionAdapter() {
            public void mouseDragged(java.awt.event.MouseEvent evt) {
                detailsMouseDragged(evt);
            }
        });
        details.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jLabel2.setFont(new java.awt.Font("Segoe UI Light", 1, 14)); // NOI18N
        jLabel2.setForeground(new java.awt.Color(255, 255, 255));
        jLabel2.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel2.setText("ROOM TYPE");
        details.add(jLabel2, new org.netbeans.lib.awtextra.AbsoluteConstraints(310, 150, 120, -1));

        roomlabel.setFont(new java.awt.Font("Segoe UI Semibold", 1, 24)); // NOI18N
        roomlabel.setForeground(new java.awt.Color(255, 255, 255));
        roomlabel.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        roomlabel.setText("ROOM NAME");
        details.add(roomlabel, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 30, 440, 50));

        jLabel4.setFont(new java.awt.Font("Segoe UI Light", 1, 14)); // NOI18N
        jLabel4.setForeground(new java.awt.Color(255, 255, 255));
        jLabel4.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel4.setText("ABBREVIATION");
        details.add(jLabel4, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 150, 120, -1));

        staff_table.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        staff_table.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "Staff Name", "Work Position"
            }
        ) {
            Class[] types = new Class [] {
                java.lang.String.class, java.lang.String.class
            };
            boolean[] canEdit = new boolean [] {
                false, false
            };

            public Class getColumnClass(int columnIndex) {
                return types [columnIndex];
            }

            public boolean isCellEditable(int rowIndex, int columnIndex) {
                return canEdit [columnIndex];
            }
        });
        staff_table.setFocusable(false);
        staff_table.setGridColor(new java.awt.Color(204, 204, 204));
        staff_table.setRequestFocusEnabled(false);
        staff_table.setRowHeight(20);
        staff_table.setRowSelectionAllowed(false);
        staff_table.setShowHorizontalLines(false);
        staff_table.setShowVerticalLines(false);
        staff_table.setUpdateSelectionOnSort(false);
        staff_table.setVerifyInputWhenFocusTarget(false);
        jScrollPane1.setViewportView(staff_table);

        details.add(jScrollPane1, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 230, 400, 300));

        roomtypelabel.setFont(new java.awt.Font("Segoe UI Semibold", 1, 12)); // NOI18N
        roomtypelabel.setForeground(new java.awt.Color(255, 255, 255));
        roomtypelabel.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        roomtypelabel.setText("ROOM TYPE");
        details.add(roomtypelabel, new org.netbeans.lib.awtextra.AbsoluteConstraints(310, 170, 120, -1));

        roomabbreviation.setFont(new java.awt.Font("Segoe UI Semibold", 1, 12)); // NOI18N
        roomabbreviation.setForeground(new java.awt.Color(255, 255, 255));
        roomabbreviation.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        roomabbreviation.setText("ABBREVIATION");
        details.add(roomabbreviation, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 170, 120, -1));

        jButton1.setText("Min");
        jButton1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton1ActionPerformed(evt);
            }
        });
        details.add(jButton1, new org.netbeans.lib.awtextra.AbsoluteConstraints(350, 10, 80, -1));

        getContentPane().add(details, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 459, 550));

        pack();
        setLocationRelativeTo(null);
    }// </editor-fold>//GEN-END:initComponents

    private void jButton1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton1ActionPerformed
      this.dispose();
    }//GEN-LAST:event_jButton1ActionPerformed

    private void formMouseMoved(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_formMouseMoved
        // TODO add your handling code here:
    }//GEN-LAST:event_formMouseMoved

    private void detailsMouseDragged(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_detailsMouseDragged
     

        
        
    }//GEN-LAST:event_detailsMouseDragged

    
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
       try {    UIManager.setLookAndFeel(new FlatIntelliJLaf ());
       }
       catch (Exception e) {
           e.printStackTrace ();
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new popup_details().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JPanel details;
    private javax.swing.JButton jButton1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JLabel roomabbreviation;
    private javax.swing.JLabel roomlabel;
    private javax.swing.JLabel roomtypelabel;
    private javax.swing.JTable staff_table;
    // End of variables declaration//GEN-END:variables

    public void tableCustom(){
          staff_table.getTableHeader().setFont(new Font("SanSerif",Font.BOLD,12));
        staff_table.getTableHeader().setBackground(new Color(3,169,131));
        staff_table.getTableHeader().setForeground(new Color(255,255,255));
    }
    
    public void getstaff(){
        DefaultTableModel model1 = (DefaultTableModel) staff_table.getModel();
                    model1.setRowCount(0);
           try {
            Class.forName(classfor);
            con = DriverManager.getConnection(connect, username, password);
            String ss= "SELECT staff.staffid, CONCAT(staff.stafffn,' ',staff.staffmn,' ',staff.staffln) AS 'fullname', staffworkposition.staffworkpositionname, room.roomname, floor.floorname FROM staff LEFT JOIN staffworkposition ON staff.staffworkid = staffworkposition.staffworkid LEFT JOIN room ON staff.roomid = room.roomid LEFT JOIN floor ON staff.floorid = floor.floorid WHERE room.roomname = 'President Office' ORDER BY staff.staffid ASC;";
           
            st = con.createStatement();
            ResultSet rs = st.executeQuery(ss);
             
             DefaultTableModel model = (DefaultTableModel) staff_table.getModel();
            while (rs.next()) {
                
                Object[] row = new Object[2];     
                row[0] = rs.getString("fullname");
                row[1]= rs.getString("staffworkpositionname");
                 model.addRow(row);
            }
        }catch (ClassNotFoundException | SQLException  | NullPointerException ex) {
            Logger.getLogger(popup_details.class.getName()).log(Level.SEVERE, null, ex);
       
        }
    
    }
    
    public void  getroom(){
          try {
            Class.forName(classfor);
            con = DriverManager.getConnection(connect, username, password);
    
             String ss= "SELECT room.roomid, room.roomname, room.abbreviation, roomcategory.roomcategoryname, floor.floorname FROM room LEFT JOIN roomcategory ON room.roomcategoryid = roomcategory.roomcategoryid LEFT JOIN floor ON room.floorid = floor.floorid  WHERE room.roomname = 'President Office' ORDER BY room.roomid ASC;";
           
            st = con.createStatement();
            ResultSet rs = st.executeQuery(ss);
             
          
            if (rs.first()) {
                
             roomlabel.setText(rs.getString("roomname"));
             roomabbreviation.setText(rs.getString("abbreviation"));
             roomtypelabel.setText(rs.getString("roomcategoryname"));
            }
            
            
        }catch (ClassNotFoundException | SQLException  | NullPointerException ex) {
            Logger.getLogger(AdminDashboard.class.getName()).log(Level.SEVERE, null, ex);
       
        }
    }

}
