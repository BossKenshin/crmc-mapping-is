
import com.formdev.flatlaf.FlatIntelliJLaf;
import java.awt.Color;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.ImageIcon;
import javax.swing.JOptionPane;
import javax.swing.UIManager;


public class UI extends javax.swing.JFrame {

    
     
       Statement st;
       Connection con;
     static public ImageIcon imageunsee; 
        static public ImageIcon imagesee;


    
    public UI() {
      
        
        initComponents();
           disable();
    }

  
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        panelui = new javax.swing.JPanel();
        btnexit = new javax.swing.JButton();
        btnguest = new javax.swing.JButton();
        btnlogin = new javax.swing.JButton();
        backg = new javax.swing.JLabel();
        login = new javax.swing.JPanel();
        btnreturn = new javax.swing.JButton();
        usertext = new javax.swing.JTextField();
        passtext = new javax.swing.JPasswordField();
        btnadmin = new javax.swing.JButton();
        btnsee = new javax.swing.JRadioButton();
        lgbg = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setUndecorated(true);
        setResizable(false);
        getContentPane().setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        panelui.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        btnexit.setBackground(new java.awt.Color(33, 88, 71));
        btnexit.setFont(new java.awt.Font("Segoe UI Semilight", 1, 18)); // NOI18N
        btnexit.setForeground(new java.awt.Color(255, 255, 255));
        btnexit.setText("EXIT");
        btnexit.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED));
        btnexit.setFocusPainted(false);
        btnexit.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        btnexit.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnexitActionPerformed(evt);
            }
        });
        panelui.add(btnexit, new org.netbeans.lib.awtextra.AbsoluteConstraints(520, 350, 260, 50));

        btnguest.setBackground(new java.awt.Color(33, 88, 71));
        btnguest.setFont(new java.awt.Font("Segoe UI Semilight", 1, 18)); // NOI18N
        btnguest.setForeground(new java.awt.Color(255, 255, 255));
        btnguest.setText("GUEST");
        btnguest.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED));
        btnguest.setFocusPainted(false);
        btnguest.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        btnguest.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnguestActionPerformed(evt);
            }
        });
        panelui.add(btnguest, new org.netbeans.lib.awtextra.AbsoluteConstraints(520, 150, 260, 50));

        btnlogin.setBackground(new java.awt.Color(33, 88, 71));
        btnlogin.setFont(new java.awt.Font("Segoe UI Semilight", 1, 18)); // NOI18N
        btnlogin.setForeground(new java.awt.Color(255, 255, 255));
        btnlogin.setText("LOGIN");
        btnlogin.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED));
        btnlogin.setFocusPainted(false);
        btnlogin.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        btnlogin.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnloginActionPerformed(evt);
            }
        });
        panelui.add(btnlogin, new org.netbeans.lib.awtextra.AbsoluteConstraints(520, 250, 260, 50));

        backg.setIcon(new javax.swing.ImageIcon(getClass().getResource("/icon/UIFIRST (3).png"))); // NOI18N
        panelui.add(backg, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 830, 520));

        getContentPane().add(panelui, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 830, 520));

        login.setBackground(new java.awt.Color(0, 102, 102));
        login.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        btnreturn.setBorder(null);
        btnreturn.setContentAreaFilled(false);
        btnreturn.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnreturnActionPerformed(evt);
            }
        });
        login.add(btnreturn, new org.netbeans.lib.awtextra.AbsoluteConstraints(740, 0, 90, 40));

        usertext.setFont(new java.awt.Font("Microsoft YaHei UI Light", 0, 13)); // NOI18N
        usertext.setBorder(null);
        login.add(usertext, new org.netbeans.lib.awtextra.AbsoluteConstraints(304, 196, 220, 30));

        passtext.setFont(new java.awt.Font("Microsoft JhengHei UI Light", 0, 13)); // NOI18N
        passtext.setBorder(null);
        login.add(passtext, new org.netbeans.lib.awtextra.AbsoluteConstraints(304, 306, 190, 30));

        btnadmin.setBorder(null);
        btnadmin.setContentAreaFilled(false);
        btnadmin.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnadminActionPerformed(evt);
            }
        });
        login.add(btnadmin, new org.netbeans.lib.awtextra.AbsoluteConstraints(300, 373, 230, 30));

        btnsee.setForeground(new java.awt.Color(255, 255, 255));
        btnsee.setText("See Password");
        btnsee.setFocusPainted(false);
        btnsee.setOpaque(false);
        btnsee.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnseeActionPerformed(evt);
            }
        });
        login.add(btnsee, new org.netbeans.lib.awtextra.AbsoluteConstraints(370, 340, -1, -1));

        lgbg.setFont(new java.awt.Font("Tahoma", 0, 36)); // NOI18N
        lgbg.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        lgbg.setIcon(new javax.swing.ImageIcon(getClass().getResource("/icon/ADLOG.png"))); // NOI18N
        lgbg.setToolTipText("");
        login.add(lgbg, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 830, 520));

        getContentPane().add(login, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 830, 520));

        pack();
        setLocationRelativeTo(null);
    }// </editor-fold>//GEN-END:initComponents

    private void btnreturnActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnreturnActionPerformed
        // TODO add your handling code here:
       login.setVisible(false);
        panelui.setVisible(true);
           disable();
    }//GEN-LAST:event_btnreturnActionPerformed

    private void btnadminActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnadminActionPerformed
        // TODO add your handling code here:
        String uname = usertext.getText();
         String pass = String.valueOf(passtext.getPassword());
       
        if(uname.length() == 0 || pass.length() == 0){
            alert("Please Fill in the Details");
        }
        else{
            checkadmin(uname, pass);
        }
    }//GEN-LAST:event_btnadminActionPerformed

    private void btnexitActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnexitActionPerformed
        // TODO add your handling code here:
        System.exit(0);
        
        
    }//GEN-LAST:event_btnexitActionPerformed

    private void btnloginActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnloginActionPerformed
        // TODO add your handling code here:
        panelui.setVisible(false);
        login.setVisible(true);
    }//GEN-LAST:event_btnloginActionPerformed

    private void btnseeActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnseeActionPerformed
        if(btnsee.isSelected()){
            passtext.setEchoChar((char)0);
          btnsee.setText("Unsee Password");
        }
        else{
            passtext.setEchoChar('*');
             btnsee.setText("See Password"); 
        }

    }//GEN-LAST:event_btnseeActionPerformed

    private void btnguestActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnguestActionPerformed
      this.dispose();
      UserDashboard UD = new UserDashboard();
      UD.setVisible(true);
    }//GEN-LAST:event_btnguestActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
           try {    UIManager.setLookAndFeel(new FlatIntelliJLaf ());
       }
       catch (Exception e) {
           e.printStackTrace ();
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
               new UI().getContentPane().setBackground(new Color(1.0f, 1.0f, 1.0f, 0.0f));
               new UI().setBackground(new Color(1.0f, 1.0f, 1.0f, 0.0f));
                new UI().setVisible(true);
               
              
             
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JLabel backg;
    private javax.swing.JButton btnadmin;
    private javax.swing.JButton btnexit;
    private javax.swing.JButton btnguest;
    private javax.swing.JButton btnlogin;
    private javax.swing.JButton btnreturn;
    private javax.swing.JRadioButton btnsee;
    private javax.swing.JLabel lgbg;
    private javax.swing.JPanel login;
    private javax.swing.JPanel panelui;
    private javax.swing.JPasswordField passtext;
    private javax.swing.JTextField usertext;
    // End of variables declaration//GEN-END:variables
public void disable(){
    login.setVisible(false);    
}
public void clear(){
    usertext.setText("");
    passtext.setText("");
}


public void alert(String msg)
{
JOptionPane.showMessageDialog(rootPane, msg);
}

private void checkadmin(String adminname, String adminpass) {
        
         try {
            Class.forName("com.mysql.jdbc.Driver");
            con = DriverManager.getConnection("jdbc:mysql://localhost:3306/systemdatabase?zeroDateTimeBehavior=convertToNull", "root", "");
            String sql = "SELECT  * FROM admin WHERE username = '"+adminname+"' AND password = '"+adminpass+"'";
            st = con.createStatement();
         ResultSet rs =   st.executeQuery(sql);
              if(rs.first()){
                  alert("Log in Successfully");
                  AdminDashboard AD = new AdminDashboard();
                  this.dispose();
                  AD.setVisible(true);
              }
              else{
                  alert("Password or Username Incorrect");
                  usertext.setText("");
                  passtext.setText("");
              }
        } catch (ClassNotFoundException | SQLException ex) {
            Logger.getLogger(AdminDashboard.class.getName()).log(Level.SEVERE, null, ex);
        }
        
    }



}
