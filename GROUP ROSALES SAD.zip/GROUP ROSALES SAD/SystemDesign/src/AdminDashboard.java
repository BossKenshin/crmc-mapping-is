
import com.formdev.flatlaf.FlatIntelliJLaf;
import java.awt.Color;
import java.awt.Font;
import java.awt.Image;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.File;
import java.io.FileInputStream;
import java.io.InputStream;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.ImageIcon;
import javax.swing.JFileChooser;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.Timer;
import javax.swing.UIManager;
import javax.swing.filechooser.FileNameExtensionFilter;
import javax.swing.table.DefaultTableCellRenderer;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.TableModel;


public class AdminDashboard extends javax.swing.JFrame {

   
     Timer timer;
     String stid;
    String roid; 
     String flrid;
    String s=null;
    String cid;
      String whattable;
    final String resetcolor= "new Color(41,62,81)";
    Connection con;
    Statement st;
    
    
    
    public AdminDashboard() {
        initComponents();
        startup();
        DigitalClock();
        
    }

    
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        TopNavPanel = new javax.swing.JPanel();
        btnRoom = new javax.swing.JButton();
        btnStaff = new javax.swing.JButton();
        btnTransaction = new javax.swing.JButton();
        btnPrevMap = new javax.swing.JButton();
        titlelabel = new javax.swing.JLabel();
        btnGeneral = new javax.swing.JButton();
        btnlogout = new javax.swing.JButton();
        title = new javax.swing.JLabel();
        titlelabel1 = new javax.swing.JLabel();
        datelabel = new javax.swing.JLabel();
        timelabel = new javax.swing.JLabel();
        ContainerPanel = new javax.swing.JPanel();
        GeneralPanel = new javax.swing.JPanel();
        jLabel1 = new javax.swing.JLabel();
        btnnumroom = new javax.swing.JButton();
        jLabel5 = new javax.swing.JLabel();
        jLabel6 = new javax.swing.JLabel();
        btnnumroomcat = new javax.swing.JButton();
        jLabel7 = new javax.swing.JLabel();
        btnnumStaff = new javax.swing.JButton();
        jLabel8 = new javax.swing.JLabel();
        btnnumStaffposition = new javax.swing.JButton();
        jScrollPane6 = new javax.swing.JScrollPane();
        tblSumRoom = new javax.swing.JTable();
        RoomPanel = new javax.swing.JPanel();
        TabbedRoom = new javax.swing.JTabbedPane();
        Room = new javax.swing.JPanel();
        roomformpanel = new javax.swing.JPanel();
        RoomTextfield = new javax.swing.JTextField();
        FloorBox = new javax.swing.JComboBox<>();
        jLabel9 = new javax.swing.JLabel();
        jLabel10 = new javax.swing.JLabel();
        CategoryRoomBox = new javax.swing.JComboBox<>();
        jLabel11 = new javax.swing.JLabel();
        btnRoomadd = new javax.swing.JButton();
        btnRoomupdate = new javax.swing.JButton();
        btnRoomdelete = new javax.swing.JButton();
        btnReset = new javax.swing.JButton();
        jLabel12 = new javax.swing.JLabel();
        abbtext = new javax.swing.JTextField();
        jLabel23 = new javax.swing.JLabel();
        jScrollPane1 = new javax.swing.JScrollPane();
        tblroom = new javax.swing.JTable();
        CategoryRoom = new javax.swing.JPanel();
        ButtonOptionsPanel = new javax.swing.JPanel();
        CategoryTextfield = new javax.swing.JTextField();
        btnaddcategory = new javax.swing.JButton();
        btnupdatecategory = new javax.swing.JButton();
        btndeletecategory = new javax.swing.JButton();
        jLabel13 = new javax.swing.JLabel();
        btnclearcategory = new javax.swing.JButton();
        jScrollPane2 = new javax.swing.JScrollPane();
        tblcategoryroom = new javax.swing.JTable();
        StaffPanel = new javax.swing.JPanel();
        TabbedStaff = new javax.swing.JTabbedPane();
        Staff = new javax.swing.JPanel();
        jPanel2 = new javax.swing.JPanel();
        sroomtextfield = new javax.swing.JTextField();
        fntext = new javax.swing.JTextField();
        lntext = new javax.swing.JTextField();
        jLabel2 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();
        workpositionbox = new javax.swing.JComboBox<>();
        jLabel14 = new javax.swing.JLabel();
        jLabel15 = new javax.swing.JLabel();
        mntext = new javax.swing.JTextField();
        jLabel16 = new javax.swing.JLabel();
        TextfieldFloor = new javax.swing.JTextField();
        btnDeleteStaff = new javax.swing.JButton();
        btnAddStaff = new javax.swing.JButton();
        btnClearStaff = new javax.swing.JButton();
        btnUpdateStaff = new javax.swing.JButton();
        tblsearchpane = new javax.swing.JScrollPane();
        tblsearchroom = new javax.swing.JTable();
        jLabel17 = new javax.swing.JLabel();
        jScrollPane4 = new javax.swing.JScrollPane();
        tblStaff = new javax.swing.JTable();
        StaffCategory = new javax.swing.JPanel();
        jPanel3 = new javax.swing.JPanel();
        TextfieldPosition = new javax.swing.JTextField();
        jLabel18 = new javax.swing.JLabel();
        btnDeleteStaff1 = new javax.swing.JButton();
        btnAddStaff1 = new javax.swing.JButton();
        btnClearStaff1 = new javax.swing.JButton();
        btnUpdateStaff1 = new javax.swing.JButton();
        jLabel19 = new javax.swing.JLabel();
        jScrollPane5 = new javax.swing.JScrollPane();
        tblStaffCategory = new javax.swing.JTable();
        TransactionPanel = new javax.swing.JPanel();
        TabbedTransaction = new javax.swing.JTabbedPane();
        Transaction = new javax.swing.JPanel();
        jPanel4 = new javax.swing.JPanel();
        TransactionTitleTextfield = new javax.swing.JTextField();
        jLabel20 = new javax.swing.JLabel();
        btndeletetranstitle = new javax.swing.JButton();
        btnaddtranstitle = new javax.swing.JButton();
        btncleartrans = new javax.swing.JButton();
        btnupdatetranstitle = new javax.swing.JButton();
        jLabel21 = new javax.swing.JLabel();
        RoomtranTextfield = new javax.swing.JTextField();
        tblroomtranspane = new javax.swing.JScrollPane();
        tblsearchroomtrans = new javax.swing.JTable();
        jLabel22 = new javax.swing.JLabel();
        jScrollPane3 = new javax.swing.JScrollPane();
        tbltransactiontitle = new javax.swing.JTable();
        TransactionProcedure = new javax.swing.JPanel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setBackground(new java.awt.Color(36, 72, 92));
        setMinimumSize(new java.awt.Dimension(1366, 700));
        setUndecorated(true);
        setSize(new java.awt.Dimension(1366, 700));
        getContentPane().setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        TopNavPanel.setBackground(new java.awt.Color(41, 150, 116));
        TopNavPanel.setPreferredSize(new java.awt.Dimension(1050, 162));
        TopNavPanel.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        btnRoom.setBackground(new java.awt.Color(204, 204, 204));
        btnRoom.setFont(new java.awt.Font("SansSerif", 0, 14)); // NOI18N
        btnRoom.setForeground(new java.awt.Color(204, 204, 204));
        btnRoom.setText("Room");
        btnRoom.setBorder(null);
        btnRoom.setBorderPainted(false);
        btnRoom.setContentAreaFilled(false);
        btnRoom.setPreferredSize(new java.awt.Dimension(93, 23));
        btnRoom.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                btnRoomMouseClicked(evt);
            }
        });
        btnRoom.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnRoomActionPerformed(evt);
            }
        });
        TopNavPanel.add(btnRoom, new org.netbeans.lib.awtextra.AbsoluteConstraints(724, 14, -1, -1));

        btnStaff.setBackground(new java.awt.Color(204, 204, 204));
        btnStaff.setFont(new java.awt.Font("SansSerif", 0, 14)); // NOI18N
        btnStaff.setForeground(new java.awt.Color(204, 204, 204));
        btnStaff.setText("Staff");
        btnStaff.setBorder(null);
        btnStaff.setBorderPainted(false);
        btnStaff.setContentAreaFilled(false);
        btnStaff.setPreferredSize(new java.awt.Dimension(93, 23));
        btnStaff.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                btnStaffMouseClicked(evt);
            }
        });
        btnStaff.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnStaffActionPerformed(evt);
            }
        });
        TopNavPanel.add(btnStaff, new org.netbeans.lib.awtextra.AbsoluteConstraints(858, 14, -1, -1));

        btnTransaction.setBackground(new java.awt.Color(204, 204, 204));
        btnTransaction.setFont(new java.awt.Font("SansSerif", 0, 14)); // NOI18N
        btnTransaction.setForeground(new java.awt.Color(204, 204, 204));
        btnTransaction.setText("Transaction");
        btnTransaction.setBorder(null);
        btnTransaction.setBorderPainted(false);
        btnTransaction.setContentAreaFilled(false);
        btnTransaction.setPreferredSize(new java.awt.Dimension(93, 23));
        btnTransaction.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                btnTransactionMouseClicked(evt);
            }
        });
        btnTransaction.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnTransactionActionPerformed(evt);
            }
        });
        TopNavPanel.add(btnTransaction, new org.netbeans.lib.awtextra.AbsoluteConstraints(992, 14, -1, -1));

        btnPrevMap.setBackground(new java.awt.Color(204, 204, 204));
        btnPrevMap.setFont(new java.awt.Font("SansSerif", 0, 14)); // NOI18N
        btnPrevMap.setForeground(new java.awt.Color(204, 204, 204));
        btnPrevMap.setText("Preview Map");
        btnPrevMap.setBorder(null);
        btnPrevMap.setBorderPainted(false);
        btnPrevMap.setContentAreaFilled(false);
        TopNavPanel.add(btnPrevMap, new org.netbeans.lib.awtextra.AbsoluteConstraints(1126, 16, -1, -1));

        titlelabel.setFont(new java.awt.Font("SansSerif", 0, 28)); // NOI18N
        titlelabel.setForeground(new java.awt.Color(255, 255, 255));
        titlelabel.setText("General");
        TopNavPanel.add(titlelabel, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 74, 410, 49));

        btnGeneral.setBackground(new java.awt.Color(204, 204, 204));
        btnGeneral.setFont(new java.awt.Font("SansSerif", 0, 14)); // NOI18N
        btnGeneral.setForeground(new java.awt.Color(204, 204, 204));
        btnGeneral.setText("General");
        btnGeneral.setBorder(null);
        btnGeneral.setBorderPainted(false);
        btnGeneral.setContentAreaFilled(false);
        btnGeneral.setPreferredSize(new java.awt.Dimension(93, 23));
        btnGeneral.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                btnGeneralMouseClicked(evt);
            }
        });
        btnGeneral.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnGeneralActionPerformed(evt);
            }
        });
        TopNavPanel.add(btnGeneral, new org.netbeans.lib.awtextra.AbsoluteConstraints(590, 14, -1, -1));

        btnlogout.setBackground(new java.awt.Color(36, 72, 92));
        btnlogout.setFont(new java.awt.Font("SansSerif", 1, 11)); // NOI18N
        btnlogout.setForeground(new java.awt.Color(255, 255, 255));
        btnlogout.setText("Log out");
        btnlogout.setBorder(null);
        btnlogout.setBorderPainted(false);
        btnlogout.setFocusPainted(false);
        btnlogout.setFocusable(false);
        btnlogout.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnlogoutActionPerformed(evt);
            }
        });
        TopNavPanel.add(btnlogout, new org.netbeans.lib.awtextra.AbsoluteConstraints(1303, 11, 57, 30));

        title.setFont(new java.awt.Font("SansSerif", 0, 28)); // NOI18N
        title.setForeground(new java.awt.Color(255, 255, 255));
        title.setText("CRMC Mapping and Information System");
        TopNavPanel.add(title, new org.netbeans.lib.awtextra.AbsoluteConstraints(430, 74, 592, 49));

        titlelabel1.setFont(new java.awt.Font("SansSerif", 2, 18)); // NOI18N
        titlelabel1.setForeground(new java.awt.Color(255, 255, 255));
        titlelabel1.setText("Admin Dashboard");
        TopNavPanel.add(titlelabel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 11, -1, -1));

        datelabel.setFont(new java.awt.Font("SansSerif", 1, 18)); // NOI18N
        datelabel.setForeground(new java.awt.Color(255, 255, 255));
        datelabel.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        datelabel.setText("Date");
        TopNavPanel.add(datelabel, new org.netbeans.lib.awtextra.AbsoluteConstraints(1150, 70, 205, -1));

        timelabel.setFont(new java.awt.Font("SansSerif", 0, 14)); // NOI18N
        timelabel.setForeground(new java.awt.Color(255, 255, 255));
        timelabel.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        timelabel.setText("Time");
        TopNavPanel.add(timelabel, new org.netbeans.lib.awtextra.AbsoluteConstraints(1150, 100, 205, -1));

        getContentPane().add(TopNavPanel, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 1370, 120));

        ContainerPanel.setBackground(new java.awt.Color(246, 246, 246));
        ContainerPanel.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        GeneralPanel.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jLabel1.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        jLabel1.setForeground(new java.awt.Color(255, 255, 255));
        jLabel1.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel1.setLabelFor(btnnumroom);
        jLabel1.setText("Number of Rooms");
        jLabel1.setFocusable(false);
        jLabel1.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        GeneralPanel.add(jLabel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(70, 190, 210, 30));

        btnnumroom.setBackground(new java.awt.Color(36, 72, 92));
        btnnumroom.setFont(new java.awt.Font("Tahoma", 1, 36)); // NOI18N
        btnnumroom.setForeground(new java.awt.Color(255, 255, 255));
        btnnumroom.setText("0");
        btnnumroom.setBorder(null);
        btnnumroom.setBorderPainted(false);
        btnnumroom.setFocusPainted(false);
        btnnumroom.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        btnnumroom.setIconTextGap(10);
        btnnumroom.setPreferredSize(new java.awt.Dimension(172, 150));
        btnnumroom.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnnumroomActionPerformed(evt);
            }
        });
        GeneralPanel.add(btnnumroom, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 70, 310, 160));

        jLabel5.setBackground(new java.awt.Color(41, 150, 116));
        jLabel5.setOpaque(true);
        GeneralPanel.add(jLabel5, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 1370, 30));

        jLabel6.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        jLabel6.setForeground(new java.awt.Color(255, 255, 255));
        jLabel6.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel6.setLabelFor(btnnumroom);
        jLabel6.setText("Number of Room Category");
        jLabel6.setFocusable(false);
        jLabel6.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        GeneralPanel.add(jLabel6, new org.netbeans.lib.awtextra.AbsoluteConstraints(410, 190, 210, 30));

        btnnumroomcat.setBackground(new java.awt.Color(36, 72, 92));
        btnnumroomcat.setFont(new java.awt.Font("Tahoma", 1, 36)); // NOI18N
        btnnumroomcat.setForeground(new java.awt.Color(255, 255, 255));
        btnnumroomcat.setText("0");
        btnnumroomcat.setBorder(null);
        btnnumroomcat.setBorderPainted(false);
        btnnumroomcat.setFocusPainted(false);
        btnnumroomcat.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        btnnumroomcat.setIconTextGap(10);
        btnnumroomcat.setPreferredSize(new java.awt.Dimension(172, 150));
        GeneralPanel.add(btnnumroomcat, new org.netbeans.lib.awtextra.AbsoluteConstraints(360, 70, 310, 160));

        jLabel7.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        jLabel7.setForeground(new java.awt.Color(255, 255, 255));
        jLabel7.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel7.setLabelFor(btnnumroom);
        jLabel7.setText("Number of Staff");
        jLabel7.setFocusable(false);
        jLabel7.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        GeneralPanel.add(jLabel7, new org.netbeans.lib.awtextra.AbsoluteConstraints(750, 190, 210, 30));

        btnnumStaff.setBackground(new java.awt.Color(36, 72, 92));
        btnnumStaff.setFont(new java.awt.Font("Tahoma", 1, 36)); // NOI18N
        btnnumStaff.setForeground(new java.awt.Color(255, 255, 255));
        btnnumStaff.setText("0");
        btnnumStaff.setBorder(null);
        btnnumStaff.setBorderPainted(false);
        btnnumStaff.setFocusPainted(false);
        btnnumStaff.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        btnnumStaff.setIconTextGap(10);
        btnnumStaff.setPreferredSize(new java.awt.Dimension(172, 150));
        btnnumStaff.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnnumStaffActionPerformed(evt);
            }
        });
        GeneralPanel.add(btnnumStaff, new org.netbeans.lib.awtextra.AbsoluteConstraints(700, 70, 310, 160));

        jLabel8.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        jLabel8.setForeground(new java.awt.Color(255, 255, 255));
        jLabel8.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel8.setLabelFor(btnnumroom);
        jLabel8.setText("Number of Work Position");
        jLabel8.setFocusable(false);
        jLabel8.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        GeneralPanel.add(jLabel8, new org.netbeans.lib.awtextra.AbsoluteConstraints(1090, 190, 210, 30));

        btnnumStaffposition.setBackground(new java.awt.Color(36, 72, 92));
        btnnumStaffposition.setFont(new java.awt.Font("Tahoma", 1, 36)); // NOI18N
        btnnumStaffposition.setForeground(new java.awt.Color(255, 255, 255));
        btnnumStaffposition.setText("0");
        btnnumStaffposition.setBorder(null);
        btnnumStaffposition.setBorderPainted(false);
        btnnumStaffposition.setFocusPainted(false);
        btnnumStaffposition.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        btnnumStaffposition.setIconTextGap(10);
        btnnumStaffposition.setPreferredSize(new java.awt.Dimension(172, 150));
        btnnumStaffposition.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnnumStaffpositionActionPerformed(evt);
            }
        });
        GeneralPanel.add(btnnumStaffposition, new org.netbeans.lib.awtextra.AbsoluteConstraints(1040, 70, 310, 160));

        jScrollPane6.setOpaque(false);

        tblSumRoom.setBackground(new java.awt.Color(36, 72, 92));
        tblSumRoom.setForeground(new java.awt.Color(255, 255, 255));
        tblSumRoom.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "Staff Name", "Work Position", "Room", "Room Category", "Floor"
            }
        ) {
            Class[] types = new Class [] {
                java.lang.String.class, java.lang.String.class, java.lang.String.class, java.lang.String.class, java.lang.String.class
            };
            boolean[] canEdit = new boolean [] {
                false, false, false, false, false
            };

            public Class getColumnClass(int columnIndex) {
                return types [columnIndex];
            }

            public boolean isCellEditable(int rowIndex, int columnIndex) {
                return canEdit [columnIndex];
            }
        });
        tblSumRoom.setFocusable(false);
        tblSumRoom.setRequestFocusEnabled(false);
        tblSumRoom.setRowSelectionAllowed(false);
        tblSumRoom.setShowHorizontalLines(false);
        tblSumRoom.setUpdateSelectionOnSort(false);
        tblSumRoom.setVerifyInputWhenFocusTarget(false);
        jScrollPane6.setViewportView(tblSumRoom);

        GeneralPanel.add(jScrollPane6, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 250, 1330, 310));

        ContainerPanel.add(GeneralPanel, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 1370, 620));

        RoomPanel.setBackground(new java.awt.Color(36, 72, 92));
        RoomPanel.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        TabbedRoom.setBackground(new java.awt.Color(41, 150, 116));
        TabbedRoom.setForeground(new java.awt.Color(255, 255, 255));
        TabbedRoom.setCursor(new java.awt.Cursor(java.awt.Cursor.DEFAULT_CURSOR));
        TabbedRoom.setFont(new java.awt.Font("Tahoma", 0, 12)); // NOI18N
        TabbedRoom.setOpaque(true);
        TabbedRoom.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                TabbedRoomMouseClicked(evt);
            }
        });

        Room.setBackground(new java.awt.Color(246, 246, 246));
        Room.setFont(new java.awt.Font("Segoe UI Historic", 1, 12)); // NOI18N
        Room.setPreferredSize(new java.awt.Dimension(1045, 580));
        Room.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        roomformpanel.setBackground(new java.awt.Color(234, 239, 241));
        roomformpanel.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        RoomTextfield.setFont(new java.awt.Font("Tahoma", 0, 12)); // NOI18N
        RoomTextfield.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                RoomTextfieldActionPerformed(evt);
            }
        });
        RoomTextfield.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyReleased(java.awt.event.KeyEvent evt) {
                RoomTextfieldKeyReleased(evt);
            }
        });
        roomformpanel.add(RoomTextfield, new org.netbeans.lib.awtextra.AbsoluteConstraints(110, 90, 270, 30));

        FloorBox.setFont(new java.awt.Font("Tahoma", 0, 12)); // NOI18N
        FloorBox.setBorder(null);
        roomformpanel.add(FloorBox, new org.netbeans.lib.awtextra.AbsoluteConstraints(110, 240, 270, 30));

        jLabel9.setBackground(new java.awt.Color(0, 0, 0));
        jLabel9.setFont(new java.awt.Font("Tahoma", 0, 12)); // NOI18N
        jLabel9.setText("Room Name");
        roomformpanel.add(jLabel9, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 90, 73, 20));

        jLabel10.setBackground(new java.awt.Color(0, 0, 0));
        jLabel10.setFont(new java.awt.Font("Tahoma", 0, 12)); // NOI18N
        jLabel10.setText("Floor");
        roomformpanel.add(jLabel10, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 250, 40, 20));

        CategoryRoomBox.setFont(new java.awt.Font("Tahoma", 0, 12)); // NOI18N
        CategoryRoomBox.setBorder(null);
        CategoryRoomBox.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                CategoryRoomBoxActionPerformed(evt);
            }
        });
        roomformpanel.add(CategoryRoomBox, new org.netbeans.lib.awtextra.AbsoluteConstraints(110, 190, 270, 30));

        jLabel11.setBackground(new java.awt.Color(0, 0, 0));
        jLabel11.setFont(new java.awt.Font("Tahoma", 0, 12)); // NOI18N
        jLabel11.setText("Category");
        roomformpanel.add(jLabel11, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 200, 50, 20));

        btnRoomadd.setFont(new java.awt.Font("SansSerif", 0, 18)); // NOI18N
        btnRoomadd.setText("ADD");
        btnRoomadd.setBorderPainted(false);
        btnRoomadd.setContentAreaFilled(false);
        btnRoomadd.setFocusPainted(false);
        btnRoomadd.setFocusable(false);
        btnRoomadd.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                btnRoomaddMouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                btnRoomaddMouseExited(evt);
            }
        });
        btnRoomadd.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnRoomaddActionPerformed(evt);
            }
        });
        roomformpanel.add(btnRoomadd, new org.netbeans.lib.awtextra.AbsoluteConstraints(170, 300, 110, 30));

        btnRoomupdate.setFont(new java.awt.Font("SansSerif", 0, 18)); // NOI18N
        btnRoomupdate.setText("UPDATE");
        btnRoomupdate.setBorderPainted(false);
        btnRoomupdate.setContentAreaFilled(false);
        btnRoomupdate.setFocusPainted(false);
        btnRoomupdate.setFocusable(false);
        btnRoomupdate.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                btnRoomupdateMouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                btnRoomupdateMouseExited(evt);
            }
        });
        btnRoomupdate.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnRoomupdateActionPerformed(evt);
            }
        });
        roomformpanel.add(btnRoomupdate, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 340, 110, 30));

        btnRoomdelete.setFont(new java.awt.Font("SansSerif", 0, 18)); // NOI18N
        btnRoomdelete.setText("DELETE");
        btnRoomdelete.setBorderPainted(false);
        btnRoomdelete.setContentAreaFilled(false);
        btnRoomdelete.setFocusPainted(false);
        btnRoomdelete.setFocusable(false);
        btnRoomdelete.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                btnRoomdeleteMouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                btnRoomdeleteMouseExited(evt);
            }
        });
        btnRoomdelete.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnRoomdeleteActionPerformed(evt);
            }
        });
        roomformpanel.add(btnRoomdelete, new org.netbeans.lib.awtextra.AbsoluteConstraints(170, 340, 110, 30));

        btnReset.setFont(new java.awt.Font("SansSerif", 0, 18)); // NOI18N
        btnReset.setText("CLEAR");
        btnReset.setBorder(null);
        btnReset.setBorderPainted(false);
        btnReset.setContentAreaFilled(false);
        btnReset.setFocusPainted(false);
        btnReset.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                btnResetMouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                btnResetMouseExited(evt);
            }
        });
        btnReset.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnResetActionPerformed(evt);
            }
        });
        roomformpanel.add(btnReset, new org.netbeans.lib.awtextra.AbsoluteConstraints(310, 340, 110, 30));

        jLabel12.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        jLabel12.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel12.setText("ROOM FILL UP FORM");
        roomformpanel.add(jLabel12, new org.netbeans.lib.awtextra.AbsoluteConstraints(90, 20, 300, 30));
        roomformpanel.add(abbtext, new org.netbeans.lib.awtextra.AbsoluteConstraints(110, 140, 270, 30));

        jLabel23.setText("Abbreviation");
        roomformpanel.add(jLabel23, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 150, -1, 20));

        Room.add(roomformpanel, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 490, 580));

        tblroom.setFont(new java.awt.Font("SansSerif", 0, 11)); // NOI18N
        tblroom.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "Room ID", "Room Name", "Abbreviation", "Room Category", "Floor "
            }
        ) {
            Class[] types = new Class [] {
                java.lang.Integer.class, java.lang.String.class, java.lang.String.class, java.lang.String.class, java.lang.String.class
            };
            boolean[] canEdit = new boolean [] {
                false, false, false, false, false
            };

            public Class getColumnClass(int columnIndex) {
                return types [columnIndex];
            }

            public boolean isCellEditable(int rowIndex, int columnIndex) {
                return canEdit [columnIndex];
            }
        });
        tblroom.getTableHeader().setReorderingAllowed(false);
        tblroom.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                tblroomMouseClicked(evt);
            }
        });
        jScrollPane1.setViewportView(tblroom);

        Room.add(jScrollPane1, new org.netbeans.lib.awtextra.AbsoluteConstraints(520, 20, 820, 490));

        TabbedRoom.addTab("Room", Room);

        CategoryRoom.setBackground(new java.awt.Color(246, 246, 246));
        CategoryRoom.setFont(new java.awt.Font("Segoe UI Historic", 1, 12)); // NOI18N
        CategoryRoom.setPreferredSize(new java.awt.Dimension(1045, 580));
        CategoryRoom.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        ButtonOptionsPanel.setBackground(new java.awt.Color(234, 239, 241));
        ButtonOptionsPanel.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        CategoryTextfield.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                CategoryTextfieldActionPerformed(evt);
            }
        });
        ButtonOptionsPanel.add(CategoryTextfield, new org.netbeans.lib.awtextra.AbsoluteConstraints(40, 130, 260, 33));

        btnaddcategory.setBackground(new java.awt.Color(3, 169, 131));
        btnaddcategory.setFont(new java.awt.Font("SansSerif", 0, 18)); // NOI18N
        btnaddcategory.setText("ADD");
        btnaddcategory.setBorder(null);
        btnaddcategory.setBorderPainted(false);
        btnaddcategory.setContentAreaFilled(false);
        btnaddcategory.setFocusPainted(false);
        btnaddcategory.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                btnaddcategoryMouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                btnaddcategoryMouseExited(evt);
            }
        });
        btnaddcategory.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnaddcategoryActionPerformed(evt);
            }
        });
        ButtonOptionsPanel.add(btnaddcategory, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 250, 80, 30));

        btnupdatecategory.setBackground(new java.awt.Color(3, 169, 131));
        btnupdatecategory.setFont(new java.awt.Font("SansSerif", 0, 18)); // NOI18N
        btnupdatecategory.setText("UPDATE");
        btnupdatecategory.setBorder(null);
        btnupdatecategory.setBorderPainted(false);
        btnupdatecategory.setContentAreaFilled(false);
        btnupdatecategory.setFocusPainted(false);
        btnupdatecategory.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                btnupdatecategoryMouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                btnupdatecategoryMouseExited(evt);
            }
        });
        btnupdatecategory.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnupdatecategoryActionPerformed(evt);
            }
        });
        ButtonOptionsPanel.add(btnupdatecategory, new org.netbeans.lib.awtextra.AbsoluteConstraints(130, 250, 80, 30));

        btndeletecategory.setBackground(new java.awt.Color(3, 169, 131));
        btndeletecategory.setFont(new java.awt.Font("SansSerif", 0, 18)); // NOI18N
        btndeletecategory.setText("DELETE");
        btndeletecategory.setBorder(null);
        btndeletecategory.setBorderPainted(false);
        btndeletecategory.setContentAreaFilled(false);
        btndeletecategory.setFocusPainted(false);
        btndeletecategory.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                btndeletecategoryMouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                btndeletecategoryMouseExited(evt);
            }
        });
        btndeletecategory.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btndeletecategoryActionPerformed(evt);
            }
        });
        ButtonOptionsPanel.add(btndeletecategory, new org.netbeans.lib.awtextra.AbsoluteConstraints(240, 250, 80, 30));

        jLabel13.setFont(new java.awt.Font("SansSerif", 0, 18)); // NOI18N
        jLabel13.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel13.setText("CATEGORY");
        ButtonOptionsPanel.add(jLabel13, new org.netbeans.lib.awtextra.AbsoluteConstraints(60, 50, 200, 30));

        btnclearcategory.setBackground(new java.awt.Color(3, 169, 131));
        btnclearcategory.setFont(new java.awt.Font("SansSerif", 0, 18)); // NOI18N
        btnclearcategory.setText("CLEAR");
        btnclearcategory.setBorder(null);
        btnclearcategory.setBorderPainted(false);
        btnclearcategory.setContentAreaFilled(false);
        btnclearcategory.setFocusPainted(false);
        btnclearcategory.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                btnclearcategoryMouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                btnclearcategoryMouseExited(evt);
            }
        });
        btnclearcategory.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnclearcategoryActionPerformed(evt);
            }
        });
        ButtonOptionsPanel.add(btnclearcategory, new org.netbeans.lib.awtextra.AbsoluteConstraints(130, 300, 80, 30));

        CategoryRoom.add(ButtonOptionsPanel, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 350, 550));

        tblcategoryroom.setFont(new java.awt.Font("SansSerif", 0, 12)); // NOI18N
        tblcategoryroom.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "Category ID", "Room Category Name"
            }
        ) {
            Class[] types = new Class [] {
                java.lang.Integer.class, java.lang.String.class
            };
            boolean[] canEdit = new boolean [] {
                false, false
            };

            public Class getColumnClass(int columnIndex) {
                return types [columnIndex];
            }

            public boolean isCellEditable(int rowIndex, int columnIndex) {
                return canEdit [columnIndex];
            }
        });
        tblcategoryroom.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                tblcategoryroomMouseClicked(evt);
            }
        });
        jScrollPane2.setViewportView(tblcategoryroom);

        CategoryRoom.add(jScrollPane2, new org.netbeans.lib.awtextra.AbsoluteConstraints(650, 20, -1, -1));

        TabbedRoom.addTab("Room Category", CategoryRoom);

        RoomPanel.add(TabbedRoom, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 1370, 620));

        ContainerPanel.add(RoomPanel, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 1370, 620));

        StaffPanel.setBackground(new java.awt.Color(41, 150, 116));
        StaffPanel.setForeground(new java.awt.Color(255, 255, 255));
        StaffPanel.setFont(new java.awt.Font("Tahoma", 0, 12)); // NOI18N
        StaffPanel.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        TabbedStaff.setBackground(new java.awt.Color(41, 150, 116));
        TabbedStaff.setForeground(new java.awt.Color(255, 255, 255));
        TabbedStaff.setFont(new java.awt.Font("Tahoma", 0, 12)); // NOI18N
        TabbedStaff.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                TabbedStaffMouseClicked(evt);
            }
        });

        Staff.setBackground(new java.awt.Color(246, 246, 246));
        Staff.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jPanel2.setBackground(new java.awt.Color(234, 239, 241));
        jPanel2.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        sroomtextfield.setFont(new java.awt.Font("Tahoma", 0, 12)); // NOI18N
        sroomtextfield.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyReleased(java.awt.event.KeyEvent evt) {
                sroomtextfieldKeyReleased(evt);
            }
        });
        jPanel2.add(sroomtextfield, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 260, 220, 30));

        fntext.setFont(new java.awt.Font("Tahoma", 0, 12)); // NOI18N
        jPanel2.add(fntext, new org.netbeans.lib.awtextra.AbsoluteConstraints(110, 40, 180, 30));

        lntext.setFont(new java.awt.Font("Tahoma", 0, 12)); // NOI18N
        jPanel2.add(lntext, new org.netbeans.lib.awtextra.AbsoluteConstraints(110, 90, 180, 30));

        jLabel2.setFont(new java.awt.Font("Tahoma", 0, 12)); // NOI18N
        jLabel2.setHorizontalAlignment(javax.swing.SwingConstants.LEFT);
        jLabel2.setText("Work Position");
        jPanel2.add(jLabel2, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 200, 90, 20));

        jLabel3.setFont(new java.awt.Font("Tahoma", 0, 12)); // NOI18N
        jLabel3.setHorizontalAlignment(javax.swing.SwingConstants.LEFT);
        jLabel3.setText("Firstname");
        jPanel2.add(jLabel3, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 40, 70, 30));

        jLabel4.setFont(new java.awt.Font("Tahoma", 0, 12)); // NOI18N
        jLabel4.setHorizontalAlignment(javax.swing.SwingConstants.LEFT);
        jLabel4.setText("Lastname");
        jPanel2.add(jLabel4, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 90, 70, 30));

        jPanel2.add(workpositionbox, new org.netbeans.lib.awtextra.AbsoluteConstraints(110, 190, 180, 30));

        jLabel14.setFont(new java.awt.Font("Tahoma", 0, 12)); // NOI18N
        jLabel14.setHorizontalAlignment(javax.swing.SwingConstants.LEFT);
        jLabel14.setText("Middle Name");
        jPanel2.add(jLabel14, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 140, 70, 20));

        jLabel15.setFont(new java.awt.Font("Tahoma", 0, 12)); // NOI18N
        jLabel15.setHorizontalAlignment(javax.swing.SwingConstants.LEFT);
        jLabel15.setText("Room Name");
        jPanel2.add(jLabel15, new org.netbeans.lib.awtextra.AbsoluteConstraints(50, 240, 70, 20));

        mntext.setFont(new java.awt.Font("Tahoma", 0, 12)); // NOI18N
        jPanel2.add(mntext, new org.netbeans.lib.awtextra.AbsoluteConstraints(110, 130, 180, 30));

        jLabel16.setFont(new java.awt.Font("Tahoma", 0, 12)); // NOI18N
        jLabel16.setHorizontalAlignment(javax.swing.SwingConstants.LEFT);
        jLabel16.setText("Floor");
        jPanel2.add(jLabel16, new org.netbeans.lib.awtextra.AbsoluteConstraints(290, 240, 70, 20));

        TextfieldFloor.setEnabled(false);
        jPanel2.add(TextfieldFloor, new org.netbeans.lib.awtextra.AbsoluteConstraints(260, 260, 150, 30));

        btnDeleteStaff.setFont(new java.awt.Font("SansSerif", 0, 18)); // NOI18N
        btnDeleteStaff.setText("DELETE");
        btnDeleteStaff.setBorderPainted(false);
        btnDeleteStaff.setContentAreaFilled(false);
        btnDeleteStaff.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                btnDeleteStaffMouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                btnDeleteStaffMouseExited(evt);
            }
        });
        btnDeleteStaff.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnDeleteStaffActionPerformed(evt);
            }
        });
        jPanel2.add(btnDeleteStaff, new org.netbeans.lib.awtextra.AbsoluteConstraints(250, 430, 110, 30));

        btnAddStaff.setFont(new java.awt.Font("SansSerif", 0, 18)); // NOI18N
        btnAddStaff.setText("ADD");
        btnAddStaff.setBorderPainted(false);
        btnAddStaff.setContentAreaFilled(false);
        btnAddStaff.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                btnAddStaffMouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                btnAddStaffMouseExited(evt);
            }
        });
        btnAddStaff.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnAddStaffActionPerformed(evt);
            }
        });
        jPanel2.add(btnAddStaff, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 430, 110, 30));

        btnClearStaff.setFont(new java.awt.Font("SansSerif", 0, 18)); // NOI18N
        btnClearStaff.setText("CLEAR");
        btnClearStaff.setBorderPainted(false);
        btnClearStaff.setContentAreaFilled(false);
        btnClearStaff.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                btnClearStaffMouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                btnClearStaffMouseExited(evt);
            }
        });
        btnClearStaff.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnClearStaffActionPerformed(evt);
            }
        });
        jPanel2.add(btnClearStaff, new org.netbeans.lib.awtextra.AbsoluteConstraints(140, 470, 110, 30));

        btnUpdateStaff.setFont(new java.awt.Font("SansSerif", 0, 18)); // NOI18N
        btnUpdateStaff.setText("UPDATE");
        btnUpdateStaff.setBorderPainted(false);
        btnUpdateStaff.setContentAreaFilled(false);
        btnUpdateStaff.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                btnUpdateStaffMouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                btnUpdateStaffMouseExited(evt);
            }
        });
        btnUpdateStaff.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnUpdateStaffActionPerformed(evt);
            }
        });
        jPanel2.add(btnUpdateStaff, new org.netbeans.lib.awtextra.AbsoluteConstraints(140, 430, 110, 30));

        tblsearchroom.setFont(new java.awt.Font("Tahoma", 0, 12)); // NOI18N
        tblsearchroom.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "Room Name", "Floor"
            }
        ) {
            Class[] types = new Class [] {
                java.lang.String.class, java.lang.String.class
            };
            boolean[] canEdit = new boolean [] {
                false, false
            };

            public Class getColumnClass(int columnIndex) {
                return types [columnIndex];
            }

            public boolean isCellEditable(int rowIndex, int columnIndex) {
                return canEdit [columnIndex];
            }
        });
        tblsearchroom.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                tblsearchroomMouseClicked(evt);
            }
        });
        tblsearchpane.setViewportView(tblsearchroom);

        jPanel2.add(tblsearchpane, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 300, 370, 120));

        jLabel17.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        jLabel17.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel17.setText("STAFF FILL UP FORM");
        jPanel2.add(jLabel17, new org.netbeans.lib.awtextra.AbsoluteConstraints(50, 0, 300, 30));

        Staff.add(jPanel2, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 440, 590));

        tblStaff.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "Staff ID", "Firstname", "Lastname", "Middle Name", "Work Position", "Room Name", "Floor "
            }
        ) {
            Class[] types = new Class [] {
                java.lang.String.class, java.lang.String.class, java.lang.String.class, java.lang.String.class, java.lang.String.class, java.lang.Object.class, java.lang.String.class
            };
            boolean[] canEdit = new boolean [] {
                false, false, false, false, false, false, false
            };

            public Class getColumnClass(int columnIndex) {
                return types [columnIndex];
            }

            public boolean isCellEditable(int rowIndex, int columnIndex) {
                return canEdit [columnIndex];
            }
        });
        tblStaff.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                tblStaffMouseClicked(evt);
            }
        });
        jScrollPane4.setViewportView(tblStaff);

        Staff.add(jScrollPane4, new org.netbeans.lib.awtextra.AbsoluteConstraints(510, 30, 790, 510));

        TabbedStaff.addTab("Staff", Staff);

        StaffCategory.setBackground(new java.awt.Color(246, 246, 246));
        StaffCategory.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jPanel3.setBackground(new java.awt.Color(234, 239, 241));

        TextfieldPosition.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                TextfieldPositionActionPerformed(evt);
            }
        });

        jLabel18.setText("Work Position");

        btnDeleteStaff1.setFont(new java.awt.Font("SansSerif", 0, 18)); // NOI18N
        btnDeleteStaff1.setText("DELETE");
        btnDeleteStaff1.setBorderPainted(false);
        btnDeleteStaff1.setContentAreaFilled(false);
        btnDeleteStaff1.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                btnDeleteStaff1MouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                btnDeleteStaff1MouseExited(evt);
            }
        });
        btnDeleteStaff1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnDeleteStaff1ActionPerformed(evt);
            }
        });

        btnAddStaff1.setFont(new java.awt.Font("SansSerif", 0, 18)); // NOI18N
        btnAddStaff1.setText("ADD");
        btnAddStaff1.setBorderPainted(false);
        btnAddStaff1.setContentAreaFilled(false);
        btnAddStaff1.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                btnAddStaff1MouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                btnAddStaff1MouseExited(evt);
            }
        });
        btnAddStaff1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnAddStaff1ActionPerformed(evt);
            }
        });

        btnClearStaff1.setFont(new java.awt.Font("SansSerif", 0, 18)); // NOI18N
        btnClearStaff1.setText("CLEAR");
        btnClearStaff1.setBorderPainted(false);
        btnClearStaff1.setContentAreaFilled(false);
        btnClearStaff1.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                btnClearStaff1MouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                btnClearStaff1MouseExited(evt);
            }
        });

        btnUpdateStaff1.setFont(new java.awt.Font("SansSerif", 0, 18)); // NOI18N
        btnUpdateStaff1.setText("UPDATE");
        btnUpdateStaff1.setBorderPainted(false);
        btnUpdateStaff1.setContentAreaFilled(false);
        btnUpdateStaff1.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                btnUpdateStaff1MouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                btnUpdateStaff1MouseExited(evt);
            }
        });
        btnUpdateStaff1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnUpdateStaff1ActionPerformed(evt);
            }
        });

        jLabel19.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        jLabel19.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel19.setText("WORK POSITION FORM");

        javax.swing.GroupLayout jPanel3Layout = new javax.swing.GroupLayout(jPanel3);
        jPanel3.setLayout(jPanel3Layout);
        jPanel3Layout.setHorizontalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel3Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel18, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addGap(18, 18, 18)
                .addComponent(TextfieldPosition, javax.swing.GroupLayout.PREFERRED_SIZE, 201, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(91, 91, 91))
            .addGroup(jPanel3Layout.createSequentialGroup()
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel3Layout.createSequentialGroup()
                        .addGap(30, 30, 30)
                        .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                            .addComponent(btnClearStaff1)
                            .addGroup(jPanel3Layout.createSequentialGroup()
                                .addComponent(btnAddStaff1)
                                .addGap(18, 18, 18)
                                .addComponent(btnUpdateStaff1)))
                        .addGap(18, 18, 18)
                        .addComponent(btnDeleteStaff1))
                    .addGroup(jPanel3Layout.createSequentialGroup()
                        .addGap(77, 77, 77)
                        .addComponent(jLabel19)))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        jPanel3Layout.setVerticalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel3Layout.createSequentialGroup()
                .addGap(24, 24, 24)
                .addComponent(jLabel19)
                .addGap(68, 68, 68)
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(TextfieldPosition)
                    .addComponent(jLabel18, javax.swing.GroupLayout.PREFERRED_SIZE, 37, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(75, 75, 75)
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(btnAddStaff1)
                    .addComponent(btnUpdateStaff1)
                    .addComponent(btnDeleteStaff1))
                .addGap(18, 18, 18)
                .addComponent(btnClearStaff1)
                .addContainerGap(280, Short.MAX_VALUE))
        );

        StaffCategory.add(jPanel3, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 380, 590));

        tblStaffCategory.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "Work Position ID", "Work Position"
            }
        ) {
            Class[] types = new Class [] {
                java.lang.String.class, java.lang.String.class
            };
            boolean[] canEdit = new boolean [] {
                false, false
            };

            public Class getColumnClass(int columnIndex) {
                return types [columnIndex];
            }

            public boolean isCellEditable(int rowIndex, int columnIndex) {
                return canEdit [columnIndex];
            }
        });
        tblStaffCategory.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                tblStaffCategoryMouseClicked(evt);
            }
        });
        jScrollPane5.setViewportView(tblStaffCategory);

        StaffCategory.add(jScrollPane5, new org.netbeans.lib.awtextra.AbsoluteConstraints(660, 60, -1, -1));

        TabbedStaff.addTab("Staff Category", StaffCategory);

        StaffPanel.add(TabbedStaff, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 1370, 620));

        ContainerPanel.add(StaffPanel, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 1370, 620));

        TransactionPanel.setBackground(new java.awt.Color(41, 150, 116));
        TransactionPanel.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        TabbedTransaction.setBackground(new java.awt.Color(41, 150, 116));
        TabbedTransaction.setForeground(new java.awt.Color(255, 255, 255));
        TabbedTransaction.setFont(new java.awt.Font("Tahoma", 0, 12)); // NOI18N

        Transaction.setBackground(new java.awt.Color(246, 246, 246));
        Transaction.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jPanel4.setBackground(new java.awt.Color(234, 239, 241));
        jPanel4.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        TransactionTitleTextfield.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                TransactionTitleTextfieldActionPerformed(evt);
            }
        });
        jPanel4.add(TransactionTitleTextfield, new org.netbeans.lib.awtextra.AbsoluteConstraints(85, 114, 241, 37));

        jLabel20.setText("Room");
        jPanel4.add(jLabel20, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 170, 60, 37));

        btndeletetranstitle.setFont(new java.awt.Font("SansSerif", 0, 18)); // NOI18N
        btndeletetranstitle.setText("DELETE");
        btndeletetranstitle.setBorderPainted(false);
        btndeletetranstitle.setContentAreaFilled(false);
        btndeletetranstitle.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                btndeletetranstitleMouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                btndeletetranstitleMouseExited(evt);
            }
        });
        btndeletetranstitle.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btndeletetranstitleActionPerformed(evt);
            }
        });
        jPanel4.add(btndeletetranstitle, new org.netbeans.lib.awtextra.AbsoluteConstraints(240, 340, -1, -1));

        btnaddtranstitle.setFont(new java.awt.Font("SansSerif", 0, 18)); // NOI18N
        btnaddtranstitle.setText("ADD");
        btnaddtranstitle.setBorderPainted(false);
        btnaddtranstitle.setContentAreaFilled(false);
        btnaddtranstitle.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                btnaddtranstitleMouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                btnaddtranstitleMouseExited(evt);
            }
        });
        btnaddtranstitle.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnaddtranstitleActionPerformed(evt);
            }
        });
        jPanel4.add(btnaddtranstitle, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 340, -1, -1));

        btncleartrans.setFont(new java.awt.Font("SansSerif", 0, 18)); // NOI18N
        btncleartrans.setText("CLEAR");
        btncleartrans.setBorderPainted(false);
        btncleartrans.setContentAreaFilled(false);
        btncleartrans.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                btncleartransMouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                btncleartransMouseExited(evt);
            }
        });
        btncleartrans.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btncleartransActionPerformed(evt);
            }
        });
        jPanel4.add(btncleartrans, new org.netbeans.lib.awtextra.AbsoluteConstraints(130, 390, -1, -1));

        btnupdatetranstitle.setFont(new java.awt.Font("SansSerif", 0, 18)); // NOI18N
        btnupdatetranstitle.setText("UPDATE");
        btnupdatetranstitle.setBorderPainted(false);
        btnupdatetranstitle.setContentAreaFilled(false);
        btnupdatetranstitle.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                btnupdatetranstitleMouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                btnupdatetranstitleMouseExited(evt);
            }
        });
        btnupdatetranstitle.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnupdatetranstitleActionPerformed(evt);
            }
        });
        jPanel4.add(btnupdatetranstitle, new org.netbeans.lib.awtextra.AbsoluteConstraints(120, 340, -1, -1));

        jLabel21.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        jLabel21.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel21.setText("TRANSACTION TITLE FORM");
        jPanel4.add(jLabel21, new org.netbeans.lib.awtextra.AbsoluteConstraints(66, 24, 239, -1));

        RoomtranTextfield.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                RoomtranTextfieldActionPerformed(evt);
            }
        });
        RoomtranTextfield.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyReleased(java.awt.event.KeyEvent evt) {
                RoomtranTextfieldKeyReleased(evt);
            }
        });
        jPanel4.add(RoomtranTextfield, new org.netbeans.lib.awtextra.AbsoluteConstraints(85, 169, 241, 37));

        tblsearchroomtrans.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "Room"
            }
        ) {
            Class[] types = new Class [] {
                java.lang.String.class
            };
            boolean[] canEdit = new boolean [] {
                false
            };

            public Class getColumnClass(int columnIndex) {
                return types [columnIndex];
            }

            public boolean isCellEditable(int rowIndex, int columnIndex) {
                return canEdit [columnIndex];
            }
        });
        tblsearchroomtrans.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                tblsearchroomtransMouseClicked(evt);
            }
        });
        tblroomtranspane.setViewportView(tblsearchroomtrans);

        jPanel4.add(tblroomtranspane, new org.netbeans.lib.awtextra.AbsoluteConstraints(80, 210, 250, 110));

        jLabel22.setText("Title");
        jPanel4.add(jLabel22, new org.netbeans.lib.awtextra.AbsoluteConstraints(21, 114, 60, 37));

        Transaction.add(jPanel4, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 380, 590));

        tbltransactiontitle.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "Transaction ID", "Title", "Room"
            }
        ) {
            Class[] types = new Class [] {
                java.lang.String.class, java.lang.String.class, java.lang.String.class
            };
            boolean[] canEdit = new boolean [] {
                false, false, false
            };

            public Class getColumnClass(int columnIndex) {
                return types [columnIndex];
            }

            public boolean isCellEditable(int rowIndex, int columnIndex) {
                return canEdit [columnIndex];
            }
        });
        tbltransactiontitle.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                tbltransactiontitleMouseClicked(evt);
            }
        });
        jScrollPane3.setViewportView(tbltransactiontitle);

        Transaction.add(jScrollPane3, new org.netbeans.lib.awtextra.AbsoluteConstraints(620, 50, -1, -1));

        TabbedTransaction.addTab("Transaction", Transaction);

        javax.swing.GroupLayout TransactionProcedureLayout = new javax.swing.GroupLayout(TransactionProcedure);
        TransactionProcedure.setLayout(TransactionProcedureLayout);
        TransactionProcedureLayout.setHorizontalGroup(
            TransactionProcedureLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 1365, Short.MAX_VALUE)
        );
        TransactionProcedureLayout.setVerticalGroup(
            TransactionProcedureLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 591, Short.MAX_VALUE)
        );

        TabbedTransaction.addTab("Transaction Procedures", TransactionProcedure);

        TransactionPanel.add(TabbedTransaction, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 1370, 620));

        ContainerPanel.add(TransactionPanel, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 1370, 620));

        getContentPane().add(ContainerPanel, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 120, 1370, 620));

        pack();
        setLocationRelativeTo(null);
    }// </editor-fold>//GEN-END:initComponents

    private void btnRoomActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnRoomActionPerformed
        RoomPanel.setVisible(true);
         TabbedRoom.setVisible(true);
         
        GeneralPanel.setVisible(false);
        StaffPanel.setVisible(false);
        TabbedStaff.setVisible(false);
        titlelabel.setText("Room");
         TransactionPanel.setVisible(false);
         TabbedTransaction.setVisible(false);
      whattable=null;
       getroom();
       getcatbox();
       getfloorbox();
       getcategory();
       tableselector();
      
    }//GEN-LAST:event_btnRoomActionPerformed

    private void btnGeneralActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnGeneralActionPerformed
        GeneralPanel.setVisible(true);
        titlelabel.setText("General");
        
        RoomPanel.setVisible(false);
        TabbedRoom.setVisible(false);
        StaffPanel.setVisible(false);
        TabbedStaff.setVisible(false);
        TransactionPanel.setVisible(false);
        TabbedTransaction.setVisible(false);
       getallnums();
         tableselector();
    }//GEN-LAST:event_btnGeneralActionPerformed

    private void TabbedRoomMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_TabbedRoomMouseClicked
            getcatbox();
            getfloorbox();
            getroom();
            tableselector();
    }//GEN-LAST:event_TabbedRoomMouseClicked

    private void btnGeneralMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_btnGeneralMouseClicked
             btnGeneral.setForeground(Color.WHITE);
             btnRoom.setForeground(new Color(204,204,204));
              btnStaff.setForeground(new Color(204,204,204));
               btnTransaction.setForeground(new Color(204,204,204));
    }//GEN-LAST:event_btnGeneralMouseClicked

    private void btnnumStaffActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnnumStaffActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_btnnumStaffActionPerformed

    private void btnnumStaffpositionActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnnumStaffpositionActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_btnnumStaffpositionActionPerformed

    private void btnnumroomActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnnumroomActionPerformed
        System.out.println("Room Clicked ");
    }//GEN-LAST:event_btnnumroomActionPerformed

    private void btnRoomMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_btnRoomMouseClicked
      btnRoom.setForeground(Color.WHITE);
      btnGeneral.setForeground(new Color(204,204,204));
      btnStaff.setForeground(new Color(204,204,204));
       btnTransaction.setForeground(new Color(204,204,204));
    }//GEN-LAST:event_btnRoomMouseClicked

    private void btnRoomaddMouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_btnRoomaddMouseEntered
        // TODO add your handling code here:
        btnRoomadd.setContentAreaFilled(true);
        btnRoomadd.setBackground(new Color(3, 169, 131));
    }//GEN-LAST:event_btnRoomaddMouseEntered

    private void btnRoomaddMouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_btnRoomaddMouseExited
        // TODO add your handling code here:
        btnRoomadd.setContentAreaFilled(false);
    }//GEN-LAST:event_btnRoomaddMouseExited

    private void btnRoomaddActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnRoomaddActionPerformed
if(!RoomTextfield.getText().isEmpty() && CategoryRoomBox.getSelectedItem() != null && FloorBox.getSelectedItem() != null){
        try {
            String rname = RoomTextfield.getText().trim();
            Class.forName("com.mysql.jdbc.Driver");
            con = DriverManager.getConnection("jdbc:mysql://localhost:3306/systemdatabase?zeroDateTimeBehavior=convertToNull", "root", "");
            String rrname = rname.replace("'", "''");
            String ss= "SELECT * FROM room WHERE roomname='"+ rrname  +"';";

            st = con.createStatement();
            java.sql.ResultSet rs = st.executeQuery(ss);

            if (!rs.first()){
               
                    SaveRoom();
                    getroom();
                    s=null;

               
            }

            else{
                alert("Room Already Exist");
            }

        }catch (ClassNotFoundException | SQLException ex) {
            Logger.getLogger(AdminDashboard.class.getName()).log(Level.SEVERE, null, ex);
        }
}
else{
    alert("Fill up the missing Form");
}
             tableselector();
    }//GEN-LAST:event_btnRoomaddActionPerformed

    private void btnRoomupdateMouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_btnRoomupdateMouseEntered
        // TODO add your handling code here:
        btnRoomupdate.setContentAreaFilled(true);
        btnRoomupdate.setBackground(new Color(3, 169, 131));
    }//GEN-LAST:event_btnRoomupdateMouseEntered

    private void btnRoomupdateMouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_btnRoomupdateMouseExited
        // TODO add your handling code here:
        btnRoomupdate.setContentAreaFilled(false);
    }//GEN-LAST:event_btnRoomupdateMouseExited

    private void btnRoomupdateActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnRoomupdateActionPerformed
        if (tblroom.getSelectedRowCount() == 0) {
            alert("Please select a row you want to update");
        } else if (!RoomTextfield.getText().isEmpty() && CategoryRoomBox.getSelectedItem() != null && FloorBox.getSelectedItem() != null) {
            if (s == null) {

                int i = tblroom.getSelectedRow();
                TableModel tblmodel = tblroom.getModel();

                String title = tblmodel.getValueAt(i, 1).toString().trim();
                String abb = tblmodel.getValueAt(i, 2).toString().trim();
                String cat = tblmodel.getValueAt(i, 3).toString().trim();
                String fl = tblmodel.getValueAt(i, 4).toString().trim();

                String newroomname = RoomTextfield.getText().trim();
                String newcat = CategoryRoomBox.getSelectedItem().toString().trim().replace("'", "''");
                String newfloor = FloorBox.getSelectedItem().toString().trim();
                String roomname = newroomname.replace("'", "''");
                String abr = abbtext.getText().trim().replace("'", "''");

                int r = tblroom.getSelectedRow();
                String rid = String.valueOf(String.valueOf(tblroom.getValueAt(r, 0)));

                try {
                    Class.forName("com.mysql.jdbc.Driver");
                    con = DriverManager.getConnection("jdbc:mysql://localhost:3306/systemdatabase?zeroDateTimeBehavior=convertToNull", "root", "");

                    String ss = "SELECT * FROM room WHERE roomname = '" + newroomname + "';";

                    st = con.createStatement();
                    ResultSet rs = st.executeQuery(ss);

                    if (rs.first()) {
                       
                        if(title.equals(newroomname) && abb.equals(abr) && cat.equals(newcat) && fl.equals(newfloor)){
                            alert("Nothing is updated");
                        }
                        else{
                             alert("Room already exist");
                        }
   
                    } else {

                        getflrid(newfloor);
                        updateroom(roomname, abr, newcat, flrid, rid);
                        getroom();
                        clear();
                    }

                } catch (ClassNotFoundException | SQLException ex) {
                    Logger.getLogger(AdminDashboard.class.getName()).log(Level.SEVERE, null, ex);
                }

            }
        } else {
            alert("Please Fill up the missing details");
        }
        tableselector();
    }//GEN-LAST:event_btnRoomupdateActionPerformed

    private void btnRoomdeleteMouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_btnRoomdeleteMouseEntered
        // TODO add your handling code here:
        btnRoomdelete.setContentAreaFilled(true);
        btnRoomdelete.setBackground(new Color(1, 169, 131));
    }//GEN-LAST:event_btnRoomdeleteMouseEntered

    private void btnRoomdeleteMouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_btnRoomdeleteMouseExited
        // TODO add your handling code here:
        btnRoomdelete.setContentAreaFilled(false);
    }//GEN-LAST:event_btnRoomdeleteMouseExited

    private void btnRoomdeleteActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnRoomdeleteActionPerformed
        int i = tblroom.getSelectedRow();
        
        if (i >= 0) {
            int option = JOptionPane.showConfirmDialog(rootPane,
                "Are you sure you want to Delete?", "Delete confirmation", JOptionPane.YES_NO_OPTION);
            if (option == 0) {
                TableModel model = tblroom.getModel();

                String rid = model.getValueAt(i, 0).toString();
                if (tblroom.getSelectedRows().length == 1) {
                    delete(rid);
                    getroom();

                }
            }
        } else {
            alert("Please select a row to delete");
        } tableselector();
        btnRoomadd.setEnabled(true);
    }//GEN-LAST:event_btnRoomdeleteActionPerformed

    private void btnResetMouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_btnResetMouseEntered
        btnReset.setContentAreaFilled(true);
        btnReset.setBackground(new Color(1, 169, 131));
    }//GEN-LAST:event_btnResetMouseEntered

    private void btnResetMouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_btnResetMouseExited
        btnReset.setContentAreaFilled(false);
    }//GEN-LAST:event_btnResetMouseExited

    private void btnResetActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnResetActionPerformed
        clear();
         tableselector();
           
    }//GEN-LAST:event_btnResetActionPerformed

    private void RoomTextfieldActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_RoomTextfieldActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_RoomTextfieldActionPerformed

    private void tblroomMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_tblroomMouseClicked
      
           
        int i = tblroom.getSelectedRow();
        TableModel model = tblroom.getModel();

     if(model.getValueAt(i, 2).toString() != "NA"){
         RoomTextfield.setText(model.getValueAt(i, 1).toString());
         abbtext.setText(model.getValueAt(i, 2).toString());
            CategoryRoomBox.setSelectedItem(model.getValueAt(i, 3).toString());  
             FloorBox.setSelectedItem(model.getValueAt(i, 4).toString());
     }
     else{
           RoomTextfield.setText(model.getValueAt(i, 1).toString());
     
            CategoryRoomBox.setSelectedIndex(-1);
             FloorBox.setSelectedItem(model.getValueAt(i, 3).toString());
     }
    }//GEN-LAST:event_tblroomMouseClicked

    private void btnaddcategoryActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnaddcategoryActionPerformed
if(CategoryTextfield.getText().length() != 0){
        try {
            String cname = CategoryTextfield.getText();
            Class.forName("com.mysql.jdbc.Driver");
            con = DriverManager.getConnection("jdbc:mysql://localhost:3306/systemdatabase?zeroDateTimeBehavior=convertToNull", "root", "");
            String rrname = cname.replace("'", "''");
            String ss= "SELECT * FROM roomcategory WHERE roomcategoryname='"+ rrname  +"';";

            st = con.createStatement();
            java.sql.ResultSet rs = st.executeQuery(ss);

            if (!rs.first()) {

                try{
                    Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/systemdatabase?zeroDateTimeBehavior=convertToNull", "root", "");
                    PreparedStatement ps = con.prepareStatement("insert into roomcategory(roomcategoryname) values(?)");

                    ps.setString(1, CategoryTextfield.getText().trim());

                    if(ps.executeUpdate() == 1)
                    {
                        JOptionPane.showMessageDialog(null, "CATEGORY INSERTED");
                        getcategory();
                        CategoryTextfield.setText("");
                    }else{
                        JOptionPane.showMessageDialog(null, "CATEGORY NOT INSERTED");
                        CategoryTextfield.setText("");
                    }

                }catch(Exception ex){
                    ex.printStackTrace();
                }

            }
            else{
                alert("FAILED TO ADD ROOM CATEGORY");
            }
        }catch (ClassNotFoundException | SQLException ex) {
            Logger.getLogger(AdminDashboard.class.getName()).log(Level.SEVERE, null, ex);
        }
}
else{
    alert("Please fill up the missing details");
}
getcategory();
    }//GEN-LAST:event_btnaddcategoryActionPerformed

    private void btnupdatecategoryActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnupdatecategoryActionPerformed
if(tblcategoryroom.getSelectedRowCount() != 0){
        int r = tblcategoryroom.getSelectedRow();
        String rid = String.valueOf(String.valueOf(tblcategoryroom.getValueAt(r, 0)));

        try {
            Class.forName("com.mysql.jdbc.Driver");
            con = DriverManager.getConnection("jdbc:mysql://localhost:3306/systemdatabase?zeroDateTimeBehavior=convertToNull", "root", "");

            String ss= "SELECT * FROM roomcategory WHERE roomcategoryid !='"+rid+"';";

            st = con.createStatement();
            java.sql.ResultSet rs = st.executeQuery(ss);

            if (rs.first()) {

                try {
                    String UpdateQuery = "UPDATE roomcategory SET roomcategoryname = ?  WHERE roomcategoryid = ?";

                    String newcat = CategoryTextfield.getText().trim();
                    String catname = newcat.replace("'", "''");
                    PreparedStatement ps = con.prepareStatement(UpdateQuery);
                    ps.setString(1, catname);
                    ps.setString(2, rid);

                    if(ps.executeUpdate() == 1)
                    {
                        JOptionPane.showMessageDialog(null, "Category Updated");
                        CategoryTextfield.setText("");
                        getcategory();
                    }else{
                        JOptionPane.showMessageDialog(null, "Category Not Updated");
                    }

                } catch (Exception ex) {
                    Logger.getLogger(AdminDashboard.class.getName()).log(Level.SEVERE, null, ex);
                }
            }

        }catch (ClassNotFoundException | SQLException ex) {
            Logger.getLogger(AdminDashboard.class.getName()).log(Level.SEVERE, null, ex);
        }
}
else{
    alert("Please select a row you want to update");
}
        getcategory();
    }//GEN-LAST:event_btnupdatecategoryActionPerformed

    private void btndeletecategoryActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btndeletecategoryActionPerformed
        int i = tblcategoryroom.getSelectedRow();
        if (i >= 0) {
            int option = JOptionPane.showConfirmDialog(rootPane,
                "Are you sure you want to Delete?", "Delete confirmation", JOptionPane.YES_NO_OPTION);
            if (option == 0) {
                TableModel model = tblcategoryroom.getModel();

                String rid = model.getValueAt(i, 0).toString();
                if (tblcategoryroom.getSelectedRows().length == 1) {

                    try {
                        Class.forName("com.mysql.jdbc.Driver");
                        con = DriverManager.getConnection("jdbc:mysql://localhost:3306/systemdatabase?zeroDateTimeBehavior=convertToNull", "root", "");
                        String sql = "DELETE FROM `roomcategory` WHERE roomcategoryid='" + rid + "'" ;
                        st = con.createStatement();
                        st.execute(sql);

                    } catch (ClassNotFoundException | SQLException ex) {
                        Logger.getLogger(AdminDashboard.class.getName()).log(Level.SEVERE, null, ex);
                    }

                }
            }
        } else {
            alert("Please select a row to delete");
        }

        getcategory();

    }//GEN-LAST:event_btndeletecategoryActionPerformed

    private void tblcategoryroomMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_tblcategoryroomMouseClicked
        int i = tblcategoryroom.getSelectedRow();
        TableModel model = tblcategoryroom.getModel();

        CategoryTextfield.setText(model.getValueAt(i, 1).toString());

    }//GEN-LAST:event_tblcategoryroomMouseClicked

    private void btnlogoutActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnlogoutActionPerformed
        // TODO add your handling code here:
        this.dispose();
        UI loginscreen = new UI();
        loginscreen.setVisible(true);
    }//GEN-LAST:event_btnlogoutActionPerformed

    private void btnStaffMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_btnStaffMouseClicked
        btnStaff.setForeground(Color.WHITE);
     btnRoom.setForeground(new Color(204,204,204));
      btnGeneral.setForeground(new Color(204,204,204));
      btnTransaction.setForeground(new Color(204,204,204));
    }//GEN-LAST:event_btnStaffMouseClicked

    private void btnStaffActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnStaffActionPerformed
        StaffPanel.setVisible(true);
        TabbedStaff.setVisible(true);
         titlelabel.setText("Staff");
         
        RoomPanel.setVisible(false);
        GeneralPanel.setVisible(false);
         TransactionPanel.setVisible(false);
         TabbedTransaction.setVisible(false);
          getstaffworkposition();
          getworkpositionbox();
           getallStaff(); 
      tblsearchpane.setVisible(false);
        
      tableselector();
      

    }//GEN-LAST:event_btnStaffActionPerformed

    private void btnAddStaffMouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_btnAddStaffMouseEntered
        btnAddStaff.setContentAreaFilled(true);
        btnAddStaff.setBackground(new Color(3, 169, 131));
    }//GEN-LAST:event_btnAddStaffMouseEntered

    private void btnAddStaffMouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_btnAddStaffMouseExited
       btnAddStaff.setContentAreaFilled(false);
    }//GEN-LAST:event_btnAddStaffMouseExited

    private void btnUpdateStaffMouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_btnUpdateStaffMouseEntered
         btnUpdateStaff.setContentAreaFilled(true);
        btnUpdateStaff.setBackground(new Color(3, 169, 131));
    }//GEN-LAST:event_btnUpdateStaffMouseEntered

    private void btnUpdateStaffMouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_btnUpdateStaffMouseExited
       btnUpdateStaff.setContentAreaFilled(false);
    }//GEN-LAST:event_btnUpdateStaffMouseExited

    private void btnDeleteStaffMouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_btnDeleteStaffMouseEntered
         btnDeleteStaff.setContentAreaFilled(true);
        btnDeleteStaff.setBackground(new Color(3, 169, 131));
    }//GEN-LAST:event_btnDeleteStaffMouseEntered

    private void btnDeleteStaffMouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_btnDeleteStaffMouseExited
      btnDeleteStaff.setContentAreaFilled(false);
    }//GEN-LAST:event_btnDeleteStaffMouseExited

    private void btnClearStaffMouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_btnClearStaffMouseEntered
        btnClearStaff.setContentAreaFilled(true);
        btnClearStaff.setBackground(new Color(3, 169, 131));
    }//GEN-LAST:event_btnClearStaffMouseEntered

    private void btnClearStaffMouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_btnClearStaffMouseExited
        btnClearStaff.setContentAreaFilled(false);
    }//GEN-LAST:event_btnClearStaffMouseExited

    private void btnaddcategoryMouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_btnaddcategoryMouseEntered
       btnaddcategory.setContentAreaFilled(true);
        btnaddcategory.setBackground(new Color(3, 169, 131));
    }//GEN-LAST:event_btnaddcategoryMouseEntered

    private void btnaddcategoryMouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_btnaddcategoryMouseExited
        btnaddcategory.setContentAreaFilled(false);
    }//GEN-LAST:event_btnaddcategoryMouseExited

    private void btnupdatecategoryMouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_btnupdatecategoryMouseEntered
         btnupdatecategory.setContentAreaFilled(true);
        btnupdatecategory.setBackground(new Color(3, 169, 131));
    }//GEN-LAST:event_btnupdatecategoryMouseEntered

    private void btnupdatecategoryMouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_btnupdatecategoryMouseExited
        btnupdatecategory.setContentAreaFilled(false);
    }//GEN-LAST:event_btnupdatecategoryMouseExited

    private void btndeletecategoryMouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_btndeletecategoryMouseEntered
       btndeletecategory.setContentAreaFilled(true);
       btndeletecategory.setBackground(new Color(3, 169, 131));
    }//GEN-LAST:event_btndeletecategoryMouseEntered

    private void btndeletecategoryMouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_btndeletecategoryMouseExited
         btndeletecategory.setContentAreaFilled(false);
    }//GEN-LAST:event_btndeletecategoryMouseExited

    private void TextfieldPositionActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_TextfieldPositionActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_TextfieldPositionActionPerformed

    private void btnDeleteStaff1MouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_btnDeleteStaff1MouseEntered
         btnDeleteStaff1.setContentAreaFilled(true);
       btnDeleteStaff1.setBackground(new Color(3, 169, 131));
    }//GEN-LAST:event_btnDeleteStaff1MouseEntered

    private void btnDeleteStaff1MouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_btnDeleteStaff1MouseExited
        btnDeleteStaff1.setContentAreaFilled(false);
    }//GEN-LAST:event_btnDeleteStaff1MouseExited

    private void btnAddStaff1MouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_btnAddStaff1MouseEntered
       btnAddStaff1.setContentAreaFilled(true);
       btnAddStaff1.setBackground(new Color(3, 169, 131));
        
    }//GEN-LAST:event_btnAddStaff1MouseEntered

    private void btnAddStaff1MouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_btnAddStaff1MouseExited
       btnAddStaff1.setContentAreaFilled(false);
    }//GEN-LAST:event_btnAddStaff1MouseExited

    private void btnClearStaff1MouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_btnClearStaff1MouseEntered
      btnClearStaff1.setContentAreaFilled(true);
       btnClearStaff1.setBackground(new Color(3, 169, 131));
    }//GEN-LAST:event_btnClearStaff1MouseEntered

    private void btnClearStaff1MouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_btnClearStaff1MouseExited
        btnClearStaff1.setContentAreaFilled(false);
    }//GEN-LAST:event_btnClearStaff1MouseExited

    private void btnUpdateStaff1MouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_btnUpdateStaff1MouseEntered
       btnUpdateStaff1.setContentAreaFilled(true);
       btnUpdateStaff1.setBackground(new Color(3, 169, 131));
    }//GEN-LAST:event_btnUpdateStaff1MouseEntered

    private void btnUpdateStaff1MouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_btnUpdateStaff1MouseExited
        btnUpdateStaff1.setContentAreaFilled(false);
    }//GEN-LAST:event_btnUpdateStaff1MouseExited

    private void btnAddStaff1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnAddStaff1ActionPerformed
        if(!TextfieldPosition.getText().isEmpty())  
        {
        try {
            String cname = TextfieldPosition.getText();
            Class.forName("com.mysql.jdbc.Driver");
            con = DriverManager.getConnection("jdbc:mysql://localhost:3306/systemdatabase?zeroDateTimeBehavior=convertToNull", "root", "");
            String swname = cname.replace("'", "''");
            String ss= "SELECT * FROM staffworkposition WHERE staffworkpositionname='"+ swname  +"';";

            st = con.createStatement();
            java.sql.ResultSet rs = st.executeQuery(ss);

            if (!rs.first()) {

                try{
                    Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/systemdatabase?zeroDateTimeBehavior=convertToNull", "root", "");
                    PreparedStatement ps = con.prepareStatement("insert into staffworkposition(staffworkpositionname) values(?)");

                    ps.setString(1, TextfieldPosition.getText().trim());

                    if(ps.executeUpdate() == 1)
                    {
                        JOptionPane.showMessageDialog(null, "NEW STAFF WORK POSITION INSERTED");
                        getcategory();
                        TextfieldPosition.setText("");
                    }else{
                        JOptionPane.showMessageDialog(null, "STAFF WORK POSITION NOT INSERTED");
                        TextfieldPosition.setText("");
                    }

                }catch(Exception ex){
                    ex.printStackTrace();
                }

            }
            else{
                alert("FAILED TO ADD STAFF WORK POSITION");
            }
        }catch (ClassNotFoundException | SQLException ex) {
            Logger.getLogger(AdminDashboard.class.getName()).log(Level.SEVERE, null, ex);
        }
        }
        else{
            alert("Please fill up the missing details");
        }
        
                               tblStaffCategory.clearSelection();
                               getstaffworkposition();
    }//GEN-LAST:event_btnAddStaff1ActionPerformed

    private void btnUpdateStaff1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnUpdateStaff1ActionPerformed
  if(tblStaffCategory.getSelectedRowCount() != 1){
      alert("Please select a row you want to update");
  }
  else if(!TextfieldPosition.getText().isEmpty()){
        int r = tblStaffCategory.getSelectedRow();
        String rid = String.valueOf(String.valueOf(tblStaffCategory.getValueAt(r, 0)));
           System.out.println(rid);
              String staffw = TextfieldPosition.getText().trim();
        try {
            Class.forName("com.mysql.jdbc.Driver");
            con = DriverManager.getConnection("jdbc:mysql://localhost:3306/systemdatabase?zeroDateTimeBehavior=convertToNull", "root", "");

            String ss= "SELECT * FROM staffworkposition WHERE staffworkpositionname ='"+staffw+"';";

            st = con.createStatement();
            ResultSet rs = st.executeQuery(ss);

            if (!rs.first()) {

                try {
                    
                    String UpdateQuery = "UPDATE staffworkposition SET staffworkpositionname = ?  WHERE staffworkid = ?";

                 
                    String staffwork = staffw.replace("'", "''");
                    PreparedStatement ps = con.prepareStatement(UpdateQuery);
                    ps.setString(1, staffwork);
                    ps.setString(2, rid);

                    if(ps.executeUpdate() == 1)
                    {
                        JOptionPane.showMessageDialog(null, "Work Position Updated");
                        TextfieldPosition.setText("");
                    }else{
                        JOptionPane.showMessageDialog(null, "Work Position Not Updated");
                                              
                    }

                } catch (Exception ex) {
                    Logger.getLogger(AdminDashboard.class.getName()).log(Level.SEVERE, null, ex);
                }
            }
            else{
                 JOptionPane.showMessageDialog(null, "Work Position Already Exists");
            }

        }catch (ClassNotFoundException | SQLException ex) {
            Logger.getLogger(AdminDashboard.class.getName()).log(Level.SEVERE, null, ex);
        }
  }
  else{
      alert("Please fill up the missing details");
  }
                       tblStaffCategory.clearSelection();
                        getstaffworkposition();
    }//GEN-LAST:event_btnUpdateStaff1ActionPerformed

    private void btnDeleteStaff1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnDeleteStaff1ActionPerformed
         int i = tblStaffCategory.getSelectedRow();
        if (i >= 0) {
            int option = JOptionPane.showConfirmDialog(rootPane,
                "Are you sure you want to Delete?", "Delete confirmation", JOptionPane.YES_NO_OPTION);
            if (option == 0) {
                TableModel model = tblStaffCategory.getModel();

                String rid = model.getValueAt(i, 0).toString();
                if (tblStaffCategory.getSelectedRows().length == 1) {

                    try {
                        Class.forName("com.mysql.jdbc.Driver");
                        con = DriverManager.getConnection("jdbc:mysql://localhost:3306/systemdatabase?zeroDateTimeBehavior=convertToNull", "root", "");
                        String sql = "DELETE FROM `staffworkposition` WHERE staffworkid='" + rid + "'" ;
                        st = con.createStatement();
                        st.execute(sql);

                    } catch (ClassNotFoundException | SQLException ex) {
                        Logger.getLogger(AdminDashboard.class.getName()).log(Level.SEVERE, null, ex);
                    }

                }
            }
        } else {
            alert("Please select a row to delete");
        }
        
        
                               tblStaffCategory.clearSelection();
                                getstaffworkposition();
    }//GEN-LAST:event_btnDeleteStaff1ActionPerformed

    private void tblStaffCategoryMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_tblStaffCategoryMouseClicked
        int i = tblStaffCategory.getSelectedRow();

        TableModel model = tblStaffCategory.getModel();

        TextfieldPosition.setText(model.getValueAt(i, 1).toString());
    }//GEN-LAST:event_tblStaffCategoryMouseClicked

    private void TabbedStaffMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_TabbedStaffMouseClicked
      getworkpositionbox();
      getstaffworkposition();
     tblsearchpane.setVisible(false);
     getallStaff(); 
     tableselector();
    
     
    }//GEN-LAST:event_TabbedStaffMouseClicked

    private void sroomtextfieldKeyReleased(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_sroomtextfieldKeyReleased
        if(sroomtextfield.getText().length() > 0){
            tblsearchpane.setVisible(true);
            searchroom();
        }
        else{
            tblsearchpane.setVisible(false);
          
        }
    }//GEN-LAST:event_sroomtextfieldKeyReleased

    private void tblsearchroomMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_tblsearchroomMouseClicked
int i = tblsearchroom.getSelectedRow();

        TableModel model = tblsearchroom.getModel();

        sroomtextfield.setText(model.getValueAt(i, 0).toString());     
         TextfieldFloor.setText(model.getValueAt(i, 1).toString());  
         tblsearchpane.setVisible(false);
    }//GEN-LAST:event_tblsearchroomMouseClicked

    private void btnAddStaffActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnAddStaffActionPerformed
       if(!fntext.getText().isEmpty() && !lntext.getText().isEmpty() && !mntext.getText().isEmpty() && workpositionbox.getSelectedItem() != null && !sroomtextfield.getText().isEmpty() && !TextfieldFloor.getText().isEmpty())
       {
        try {
            
            Class.forName("com.mysql.jdbc.Driver");
            con = DriverManager.getConnection("jdbc:mysql://localhost:3306/systemdatabase?zeroDateTimeBehavior=convertToNull", "root", "");
            String fnname = fntext.getText().trim().replace("'", "''");
            String lnname = lntext.getText().trim().replace("'", "''");
            String mnname = mntext.getText().trim().replace("'", "''");
            String ss= "SELECT * FROM staff WHERE stafffn='"+ fnname +"'  AND staffln='"+ lnname  +"' AND staffmn='"+ mnname  +"' ;";

            st = con.createStatement();
            ResultSet rs = st.executeQuery(ss);

            if (!rs.first()){
                   SaveStaff();
                    getallStaff();
                  
            }

            else{
               JOptionPane.showMessageDialog(null, "STAFF ALREADY EXIST");
            }

        }catch (ClassNotFoundException | SQLException ex) {
            Logger.getLogger(AdminDashboard.class.getName()).log(Level.SEVERE, null, ex);
        }
       }
       else{
           alert("Please fill up the missing details");
       }
 clear();
 getallStaff();
  tableselector();
    }//GEN-LAST:event_btnAddStaffActionPerformed

    private void btnUpdateStaffActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnUpdateStaffActionPerformed
        if(tblStaff.getSelectedRowCount() != 1){
            alert("Please select a row you want to update");
        } else if(!fntext.getText().isEmpty() && !lntext.getText().isEmpty() && !mntext.getText().isEmpty() && workpositionbox.getSelectedItem() != null && !sroomtextfield.getText().isEmpty() && !TextfieldFloor.getText().isEmpty())
       {
           
             try {
            
            Class.forName("com.mysql.jdbc.Driver");
            con = DriverManager.getConnection("jdbc:mysql://localhost:3306/systemdatabase?zeroDateTimeBehavior=convertToNull", "root", "");
            String fnname = fntext.getText().trim().replace("'", "''");
            String lnname = lntext.getText().trim().replace("'", "''");
            String mnname = mntext.getText().trim().replace("'", "''");
            String ss= "SELECT * FROM staff WHERE stafffn='"+ fnname +"'  AND staffln='"+ lnname  +"' AND staffmn='"+ mnname  +"' ;";

            st = con.createStatement();
            ResultSet rs = st.executeQuery(ss);

            if (!rs.first()){
                    int r = tblStaff.getSelectedRow();
        String rid = String.valueOf(String.valueOf(tblStaff.getValueAt(r, 0)));
           System.out.println(rid);
           
                try {
                    
            String UpdateQuery = "UPDATE staff SET stafffn = ? ,staffln = ? ,staffmn = ? ,staffworkid = ? ,roomid = ? ,floorid = ? WHERE staffid = ?";

                   
            String newstaffn = fntext.getText().trim().replace("'", "''");
            String newstaffln = lntext.getText().trim().replace("'", "''");
	    String newstaffmn = mntext.getText().trim().replace("'", "''");
            String newworkposition = workpositionbox.getSelectedItem().toString();
            String newroom = sroomtextfield.getText().trim().replace("'", "''");
            String newfloor = TextfieldFloor.getText().trim().replace("'", "''");
            
               	getstaffworkid(newworkposition);
		getroomid(newroom);
                getflrid(newfloor);
            
            
            PreparedStatement ps = con.prepareStatement(UpdateQuery);
            ps.setString(1,newstaffn  );
            ps.setString(2, newstaffln );
            ps.setString(3,newstaffmn );
            ps.setString(4, stid);
            ps.setString(5, roid);
            ps.setString(6, flrid);
            ps.setString(7, rid);

                    if(ps.executeUpdate() == 1)
                    {
                        JOptionPane.showMessageDialog(null, "Staff Updated");
                        TextfieldPosition.setText("");
                    }else{
                        JOptionPane.showMessageDialog(null, "Staff Not Updated");
                                              
                    }

                } catch (Exception ex) {
                    Logger.getLogger(AdminDashboard.class.getName()).log(Level.SEVERE, null, ex);
                }
            }

            else{
               JOptionPane.showMessageDialog(null, "STAFF ALREADY EXIST");
            }

        }catch (ClassNotFoundException | SQLException ex) {
            Logger.getLogger(AdminDashboard.class.getName()).log(Level.SEVERE, null, ex);
        }
           
  
              
       
       }
     else{
         alert("Please fill up the missing details");
     }
        
         clear();
        getallStaff();
         tableselector();
    }//GEN-LAST:event_btnUpdateStaffActionPerformed

    private void tblStaffMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_tblStaffMouseClicked
      
        int i = tblStaff.getSelectedRow();

        TableModel model = tblStaff.getModel();
        try{
        fntext.setText(model.getValueAt(i, 1).toString());
        lntext.setText(model.getValueAt(i, 2).toString());
        mntext.setText(model.getValueAt(i, 3).toString());
        workpositionbox.setSelectedItem(model.getValueAt(i, 4).toString());
        sroomtextfield.setText(model.getValueAt(i, 5).toString());
        TextfieldFloor.setText(model.getValueAt(i, 6).toString());
        }
        catch(NullPointerException e){
        fntext.setText(model.getValueAt(i, 1).toString());
        lntext.setText(model.getValueAt(i, 2).toString());
        mntext.setText(model.getValueAt(i, 3).toString());
               
                
            
        if(model.getValueAt(i, 4).equals("") ){
            workpositionbox.setSelectedIndex(-1);
            sroomtextfield.setText(model.getValueAt(i, 5).toString());
            TextfieldFloor.setText(model.getValueAt(i, 6).toString());
        }
        else if(model.getValueAt(i, 5).equals("")){
            workpositionbox.setSelectedItem(model.getValueAt(i, 4).toString());
            sroomtextfield.setText("");
            TextfieldFloor.setText(model.getValueAt(i, 6).toString());
        }
        else if(model.getValueAt(i, 6).equals("")){
            workpositionbox.setSelectedItem(model.getValueAt(i, 4).toString());
        sroomtextfield.setText(model.getValueAt(i, 5).toString());
        TextfieldFloor.setText("");
        }
            
        }
    
    }//GEN-LAST:event_tblStaffMouseClicked

    private void btnDeleteStaffActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnDeleteStaffActionPerformed
      if(tblStaff.getSelectedRowCount() == 1){
          
        int i = tblStaff.getSelectedRow();
        TableModel model = tblStaff.getModel();
        String id = String.valueOf(model.getValueAt(i, 0));
        deletestaff(id);}
      else{
          alert("Please select the row you want to delete");
      }
         tableselector();
      
    }//GEN-LAST:event_btnDeleteStaffActionPerformed

    private void btnClearStaffActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnClearStaffActionPerformed
 clear();
  tableselector();
  tblStaff.clearSelection();
    }//GEN-LAST:event_btnClearStaffActionPerformed

    private void btnTransactionMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_btnTransactionMouseClicked
         btnTransaction.setForeground(Color.WHITE);
             btnRoom.setForeground(new Color(204,204,204));
              btnStaff.setForeground(new Color(204,204,204));
               btnGeneral.setForeground(new Color(204,204,204));
    }//GEN-LAST:event_btnTransactionMouseClicked

    private void btnTransactionActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnTransactionActionPerformed
     
      TransactionPanel.setVisible(true);
        TabbedTransaction.setVisible(true);
        titlelabel.setText("Transaction Information");
        
        RoomPanel.setVisible(false);
        TabbedRoom.setVisible(false);
        StaffPanel.setVisible(false);
        TabbedStaff.setVisible(false);
       GeneralPanel.setVisible(false);  
       tblroomtranspane.setVisible(false);
  
       getranstitle();
       tableselector();
    }//GEN-LAST:event_btnTransactionActionPerformed

    private void TransactionTitleTextfieldActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_TransactionTitleTextfieldActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_TransactionTitleTextfieldActionPerformed

    private void btndeletetranstitleMouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_btndeletetranstitleMouseEntered
        btndeletetranstitle.setContentAreaFilled(true);
       btndeletetranstitle.setBackground(new Color(3, 169, 131));
    }//GEN-LAST:event_btndeletetranstitleMouseEntered

    private void btndeletetranstitleMouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_btndeletetranstitleMouseExited
      btndeletetranstitle.setContentAreaFilled(false);
    }//GEN-LAST:event_btndeletetranstitleMouseExited

    private void btndeletetranstitleActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btndeletetranstitleActionPerformed
       int i = tbltransactiontitle.getSelectedRow();
        TableModel model = tbltransactiontitle.getModel();
        String id = String.valueOf(model.getValueAt(i, 0));
        deletestaff(id);
         getranstitle();
    }//GEN-LAST:event_btndeletetranstitleActionPerformed

    private void btnaddtranstitleMouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_btnaddtranstitleMouseEntered
       btnaddtranstitle.setContentAreaFilled(true);
       btnaddtranstitle.setBackground(new Color(3, 169, 131));
    }//GEN-LAST:event_btnaddtranstitleMouseEntered

    private void btnaddtranstitleMouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_btnaddtranstitleMouseExited
       btnaddtranstitle.setContentAreaFilled(false);
    }//GEN-LAST:event_btnaddtranstitleMouseExited

    private void btnaddtranstitleActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnaddtranstitleActionPerformed
             try {
            
            Class.forName("com.mysql.jdbc.Driver");
            con = DriverManager.getConnection("jdbc:mysql://localhost:3306/systemdatabase?zeroDateTimeBehavior=convertToNull", "root", "");
            String titlename = TransactionTitleTextfield.getText().trim().replace("'", "''");
            String roomname = RoomtranTextfield.getText().trim().replace("'", "''");
            getroomid(roomname);
          
            String ss= "SELECT * FROM transaction WHERE transactiontitle='"+ titlename +"';";

            st = con.createStatement();
            java.sql.ResultSet rs = st.executeQuery(ss);

            if (!rs.first()){
                  SaveTransaction();
            }

            else{
               JOptionPane.showMessageDialog(null, "Transaction Title Already Exist");
            }

        }catch (ClassNotFoundException | SQLException ex) {
            Logger.getLogger(AdminDashboard.class.getName()).log(Level.SEVERE, null, ex);
        }
        
         getranstitle();
    }//GEN-LAST:event_btnaddtranstitleActionPerformed

    private void btncleartransMouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_btncleartransMouseEntered
         btncleartrans.setContentAreaFilled(true);
       btncleartrans.setBackground(new Color(3, 169, 131));
    }//GEN-LAST:event_btncleartransMouseEntered

    private void btncleartransMouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_btncleartransMouseExited
      
       
        
      btncleartrans.setContentAreaFilled(false);
    }//GEN-LAST:event_btncleartransMouseExited

    private void btnupdatetranstitleMouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_btnupdatetranstitleMouseEntered
      btnupdatetranstitle.setContentAreaFilled(true);
       btnupdatetranstitle.setBackground(new Color(3, 169, 131));
    }//GEN-LAST:event_btnupdatetranstitleMouseEntered

    private void btnupdatetranstitleMouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_btnupdatetranstitleMouseExited
      btnupdatetranstitle.setContentAreaFilled(false);
    }//GEN-LAST:event_btnupdatetranstitleMouseExited

    private void btnupdatetranstitleActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnupdatetranstitleActionPerformed
     int i = tbltransactiontitle.getSelectedRow();
    if(i != 0){
       transactiontitlechecker();
    }
        
         getranstitle();
    }//GEN-LAST:event_btnupdatetranstitleActionPerformed

    private void RoomtranTextfieldActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_RoomtranTextfieldActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_RoomtranTextfieldActionPerformed

    private void RoomtranTextfieldKeyReleased(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_RoomtranTextfieldKeyReleased
        if(RoomtranTextfield.getText().length() > 0){
            tblroomtranspane.setVisible(true);
            searchroomtrans();
        }
        else{
            tblroomtranspane.setVisible(false);
          
        }
    }//GEN-LAST:event_RoomtranTextfieldKeyReleased

    private void btnclearcategoryMouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_btnclearcategoryMouseEntered
         btnclearcategory.setContentAreaFilled(true);
         btnclearcategory.setBackground(new Color(3, 169, 131));
    }//GEN-LAST:event_btnclearcategoryMouseEntered

    private void btnclearcategoryMouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_btnclearcategoryMouseExited
        btnclearcategory.setContentAreaFilled(false);
    }//GEN-LAST:event_btnclearcategoryMouseExited

    private void btnclearcategoryActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnclearcategoryActionPerformed
      CategoryTextfield.setText("");
      tblcategoryroom.clearSelection();
    }//GEN-LAST:event_btnclearcategoryActionPerformed

    private void RoomTextfieldKeyReleased(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_RoomTextfieldKeyReleased
         
    }//GEN-LAST:event_RoomTextfieldKeyReleased

    private void CategoryRoomBoxActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_CategoryRoomBoxActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_CategoryRoomBoxActionPerformed

    private void CategoryTextfieldActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_CategoryTextfieldActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_CategoryTextfieldActionPerformed

    private void tblsearchroomtransMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_tblsearchroomtransMouseClicked
int i = tblsearchroomtrans.getSelectedRow();

        TableModel model = tblsearchroomtrans.getModel();

        RoomtranTextfield.setText(model.getValueAt(i, 0).toString());     
         tblroomtranspane.setVisible(false);       
        
        
        
        
    }//GEN-LAST:event_tblsearchroomtransMouseClicked

    private void btncleartransActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btncleartransActionPerformed
        TransactionTitleTextfield.setText("");
        RoomtranTextfield.setText("");
        tblroomtranspane.setVisible(false);
        tbltransactiontitle.clearSelection();
    }//GEN-LAST:event_btncleartransActionPerformed

    private void tbltransactiontitleMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_tbltransactiontitleMouseClicked
 int i = tbltransactiontitle.getSelectedRow();

        TableModel model = tbltransactiontitle.getModel();
        TransactionTitleTextfield.setText(model.getValueAt(i, 1).toString());
        RoomtranTextfield.setText(model.getValueAt(i, 2).toString());
         
    }//GEN-LAST:event_tbltransactiontitleMouseClicked

   
    public static void main(String args[]) {
     
       try {    UIManager.setLookAndFeel(new FlatIntelliJLaf ());
       }
       catch (Exception e) {
           e.printStackTrace ();
        }
       
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new AdminDashboard().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JPanel ButtonOptionsPanel;
    private javax.swing.JPanel CategoryRoom;
    private javax.swing.JComboBox<String> CategoryRoomBox;
    private javax.swing.JTextField CategoryTextfield;
    private javax.swing.JPanel ContainerPanel;
    private javax.swing.JComboBox<String> FloorBox;
    private javax.swing.JPanel GeneralPanel;
    private javax.swing.JPanel Room;
    private javax.swing.JPanel RoomPanel;
    private javax.swing.JTextField RoomTextfield;
    private javax.swing.JTextField RoomtranTextfield;
    private javax.swing.JPanel Staff;
    private javax.swing.JPanel StaffCategory;
    private javax.swing.JPanel StaffPanel;
    private javax.swing.JTabbedPane TabbedRoom;
    private javax.swing.JTabbedPane TabbedStaff;
    private javax.swing.JTabbedPane TabbedTransaction;
    private javax.swing.JTextField TextfieldFloor;
    private javax.swing.JTextField TextfieldPosition;
    private javax.swing.JPanel TopNavPanel;
    private javax.swing.JPanel Transaction;
    private javax.swing.JPanel TransactionPanel;
    private javax.swing.JPanel TransactionProcedure;
    private javax.swing.JTextField TransactionTitleTextfield;
    private javax.swing.JTextField abbtext;
    private javax.swing.JButton btnAddStaff;
    private javax.swing.JButton btnAddStaff1;
    private javax.swing.JButton btnClearStaff;
    private javax.swing.JButton btnClearStaff1;
    private javax.swing.JButton btnDeleteStaff;
    private javax.swing.JButton btnDeleteStaff1;
    private javax.swing.JButton btnGeneral;
    private javax.swing.JButton btnPrevMap;
    private javax.swing.JButton btnReset;
    private javax.swing.JButton btnRoom;
    private javax.swing.JButton btnRoomadd;
    private javax.swing.JButton btnRoomdelete;
    private javax.swing.JButton btnRoomupdate;
    private javax.swing.JButton btnStaff;
    private javax.swing.JButton btnTransaction;
    private javax.swing.JButton btnUpdateStaff;
    private javax.swing.JButton btnUpdateStaff1;
    private javax.swing.JButton btnaddcategory;
    private javax.swing.JButton btnaddtranstitle;
    private javax.swing.JButton btnclearcategory;
    private javax.swing.JButton btncleartrans;
    private javax.swing.JButton btndeletecategory;
    private javax.swing.JButton btndeletetranstitle;
    private javax.swing.JButton btnlogout;
    private javax.swing.JButton btnnumStaff;
    private javax.swing.JButton btnnumStaffposition;
    private javax.swing.JButton btnnumroom;
    private javax.swing.JButton btnnumroomcat;
    private javax.swing.JButton btnupdatecategory;
    private javax.swing.JButton btnupdatetranstitle;
    private javax.swing.JLabel datelabel;
    private javax.swing.JTextField fntext;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel10;
    private javax.swing.JLabel jLabel11;
    private javax.swing.JLabel jLabel12;
    private javax.swing.JLabel jLabel13;
    private javax.swing.JLabel jLabel14;
    private javax.swing.JLabel jLabel15;
    private javax.swing.JLabel jLabel16;
    private javax.swing.JLabel jLabel17;
    private javax.swing.JLabel jLabel18;
    private javax.swing.JLabel jLabel19;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel20;
    private javax.swing.JLabel jLabel21;
    private javax.swing.JLabel jLabel22;
    private javax.swing.JLabel jLabel23;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JLabel jLabel9;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JPanel jPanel3;
    private javax.swing.JPanel jPanel4;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JScrollPane jScrollPane2;
    private javax.swing.JScrollPane jScrollPane3;
    private javax.swing.JScrollPane jScrollPane4;
    private javax.swing.JScrollPane jScrollPane5;
    private javax.swing.JScrollPane jScrollPane6;
    private javax.swing.JTextField lntext;
    private javax.swing.JTextField mntext;
    private javax.swing.JPanel roomformpanel;
    private javax.swing.JTextField sroomtextfield;
    private javax.swing.JTable tblStaff;
    private javax.swing.JTable tblStaffCategory;
    private javax.swing.JTable tblSumRoom;
    private javax.swing.JTable tblcategoryroom;
    private javax.swing.JTable tblroom;
    private javax.swing.JScrollPane tblroomtranspane;
    private javax.swing.JScrollPane tblsearchpane;
    private javax.swing.JTable tblsearchroom;
    private javax.swing.JTable tblsearchroomtrans;
    private javax.swing.JTable tbltransactiontitle;
    private javax.swing.JLabel timelabel;
    private javax.swing.JLabel title;
    private javax.swing.JLabel titlelabel;
    private javax.swing.JLabel titlelabel1;
    private javax.swing.JComboBox<String> workpositionbox;
    // End of variables declaration//GEN-END:variables

public void startup(){
    TabbedRoom.setVisible(false);
    TabbedStaff.setVisible(false);
    TabbedTransaction.setVisible(false);
    btnGeneral.setForeground(Color.WHITE);
   tablecustom();
  getallnums();
   tableselector();
}

 
    public void getroom(){
        DefaultTableModel model1 = (DefaultTableModel) tblroom.getModel();
                    model1.setRowCount(0);
           try {
            Class.forName("com.mysql.jdbc.Driver");
            con = DriverManager.getConnection("jdbc:mysql://localhost:3306/systemdatabase?zeroDateTimeBehavior=convertToNull", "root", "");
    
             String ss= "SELECT room.roomid, room.roomname, room.abbreviation, roomcategory.roomcategoryname, floor.floorname FROM room LEFT JOIN roomcategory ON room.roomcategoryid = roomcategory.roomcategoryid LEFT JOIN floor ON room.floorid = floor.floorid ORDER BY room.roomid ASC;";
           
            st = con.createStatement();
            java.sql.ResultSet rs = st.executeQuery(ss);
             
             DefaultTableModel model = (DefaultTableModel) tblroom.getModel();
            while (rs.next()) {
                
                Object[] row = new Object[5];
                row[0] = rs.getString("roomid");
                row[1]= rs.getString("roomname");
                row[2] = rs.getString("abbreviation");
                row[3]= rs.getString("roomcategoryname");
                row[4]= rs.getString("floorname");
                 model.addRow(row);
                 clear();
              
  
            }
        }catch (ClassNotFoundException | SQLException  | NullPointerException ex) {
            Logger.getLogger(AdminDashboard.class.getName()).log(Level.SEVERE, null, ex);
       
        }
    
    }         
    
//  //CHECKS ALL THE CELL IN THE TABLE, IF A CELL IS EMPTY IT REPLACES AN 'NA'//  
//  public void validCheck() {
//        DefaultTableModel model = (DefaultTableModel)tblroom.getModel();
//        int rows = model.getRowCount();
//
//        for (int i = 0; i < rows; i++) {
//            for (int j = 0; j < model.getColumnCount(); j++) {
//                Object ob = model.getValueAt(i, j);
//                if (ob == null || ob.toString().isEmpty()) {
//                    model.setValueAt("NA", i, j);
//                }
//            }
//        }
//
//  
//   }
    
    //THIS CUSTOMIZES THE ALL THE TABLE CALLED WITHIN THIS CLASSS//
    public void tablecustom(){
        
       tblroom.getTableHeader().setFont(new Font("SanSerif",Font.BOLD,12));
        tblroom.getTableHeader().setBackground(new Color(3,169,131));
        tblroom.getTableHeader().setForeground(new Color(255,255,255));
        
         DefaultTableCellRenderer centerRenderer = new DefaultTableCellRenderer();
         centerRenderer.setHorizontalAlignment( JLabel.CENTER );
           tblroom.setDefaultRenderer(String.class, centerRenderer);
           centerRenderer.setHorizontalAlignment( JLabel.CENTER );
            tblroom.getColumnModel().getColumn(0).setCellRenderer( centerRenderer );
            
             tblcategoryroom.getTableHeader().setFont(new Font("SanSerif",Font.BOLD,12));
        tblcategoryroom.getTableHeader().setBackground(new Color(3,169,131));
        tblcategoryroom.getTableHeader().setForeground(new Color(255,255,255));
        
         centerRenderer.setHorizontalAlignment( JLabel.CENTER );
           tblcategoryroom.setDefaultRenderer(String.class, centerRenderer);
           centerRenderer.setHorizontalAlignment( JLabel.CENTER );
            tblcategoryroom.getColumnModel().getColumn(0).setCellRenderer( centerRenderer );
            
              tblsearchroom.getTableHeader().setFont(new Font("SanSerif",Font.BOLD,12));
        tblsearchroom.getTableHeader().setBackground(new Color(3,169,131));
        tblsearchroom.getTableHeader().setForeground(new Color(255,255,255));
        
         centerRenderer.setHorizontalAlignment( JLabel.CENTER );
           tblsearchroom.setDefaultRenderer(String.class, centerRenderer);
           centerRenderer.setHorizontalAlignment( JLabel.CENTER );
            tblsearchroom.getColumnModel().getColumn(0).setCellRenderer( centerRenderer );
            
            tblStaff.getTableHeader().setFont(new Font("SanSerif",Font.BOLD,12));
        tblStaff.getTableHeader().setBackground(new Color(3,169,131));
        tblStaff.getTableHeader().setForeground(new Color(255,255,255));
        
         centerRenderer.setHorizontalAlignment( JLabel.CENTER );
           tblStaff.setDefaultRenderer(String.class, centerRenderer);
           centerRenderer.setHorizontalAlignment( JLabel.CENTER );
            tblStaff.getColumnModel().getColumn(0).setCellRenderer( centerRenderer );
            
               tblStaffCategory.getTableHeader().setFont(new Font("SanSerif",Font.BOLD,12));
        tblStaffCategory.getTableHeader().setBackground(new Color(3,169,131));
        tblStaffCategory.getTableHeader().setForeground(new Color(255,255,255));
        
         centerRenderer.setHorizontalAlignment( JLabel.CENTER );
           tblStaffCategory.setDefaultRenderer(String.class, centerRenderer);
           centerRenderer.setHorizontalAlignment( JLabel.CENTER );
            tblStaffCategory.getColumnModel().getColumn(0).setCellRenderer( centerRenderer );
            

               tblSumRoom.getTableHeader().setFont(new Font("SanSerif",Font.BOLD,12));
        tblSumRoom.getTableHeader().setBackground(new Color(3,169,131));
        tblSumRoom.getTableHeader().setForeground(new Color(255,255,255));
        
        
         tbltransactiontitle.getTableHeader().setFont(new Font("SanSerif",Font.BOLD,12));
        tbltransactiontitle.getTableHeader().setBackground(new Color(3,169,131));
        tbltransactiontitle.getTableHeader().setForeground(new Color(255,255,255));
        
         centerRenderer.setHorizontalAlignment( JLabel.CENTER );
           tbltransactiontitle.setDefaultRenderer(String.class, centerRenderer);
           centerRenderer.setHorizontalAlignment( JLabel.CENTER );
            tbltransactiontitle.getColumnModel().getColumn(0).setCellRenderer( centerRenderer );
            
            
          
    }
    
  
    
    //THIS CLASS GETS ALL THE CATEGORY OF ROOM AND DISPLAYS IS TO THE COMOBOBOX
    public void getcatbox(){
        CategoryRoomBox.removeAllItems();
        try {
            Class.forName("com.mysql.jdbc.Driver");
            con = DriverManager.getConnection("jdbc:mysql://localhost:3306/systemdatabase?zeroDateTimeBehavior=convertToNull", "root", "");
    
             String ss= "SELECT * FROM roomcategory order by roomcategoryid ASC;";
           
            st = con.createStatement();
            java.sql.ResultSet rs = st.executeQuery(ss);
             
            while (rs.next()) {
                String catname = rs.getString("roomcategoryname");
                CategoryRoomBox.addItem(catname);
                CategoryRoomBox.setSelectedIndex(-1);
            }
        }catch (ClassNotFoundException | SQLException ex) {
            Logger.getLogger(AdminDashboard.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
    
    //THIS CLASS GETS ALL THE FLOOR AND DISPLAYS IT TO THE COMBOBOX
     public void getfloorbox(){
           FloorBox.removeAllItems();
        try {
            Class.forName("com.mysql.jdbc.Driver");
            con = DriverManager.getConnection("jdbc:mysql://localhost:3306/systemdatabase?zeroDateTimeBehavior=convertToNull", "root", "");
    
             String ss= "SELECT * FROM floor order by floorid ASC;";
           
            st = con.createStatement();
            java.sql.ResultSet rs = st.executeQuery(ss);
             
            while (rs.next()) {
                String catname = rs.getString("floorname");
                FloorBox.addItem(catname);
                FloorBox.setSelectedIndex(-1);
            }
        }catch (ClassNotFoundException | SQLException ex) {
            Logger.getLogger(AdminDashboard.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
     
     
//THIS CLASS SAVES THE ROOM IF THERE IS NO EXISTING ROOM NAME AND CATEGORY
    private void SaveRoom() {
        
       try{
               Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/systemdatabase?zeroDateTimeBehavior=convertToNull", "root", "");
               PreparedStatement ps = con.prepareStatement("insert into room(roomname,abbreviation,roomcategoryid,floorid) values(?,?,?,?)");
               String catroomboxString =   CategoryRoomBox.getSelectedItem().toString().trim().replace("'", "''");
               getcatid(catroomboxString);
               getflrid(FloorBox.getSelectedItem().toString().trim());
               
               ps.setString(1, RoomTextfield.getText().trim().replace("'", "''"));
               ps.setString(2, abbtext.getText().trim().replace("'", "''"));
               ps.setString(3, cid);
               ps.setString(4, flrid);
               
               
               ps.executeUpdate();
               JOptionPane.showMessageDialog(null, "ROOM ADDED SUCCESSFULLY");
               getroom();
           }catch(Exception ex){
               ex.printStackTrace();
           }
    }
    
     
    //THIS CLASS GETS THE ID  SELECTED ROOM CATEGORY IN THE COMBOBOX AND RETURN THE ID //
      public void getcatid( String id){
        
         try {
            Class.forName("com.mysql.jdbc.Driver");
            con = DriverManager.getConnection("jdbc:mysql://localhost:3306/systemdatabase?zeroDateTimeBehavior=convertToNull", "root", "");
    
             String ss= "SELECT * FROM roomcategory where roomcategoryname ='"+id+"';";
           
            st = con.createStatement();
            java.sql.ResultSet rs = st.executeQuery(ss);
             
            while (rs.next()) {
               cid = rs.getString("roomcategoryid");
            }
        }catch (ClassNotFoundException | SQLException ex) {
            Logger.getLogger(AdminDashboard.class.getName()).log(Level.SEVERE, null, ex);
        }
        
    
    }
    
        //THIS CLASS GETS THE ID  SELECTED FLOOR IN THE COMBOBOX AND RETURN THE ID //
    public void getflrid( String rn){
        
         try {
            Class.forName("com.mysql.jdbc.Driver");
            con = DriverManager.getConnection("jdbc:mysql://localhost:3306/systemdatabase?zeroDateTimeBehavior=convertToNull", "root", "");
    
             String ss= "SELECT * FROM floor where floorname ='"+rn+"';";
           
            st = con.createStatement();
            java.sql.ResultSet rs = st.executeQuery(ss);
             
            while (rs.next()) {
               flrid = rs.getString("floorid");
            }
        }catch (ClassNotFoundException | SQLException ex) {
            Logger.getLogger(AdminDashboard.class.getName()).log(Level.SEVERE, null, ex);
        }
        
    
    }

    
    
private void roomchecker(){
     int i = tblroom.getSelectedRow();
    TableModel tblmodel = tblroom.getModel();
     
     String title = tblmodel.getValueAt(i, 1).toString().trim();
     String room = tblmodel.getValueAt(i, 2).toString().trim();
     String cat = tblmodel.getValueAt(i, 3).toString().trim();
     String fl = tblmodel.getValueAt(i, 4).toString().trim();
     
      try {
            
            Class.forName("com.mysql.jdbc.Driver");
            con = DriverManager.getConnection("jdbc:mysql://localhost:3306/systemdatabase?zeroDateTimeBehavior=convertToNull", "root", "");
            String titlename = RoomTextfield.getText().trim().replace("'", "''");          
            String abb = abbtext.getText().toString().trim();
            String category = CategoryRoomBox.getSelectedItem().toString().trim();
            String floor = FloorBox.getSelectedItem().toString().trim();
            String ss= "SELECT * FROM room WHERE roomname = '"+titlename+"';";

            st = con.createStatement();
            ResultSet rs = st.executeQuery(ss);

            if (rs.first()){
                if(!rs.getString("roomname").equals(title) || !abb.equals(room) || !category.equals(cat) || !floor.equals(fl)){
                updatetransactionTitle();
            }
            else{
                 alert("Transaction Title Already Exist");
            }
                
            }
            else{
             updatetransactionTitle();
            }

        }catch (ClassNotFoundException | SQLException ex) {
            Logger.getLogger(AdminDashboard.class.getName()).log(Level.SEVERE, null, ex);
        }
      
}
    
    
    
    
    
    
    
    
    
    
    //THIS CLASS UPDATES THE ROOM IF THERE IS NO PICTURE TO BE UPDATED
    private void updateroom(String newroomname,String abbr ,String newcat, String newfloor, String rid) {
    try {
            
            Class.forName("com.mysql.jdbc.Driver");
            con = DriverManager.getConnection("jdbc:mysql://localhost:3306/systemdatabase?zeroDateTimeBehavior=convertToNull", "root", "");
           String sqlr = "SELECT * FROM roomcategory WHERE roomcategoryname='" + newcat+ "'";
                st = con.createStatement();
                
                ResultSet rs = st.executeQuery(sqlr);
               
                if(rs.first()){
                  String caet = rs.getString("roomcategoryid");
                   
        
                
      
        try {
            Class.forName("com.mysql.jdbc.Driver");
            con = DriverManager.getConnection("jdbc:mysql://localhost:3306/systemdatabase?zeroDateTimeBehavior=convertToNull", "root", "");
            String sql = "UPDATE `room` SET roomname='" + newroomname +"',abbreviation='" + abbr + "',roomcategoryid='" + caet + "',floorid='" + newfloor +"' WHERE roomid='"+rid+"';";
            st = con.createStatement();
            st.execute(sql);
            alert("UPDATE SUCCESS");
                
        } catch (ClassNotFoundException | SQLException ex) {
            Logger.getLogger(AdminDashboard.class.getName()).log(Level.SEVERE, null, ex);
        }
        }
    }
        catch(ClassNotFoundException | SQLException ex){
         Logger.getLogger(AdminDashboard.class.getName()).log(Level.SEVERE, null, ex);
    }
    
    
    }
    
     public void alert(String msg) {
        JOptionPane.showMessageDialog(rootPane, msg);
    }

     
     //THIS CLASS DELETES THE ROOM USING THE ID//
    private void delete(String rid) {
        
         try {
            Class.forName("com.mysql.jdbc.Driver");
            con = DriverManager.getConnection("jdbc:mysql://localhost:3306/systemdatabase?zeroDateTimeBehavior=convertToNull", "root", "");
            String sql = "DELETE FROM `room` WHERE roomid='" + rid + "'" ;
            st = con.createStatement();
            st.execute(sql);
        } catch (ClassNotFoundException | SQLException ex) {
            Logger.getLogger(AdminDashboard.class.getName()).log(Level.SEVERE, null, ex);
        }
        
    }
    
    
    //THIS CLEARS THE ALL THE FORM IN THE ROOM PANEL
    public void clear(){
         RoomTextfield.setText("");
        CategoryRoomBox.setSelectedIndex(-1);
        FloorBox.setSelectedIndex(-1);
        tblroom.clearSelection();
        fntext.setText("");
        lntext.setText("");
        mntext.setText("");
        workpositionbox.setSelectedIndex(-1);
        sroomtextfield.setText("");
        TextfieldFloor.setText("");
       tblsearchpane.setVisible(false);
       TransactionTitleTextfield.setText("");
        RoomtranTextfield.setText("");
      abbtext.setText("");
    }
    
 
     
     //THIS CLASS GETS ALL THE ROOM CATEGORY AND DISPLAY IN THE TABLE CATEGORY ROOM
     public void getcategory(){
            DefaultTableModel model1 = (DefaultTableModel) tblcategoryroom.getModel();
                    model1.setRowCount(0);
           try {
            Class.forName("com.mysql.jdbc.Driver");
            con = DriverManager.getConnection("jdbc:mysql://localhost:3306/systemdatabase?zeroDateTimeBehavior=convertToNull", "root", "");
    
             String ss= "SELECT * FROM roomcategory ORDER BY roomcategoryid ASC;";
           
            st = con.createStatement();
            java.sql.ResultSet rs = st.executeQuery(ss);
             
             DefaultTableModel model = (DefaultTableModel) tblcategoryroom.getModel();
            while (rs.next()) {
                
                Object[] row = new Object[2];
                row[0] = rs.getString("roomcategoryid");
                row[1]= rs.getString("roomcategoryname");
                
                 model.addRow(row);
                 clear();
              
  
            }
        }catch (ClassNotFoundException | SQLException ex) {
            Logger.getLogger(AdminDashboard.class.getName()).log(Level.SEVERE, null, ex);
        }
     }

     //THIS CLASS COUNTS THE ROOM AND DISPLAY THE NUMBER OF ROOM IN THE DATABASE
private void countroom() {
        
         try {
            Class.forName("com.mysql.jdbc.Driver");
            con = DriverManager.getConnection("jdbc:mysql://localhost:3306/systemdatabase?zeroDateTimeBehavior=convertToNull", "root", "");
            String sql = "SELECT  COUNT(roomid) AS 'numroom' FROM room " ;
            st = con.createStatement();
         ResultSet rs =   st.executeQuery(sql);
              if(rs.first()){
                  
            btnnumroom.setText(rs.getString("numroom"));}
        } catch (ClassNotFoundException | SQLException ex) {
            Logger.getLogger(AdminDashboard.class.getName()).log(Level.SEVERE, null, ex);
        }
        
    }
 //THIS CLASS COUNTS THE ROOM AND DISPLAY THE NUMBER OF ROOM CATEGORY IN THE DATABASE
private void countroomcat() {
        
         try {
            Class.forName("com.mysql.jdbc.Driver");
            con = DriverManager.getConnection("jdbc:mysql://localhost:3306/systemdatabase?zeroDateTimeBehavior=convertToNull", "root", "");
            String sql = "SELECT  COUNT(roomcategoryid) AS 'numroomcat' FROM roomcategory " ;
            st = con.createStatement();
         ResultSet rs =   st.executeQuery(sql);
              if(rs.first()){
                  
            btnnumroomcat.setText(rs.getString("numroomcat"));}
        } catch (ClassNotFoundException | SQLException ex) {
            Logger.getLogger(AdminDashboard.class.getName()).log(Level.SEVERE, null, ex);
        }
        
    }
 //THIS CLASS COUNTS THE STAFF AND DISPLAY THE NUMBER OF STAFF IN THE DATABASE
private void countstaff() {
        
         try {
            Class.forName("com.mysql.jdbc.Driver");
            con = DriverManager.getConnection("jdbc:mysql://localhost:3306/systemdatabase?zeroDateTimeBehavior=convertToNull", "root", "");
            String sql = "SELECT  COUNT(staffid) AS 'numstaff' FROM staff " ;
            st = con.createStatement();
         ResultSet rs =   st.executeQuery(sql);
              if(rs.first()){
                  
            btnnumStaff.setText(rs.getString("numstaff"));}
        } catch (ClassNotFoundException | SQLException ex) {
            Logger.getLogger(AdminDashboard.class.getName()).log(Level.SEVERE, null, ex);
        }
        
    }

//THIS CLASS COUNTS THE STAFF WORK POSITION AND DISPLAY THE NUMBER OF STAFF WORK POSITION IN THE DATABASE
private void countstaffposition() {
        
         try {
            Class.forName("com.mysql.jdbc.Driver");
            con = DriverManager.getConnection("jdbc:mysql://localhost:3306/systemdatabase?zeroDateTimeBehavior=convertToNull", "root", "");
            String sql = "SELECT  COUNT(staffworkid) AS 'numstaffposition' FROM staffworkposition " ;
            st = con.createStatement();
         ResultSet rs =   st.executeQuery(sql);
              if(rs.first()){
                  
            btnnumStaffposition.setText(rs.getString("numstaffposition"));}
        } catch (ClassNotFoundException | SQLException ex) {
            Logger.getLogger(AdminDashboard.class.getName()).log(Level.SEVERE, null, ex);
        }
        
    }

//THIS CLASS GETS ALL THE STAFF WORK POSITION IN THE DATABASE AND DISPLAY
 public void getstaffworkposition(){
        DefaultTableModel model1 = (DefaultTableModel) tblStaffCategory.getModel();
                    model1.setRowCount(0);
           try {
            Class.forName("com.mysql.jdbc.Driver");
            con = DriverManager.getConnection("jdbc:mysql://localhost:3306/systemdatabase?zeroDateTimeBehavior=convertToNull", "root", "");
    
             String ss= "SELECT * FROM staffworkposition ORDER BY staffworkid ASC;";
           
            st = con.createStatement();
            java.sql.ResultSet rs = st.executeQuery(ss);
             
             DefaultTableModel model = (DefaultTableModel) tblStaffCategory.getModel();
            while (rs.next()) {
                
                Object[] row = new Object[2];
                row[0] = rs.getString("staffworkid");
                row[1]= rs.getString("staffworkpositionname");
               
                 model.addRow(row);
                 clear();
              
  
            }
        }catch (ClassNotFoundException | SQLException ex) {
            Logger.getLogger(AdminDashboard.class.getName()).log(Level.SEVERE, null, ex);
        }
         }          

 
public void getworkpositionbox(){ 
    workpositionbox.removeAllItems();
         
        try {
            Class.forName("com.mysql.jdbc.Driver");
            con = DriverManager.getConnection("jdbc:mysql://localhost:3306/systemdatabase?zeroDateTimeBehavior=convertToNull", "root", "");
    
             String ss= "SELECT * FROM staffworkposition order by staffworkid ASC;";
           
            st = con.createStatement();
            java.sql.ResultSet rs = st.executeQuery(ss);
             
            while (rs.next()) {
                String positionname = rs.getString("staffworkpositionname");
                workpositionbox.addItem(positionname);
                workpositionbox.setSelectedIndex(-1);
            }
        }catch (ClassNotFoundException | SQLException ex) {
            Logger.getLogger(AdminDashboard.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

public void searchroom(){
    DefaultTableModel model1 = (DefaultTableModel) tblsearchroom.getModel();
                    model1.setRowCount(0);
        try {
            Class.forName("com.mysql.jdbc.Driver");
            con = DriverManager.getConnection("jdbc:mysql://localhost:3306/systemdatabase?zeroDateTimeBehavior=convertToNull", "root", "");
             String s = sroomtextfield.getText().trim();
             String ss= "SELECT room.roomname, floor.floorname FROM room INNER JOIN floor ON room.floorid = floor.floorid WHERE roomname LIKE '%"+s+"%' ;";
           
            st = con.createStatement();
            java.sql.ResultSet rs = st.executeQuery(ss);
             DefaultTableModel model = (DefaultTableModel) tblsearchroom.getModel();
            while (rs.next()) {
               
               Object[] row = new Object[2];
                row[0] = rs.getString("roomname");
                row[1]= rs.getString("floorname");
               model.addRow(row);
            }
        }catch (ClassNotFoundException | SQLException ex) {
            Logger.getLogger(AdminDashboard.class.getName()).log(Level.SEVERE, null, ex);
        }
}

public void searchroomtrans(){
    DefaultTableModel model1 = (DefaultTableModel) tblsearchroomtrans.getModel();
                    model1.setRowCount(0);
        try {
            Class.forName("com.mysql.jdbc.Driver");
            con = DriverManager.getConnection("jdbc:mysql://localhost:3306/systemdatabase?zeroDateTimeBehavior=convertToNull", "root", "");
             String s = RoomtranTextfield.getText().trim();
             String ss= "SELECT room.roomname, floor.floorname FROM room INNER JOIN floor ON room.floorid = floor.floorid WHERE roomname LIKE '%"+s+"%' ;";
           
            st = con.createStatement();
            java.sql.ResultSet rs = st.executeQuery(ss);
             DefaultTableModel model = (DefaultTableModel) tblsearchroomtrans.getModel();
            while (rs.next()) {
               
               Object[] row = new Object[2];
                row[0] = rs.getString("roomname");
                row[1]= rs.getString("floorname");
               model.addRow(row);
            }
        }catch (ClassNotFoundException | SQLException ex) {
            Logger.getLogger(AdminDashboard.class.getName()).log(Level.SEVERE, null, ex);
        }
}



private void SaveStaff() {
        
       try{
            Class.forName("com.mysql.jdbc.Driver");
               Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/systemdatabase?zeroDateTimeBehavior=convertToNull", "root", "");
               PreparedStatement ps = con.prepareStatement("insert into staff(stafffn, staffln, staffmn, staffworkid, roomid, floorid) values(?,?,?,?,?,?)");
               
               
               getstaffworkid(workpositionbox.getSelectedItem().toString().trim().replace("'", "''"));
	       getroomid(sroomtextfield.getText().trim().replace("'", "''"));
               getflrid(TextfieldFloor.getText().trim().replace("'", "''"));

               ps.setString(1, fntext.getText().trim().replace("'", "''"));
               ps.setString(2,lntext.getText().trim().replace("'", "''"));
               ps.setString(3,mntext.getText().trim().replace("'", "''"));
               ps.setString(4, stid);
               ps.setString(5, roid);
               ps.setString(6, flrid);
               
               
               if(ps.executeUpdate() == 1 ){
               JOptionPane.showMessageDialog(null, "STAFF ADDED SUCCESSFULLY");
               getroom();
		}
		else{
			 JOptionPane.showMessageDialog(null, "FAILED TO ADD STAFF");
			}
           }catch(Exception ex){
               ex.printStackTrace();
           }
	roid =null;
	stid = null;
	flrid = null;

    }


  public void getstaffworkid( String name){
        
         try {
            Class.forName("com.mysql.jdbc.Driver");
            con = DriverManager.getConnection("jdbc:mysql://localhost:3306/systemdatabase?zeroDateTimeBehavior=convertToNull", "root", "");
    
             String ss= "SELECT * FROM staffworkposition where staffworkpositionname ='"+name+"';";
           
            st = con.createStatement();
           ResultSet rs = st.executeQuery(ss);
             
            while (rs.next()) {
               stid = rs.getString("staffworkid");
            }
        }catch (ClassNotFoundException | SQLException ex) {
            Logger.getLogger(AdminDashboard.class.getName()).log(Level.SEVERE, null, ex);
        }
        
    
    }

  public void getroomid( String name){
        
         try {
            Class.forName("com.mysql.jdbc.Driver");
            con = DriverManager.getConnection("jdbc:mysql://localhost:3306/systemdatabase?zeroDateTimeBehavior=convertToNull", "root", "");
    
             String ss= "SELECT * FROM room where roomname='"+name+"';";
           
            st = con.createStatement();
            java.sql.ResultSet rs = st.executeQuery(ss);
             
            while (rs.next()) {
              roid = rs.getString("roomid");
            }
        }catch (ClassNotFoundException | SQLException ex) {
            Logger.getLogger(AdminDashboard.class.getName()).log(Level.SEVERE, null, ex);
        }
        
    
    }


 public void updatestaff(){
        
            try {
              
            String UpdateQuery = "UPDATE staff SET stafffn = ? ,staffln = ? ,staffmn = ? ,staffworkid = ? ,roomid = ? ,staffworkid = ? WHERE staffid = ?";
            int r = tblStaff.getSelectedRow();
            String rid = String.valueOf(String.valueOf(tblStaff.getValueAt(r, 0)));
            String newstaffn = fntext.getText().trim();
            String newstaffln = lntext.getText().trim();
	    String nestaffmn = mntext.getText().trim();
            String newworkposition = workpositionbox.getSelectedItem().toString();
            String newroom = sroomtextfield.getText().trim();
            String newfloor = TextfieldFloor.getText().trim();
            
               	getstaffworkid(newworkposition);
		getroomid(newroom);
                getflrid(newfloor);
            
            
            PreparedStatement ps = con.prepareStatement(UpdateQuery);
            ps.setString(1,newstaffn  );
            ps.setString(2, newstaffln );
            ps.setString(3,nestaffmn );
            ps.setString(4, stid);
            ps.setString(5, roid);
            ps.setString(6, flrid);
            ps.setString(7, rid);
            if(ps.executeUpdate() == 1)
            {
                JOptionPane.showMessageDialog(null, "Staff Updated");
                clear();
            }else{
                JOptionPane.showMessageDialog(null, "Failed to Update Staff");
            }
            
            } catch (Exception ex) {
                Logger.getLogger(AdminDashboard.class.getName()).log(Level.SEVERE, null, ex);
            }            
        
        roid =null;
	stid = null;
	flrid = null;
 
     }


private void deletestaff(String rid) {
        
         try {
            Class.forName("com.mysql.jdbc.Driver");
            con = DriverManager.getConnection("jdbc:mysql://localhost:3306/systemdatabase?zeroDateTimeBehavior=convertToNull", "root", "");
            String sql = "DELETE FROM `staff` WHERE staffid='" + rid + "'" ;
            st = con.createStatement();
           
            if(st.execute(sql) != true){
                 alert("Staff Deleted");
            }
            else{
                 alert("Staff Deletion Failed");
            }
            
            
        } catch (ClassNotFoundException | SQLException ex) {
            Logger.getLogger(AdminDashboard.class.getName()).log(Level.SEVERE, null, ex);
        }
        getallStaff();
    }

 public void getallStaff(){
        DefaultTableModel model1 = (DefaultTableModel) tblStaff.getModel();
                    model1.setRowCount(0);
           try {
            Class.forName("com.mysql.jdbc.Driver");
            con = DriverManager.getConnection("jdbc:mysql://localhost:3306/systemdatabase?zeroDateTimeBehavior=convertToNull", "root", "");
    
             String ss= "SELECT staff.staffid, staff.stafffn, staff.staffln, staff.staffmn, staffworkposition.staffworkpositionname, room.roomname, floor.floorname FROM staff LEFT JOIN staffworkposition ON staff.staffworkid = staffworkposition.staffworkid LEFT JOIN room ON staff.roomid = room.roomid LEFT JOIN floor ON staff.floorid = floor.floorid ORDER BY staff.staffid ASC;";
           
            st = con.createStatement();
            ResultSet rs = st.executeQuery(ss);
             
             DefaultTableModel model = (DefaultTableModel) tblStaff.getModel();
            while (rs.next()) {
                
                Object[] row = new Object[7];     
                row[0] = rs.getString("staffid");
                row[1]= rs.getString("stafffn");
                row[2]= rs.getString("staffln");
                row[3]= rs.getString("staffmn");
                row[4]= rs.getString("staffworkpositionname");
                row[5]= rs.getString("roomname");
                row[6]= rs.getString("floorname");
                 model.addRow(row);
               
              
  
            }
        }catch (ClassNotFoundException | SQLException ex) {
            Logger.getLogger(AdminDashboard.class.getName()).log(Level.SEVERE, null, ex);
        }
         }          




public void getallnums(){
    countroomcat();
    countroom();
    countstaff();
    countstaffposition();
    fetchtableingeneral();
}

 public void DigitalClock() {
     
      
        ActionListener actionListener = new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                //Time in 24Hrs Format
              
                
                //Time in 12Hrs Format
                Date date1 = new Date();
                DateFormat timeFormat1 = new SimpleDateFormat("hh:mm:ss ");
                String time1 = timeFormat1.format(date1);
                timelabel.setText(time1);
                
                //Todays Date
                Date date2 = new Date();
                DateFormat timeFormat2 = new SimpleDateFormat("MMM dd,yyyy");
                String time2 = timeFormat2.format(date2);
                datelabel.setText(time2);
                
               
            }
        };
        timer = new Timer(1000, actionListener);
        timer.setInitialDelay(0);
        timer.start();
    }  



public void fetchtableingeneral(){
    
     DefaultTableModel model1 = (DefaultTableModel) tblSumRoom.getModel();
                    model1.setRowCount(0);
           try {
            Class.forName("com.mysql.jdbc.Driver");
            con = DriverManager.getConnection("jdbc:mysql://localhost:3306/systemdatabase?zeroDateTimeBehavior=convertToNull", "root", "");
    
             String ss= "SELECT staff.staffid, CONCAT(staff.stafffn,' ',staff.staffmn,' ',staff.staffln) AS 'Staff Name', staffworkposition.staffworkpositionname, room.roomname, roomcategory.roomcategoryname, floor.floorname FROM staff LEFT JOIN staffworkposition ON staff.staffworkid = staffworkposition.staffworkid LEFT JOIN room ON staff.roomid = room.roomid LEFT JOIN roomcategory ON room.roomcategoryid = roomcategory.roomcategoryid LEFT JOIN floor ON room.floorid = floor.floorid ORDER BY staff.staffid ASC;";
           
            st = con.createStatement();
            ResultSet rs = st.executeQuery(ss);
             
             DefaultTableModel model = (DefaultTableModel) tblSumRoom.getModel();
            while (rs.next()) {
                
                Object[] row = new Object[5];
                row[0] = rs.getString("Staff Name");
                row[1]= rs.getString("staffworkpositionname");
                row[2]= rs.getString("roomname");
                row[3]= rs.getString("roomcategoryname");
                row[4]= rs.getString("floorname");
                 model.addRow(row);               

            }
        }catch (ClassNotFoundException | SQLException ex) {
            Logger.getLogger(AdminDashboard.class.getName()).log(Level.SEVERE, null, ex);
        }
    
}

private void SaveTransaction() {
        
       try{
               Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/systemdatabase?zeroDateTimeBehavior=convertToNull", "root", "");
               PreparedStatement ps = con.prepareStatement("insert into transaction(transactiontitle, roomid) values(?,?)");
               
               
                String titlename = TransactionTitleTextfield.getText().trim().replace("'", "''");
                String roomname = RoomtranTextfield.getText().trim().replace("'", "''");
                getroomid(roomname);

               ps.setString(1, titlename);
               ps.setString(2,roid);
              
               
               
               if(ps.executeUpdate() == 1 ){
               JOptionPane.showMessageDialog(null, "Transaction Title Added");
               getroom();
		}
		else{
			 JOptionPane.showMessageDialog(null, "Failed to Add Transaction Title");
			}
           }catch(Exception ex){
               ex.printStackTrace();
           }
	roid =null;
	stid = null;
	flrid = null;

    }

public void tblchooser(){
  

switch(whattable)
{
case "1":
 DefaultTableModel model = (DefaultTableModel)tblSumRoom.getModel();
        int rows = model.getRowCount();

        for (int i = 0; i < rows; i++) {
            for (int j = 0; j < model.getColumnCount(); j++) {
                Object ob = model.getValueAt(i, j);
                if (ob == null || ob.toString().isEmpty()) {
                    model.setValueAt("NONE", i, j);
                }
            }
        }
break;

case "2":
 DefaultTableModel model2 = (DefaultTableModel)tblroom.getModel();
        int rows2 = model2.getRowCount();

        for (int i = 0; i < rows2; i++) {
            for (int j = 0; j < model2.getColumnCount(); j++) {
                Object ob = model2.getValueAt(i, j);
                if (ob == null || ob.toString().isEmpty()) {
                    model2.setValueAt("NONE", i, j);
                }
            }
        }
      
break;



case "3":
 DefaultTableModel model4 = (DefaultTableModel)tblStaff.getModel();
        int rows4 = model4.getRowCount();

        for (int i = 0; i < rows4; i++) {
            for (int j = 0; j < model4.getColumnCount(); j++) {
                Object ob = model4.getValueAt(i, j);
                if (ob == null || ob.toString().isEmpty()) {
                    model4.setValueAt("NONE", i, j);
                }
            }
        }


break;

case "4":
 DefaultTableModel model5 = (DefaultTableModel)tbltransactiontitle.getModel();
        int rows5 = model5.getRowCount();

        for (int i = 0; i < rows5; i++) {
            for (int j = 0; j < model5.getColumnCount(); j++) {
                Object ob = model5.getValueAt(i, j);
                if (ob == null || ob.toString().isEmpty()) {
                    model5.setValueAt("NONE", i, j);
                }
            }
        }


break;

}
whattable = null;
}


	public void tableselector(){

	if(GeneralPanel.isVisible()){
		whattable = "1";
		
	}
	else if(RoomPanel.isVisible()){
		whattable = "2";
		
	}
	else if(StaffPanel.isVisible()){
		whattable = "3";
		
	}
        else if (TransactionPanel.isVisible()){
            whattable="4";
        }
        tblchooser();	
	}

    public void getranstitle(){
        DefaultTableModel model1 = (DefaultTableModel) tbltransactiontitle.getModel();
                    model1.setRowCount(0);
           try {
            Class.forName("com.mysql.jdbc.Driver");
            con = DriverManager.getConnection("jdbc:mysql://localhost:3306/systemdatabase?zeroDateTimeBehavior=convertToNull", "root", "");
    
             String ss= "SELECT `transaction`.`transactionid`, `transaction`.`transactiontitle`, room.roomname FROM transaction LEFT JOIN room ON `transaction`.`roomid` = room.roomid ORDER BY transaction.transactionid ASC;";
           
            st = con.createStatement();
            ResultSet rs = st.executeQuery(ss);
             
             DefaultTableModel model = (DefaultTableModel) tbltransactiontitle.getModel();
            while (rs.next()) {
                
                Object[] row = new Object[3];
                row[0] = rs.getString("transactionid");
                row[1]= rs.getString("transactiontitle");
                row[2]= rs.getString("roomname");
              
               
                 model.addRow(row);
                 clear();
            }
        }catch (ClassNotFoundException | SQLException  | NullPointerException ex) {
            Logger.getLogger(AdminDashboard.class.getName()).log(Level.SEVERE, null, ex);
       
        }
    
         }            
        
        
private void deletetransaction(String rid) {

       try {
           Class.forName("com.mysql.jdbc.Driver");
            con = DriverManager.getConnection("jdbc:mysql://localhost:3306/systemdatabase?zeroDateTimeBehavior=convertToNull", "root", "");
            String sql = "DELETE FROM `transaction` WHERE transactionid='" + rid + "'";
          st = con.createStatement();

           if (st.execute(sql) != true) {
               alert("Transaction Title Deleted");
           } else {
               alert("Transaction Title Deletion Failed");
           }

        } catch (ClassNotFoundException | SQLException ex) {
            Logger.getLogger(AdminDashboard.class.getName()).log(Level.SEVERE, null, ex);
        }
        getranstitle();
   }

private void transactiontitlechecker(){
     int i = tbltransactiontitle.getSelectedRow();
    TableModel tblmodel = tbltransactiontitle.getModel();
     
     String title = tblmodel.getValueAt(i, 1).toString().trim();
     String room = tblmodel.getValueAt(i, 2).toString().trim();
     
      try {
            
            Class.forName("com.mysql.jdbc.Driver");
            con = DriverManager.getConnection("jdbc:mysql://localhost:3306/systemdatabase?zeroDateTimeBehavior=convertToNull", "root", "");
            String titlename = TransactionTitleTextfield.getText().trim().replace("'", "''");          
            String roomname = RoomtranTextfield.getText().toString().trim();
            String ss= "SELECT * FROM transaction WHERE transactiontitle != '"+titlename+"';";

            st = con.createStatement();
            ResultSet rs = st.executeQuery(ss);

            if (rs.first()){
                if(!rs.getString("transactiontitle").equals(title) || !roomname.equals(room)){
                updatetransactionTitle();
            }
            else{
                 alert("Transaction Title Already Exist");
            }
                
            }
            else{
               alert("Transaction Title Already Exist LAST CHECKPOINT");
            }

        }catch (ClassNotFoundException | SQLException ex) {
            Logger.getLogger(AdminDashboard.class.getName()).log(Level.SEVERE, null, ex);
        }
      
}

private void updatetransactionTitle(){
    int i = tbltransactiontitle.getSelectedRow();
    TableModel tblmodel = tbltransactiontitle.getModel();
     
     int id = Integer.valueOf(tblmodel.getValueAt(i, 0).toString().trim());
      try{
               Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/systemdatabase?zeroDateTimeBehavior=convertToNull", "root", "");
               PreparedStatement ps = con.prepareStatement("update transaction set transactiontitle = ?, roomid = ? WHERE transactionid= '"+id+"'");
             String title = TransactionTitleTextfield.getText().trim().replace("'", "''");
             String roomname = RoomtranTextfield.getText().trim().replace("'", "''");
             getroomid(roomname);
             
               ps.setString(1, title);
               ps.setString(2, roid);
            
               if(ps.executeUpdate() == 1){
                 alert("Room Title Updated");
               }
               else{
                   alert("Room Title already exist");
               }
               getranstitle();
           }catch(Exception ex){
               ex.printStackTrace();
           }
}

}






