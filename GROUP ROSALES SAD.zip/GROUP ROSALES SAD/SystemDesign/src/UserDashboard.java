
import com.formdev.flatlaf.FlatIntelliJLaf;
import java.awt.Color;
import java.awt.Image;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Collections;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.AbstractButton;
import javax.swing.DefaultListModel;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JOptionPane;
import javax.swing.UIManager;
import javax.swing.table.DefaultTableModel;


public class UserDashboard extends javax.swing.JFrame {

   Connection con;
    Statement st;
    final String classfor = "com.mysql.jdbc.Driver";
    final String connect = "jdbc:mysql://localhost:3306/systemdatabase?zeroDateTimeBehavior=convertToNull";
    final String username = "root";
    final String password = "";
    
    
    
    public UserDashboard() {
        initComponents();
        
        startup();
        fetchall();
    }

   
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        buttonGroup1 = new javax.swing.ButtonGroup();
        WholePanel = new javax.swing.JPanel();
        TopPanel = new javax.swing.JPanel();
        jLabel1 = new javax.swing.JLabel();
        jButton1 = new javax.swing.JButton();
        ContainerPanel = new javax.swing.JPanel();
        MenuPanel = new javax.swing.JPanel();
        SearchRoomLabel = new javax.swing.JLabel();
        TransactionLabel = new javax.swing.JLabel();
        WelcomeUser = new javax.swing.JLabel();
        btnMap = new javax.swing.JButton();
        btnTransaction = new javax.swing.JButton();
        MapPanel = new javax.swing.JPanel();
        contentPanel = new javax.swing.JPanel();
        Floorone = new javax.swing.JPanel();
        afa_office = new javax.swing.JButton();
        chemlabroom = new javax.swing.JButton();
        skulbox_canteen = new javax.swing.JButton();
        entrancetosh = new javax.swing.JButton();
        canteen = new javax.swing.JButton();
        tle = new javax.swing.JButton();
        registrar_office = new javax.swing.JButton();
        cashier_office = new javax.swing.JButton();
        president_office = new javax.swing.JButton();
        guidance_room = new javax.swing.JButton();
        guidance = new javax.swing.JButton();
        accounting_office = new javax.swing.JButton();
        seniorhigh = new javax.swing.JButton();
        stage = new javax.swing.JButton();
        cr1_male = new javax.swing.JButton();
        skulbox_schoolsupplies = new javax.swing.JButton();
        cafeteria = new javax.swing.JButton();
        stairs = new javax.swing.JButton();
        clinic = new javax.swing.JButton();
        registrar_stockroom = new javax.swing.JButton();
        maingate = new javax.swing.JButton();
        hslibrary = new javax.swing.JButton();
        cr2_female = new javax.swing.JButton();
        second_floor = new javax.swing.JButton();
        library_extension = new javax.swing.JButton();
        rented_space = new javax.swing.JButton();
        stair_outside = new javax.swing.JButton();
        tato = new javax.swing.JButton();
        custodian_stockroom = new javax.swing.JButton();
        stairs2 = new javax.swing.JButton();
        quadrangle = new javax.swing.JLabel();
        fe1 = new javax.swing.JLabel();
        fe2 = new javax.swing.JLabel();
        line1 = new javax.swing.JLabel();
        line2 = new javax.swing.JLabel();
        line3 = new javax.swing.JLabel();
        line4 = new javax.swing.JLabel();
        line5 = new javax.swing.JLabel();
        Floortwo = new javax.swing.JPanel();
        jButton36 = new javax.swing.JButton();
        jButton37 = new javax.swing.JButton();
        jButton38 = new javax.swing.JButton();
        jButton39 = new javax.swing.JButton();
        jButton40 = new javax.swing.JButton();
        jButton41 = new javax.swing.JButton();
        jButton42 = new javax.swing.JButton();
        jButton43 = new javax.swing.JButton();
        jButton45 = new javax.swing.JButton();
        jButton46 = new javax.swing.JButton();
        jButton49 = new javax.swing.JButton();
        jButton50 = new javax.swing.JButton();
        jButton51 = new javax.swing.JButton();
        jButton52 = new javax.swing.JButton();
        jButton53 = new javax.swing.JButton();
        jButton54 = new javax.swing.JButton();
        jButton55 = new javax.swing.JButton();
        jButton56 = new javax.swing.JButton();
        jButton57 = new javax.swing.JButton();
        jButton58 = new javax.swing.JButton();
        jButton59 = new javax.swing.JButton();
        jButton60 = new javax.swing.JButton();
        jButton61 = new javax.swing.JButton();
        jButton63 = new javax.swing.JButton();
        jButton64 = new javax.swing.JButton();
        jButton65 = new javax.swing.JButton();
        jLabel10 = new javax.swing.JLabel();
        jLabel11 = new javax.swing.JLabel();
        jLabel12 = new javax.swing.JLabel();
        jLabel13 = new javax.swing.JLabel();
        Floorthree = new javax.swing.JPanel();
        jButton113 = new javax.swing.JButton();
        jButton111 = new javax.swing.JButton();
        jButton123 = new javax.swing.JButton();
        jButton124 = new javax.swing.JButton();
        jButton120 = new javax.swing.JButton();
        jButton121 = new javax.swing.JButton();
        jButton129 = new javax.swing.JButton();
        jButton130 = new javax.swing.JButton();
        jButton132 = new javax.swing.JButton();
        jButton133 = new javax.swing.JButton();
        jButton134 = new javax.swing.JButton();
        jButton153 = new javax.swing.JButton();
        jButton154 = new javax.swing.JButton();
        jButton155 = new javax.swing.JButton();
        jButton156 = new javax.swing.JButton();
        jButton157 = new javax.swing.JButton();
        jButton158 = new javax.swing.JButton();
        jButton115 = new javax.swing.JButton();
        jButton160 = new javax.swing.JButton();
        jButton161 = new javax.swing.JButton();
        jButton162 = new javax.swing.JButton();
        jButton116 = new javax.swing.JButton();
        jButton159 = new javax.swing.JButton();
        jButton118 = new javax.swing.JButton();
        jButton119 = new javax.swing.JButton();
        jButton122 = new javax.swing.JButton();
        Floorfour = new javax.swing.JPanel();
        jButton135 = new javax.swing.JButton();
        jButton136 = new javax.swing.JButton();
        jButton137 = new javax.swing.JButton();
        jButton112 = new javax.swing.JButton();
        jButton138 = new javax.swing.JButton();
        jButton139 = new javax.swing.JButton();
        jButton140 = new javax.swing.JButton();
        jButton141 = new javax.swing.JButton();
        jButton142 = new javax.swing.JButton();
        jButton143 = new javax.swing.JButton();
        jButton144 = new javax.swing.JButton();
        jButton145 = new javax.swing.JButton();
        jButton146 = new javax.swing.JButton();
        jButton147 = new javax.swing.JButton();
        jButton148 = new javax.swing.JButton();
        jButton114 = new javax.swing.JButton();
        jButton149 = new javax.swing.JButton();
        jButton150 = new javax.swing.JButton();
        jButton151 = new javax.swing.JButton();
        jButton152 = new javax.swing.JButton();
        FloorFifth = new javax.swing.JPanel();
        jButton81 = new javax.swing.JButton();
        jButton82 = new javax.swing.JButton();
        jButton84 = new javax.swing.JButton();
        jButton85 = new javax.swing.JButton();
        jButton86 = new javax.swing.JButton();
        jButton87 = new javax.swing.JButton();
        jButton88 = new javax.swing.JButton();
        jButton89 = new javax.swing.JButton();
        jButton90 = new javax.swing.JButton();
        jButton91 = new javax.swing.JButton();
        jButton92 = new javax.swing.JButton();
        jButton93 = new javax.swing.JButton();
        btn1 = new javax.swing.JButton();
        btn2 = new javax.swing.JButton();
        btn5 = new javax.swing.JButton();
        btn3 = new javax.swing.JButton();
        btn4 = new javax.swing.JButton();
        WelcomeUser1 = new javax.swing.JLabel();
        searchbtn = new javax.swing.JButton();
        searchtext = new javax.swing.JTextField();
        jButton2 = new javax.swing.JButton();
        SearchTransaction = new javax.swing.JPanel();
        SearchTransactionLabel = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setBackground(new java.awt.Color(29, 118, 90));
        setMinimumSize(new java.awt.Dimension(1366, 670));
        setUndecorated(true);
        setResizable(false);
        setSize(new java.awt.Dimension(1370, 670));

        WholePanel.setBackground(new java.awt.Color(29, 118, 90));
        WholePanel.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        TopPanel.setBackground(new java.awt.Color(33, 88, 71));
        TopPanel.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jLabel1.setFont(new java.awt.Font("SansSerif", 3, 28)); // NOI18N
        jLabel1.setForeground(new java.awt.Color(255, 255, 255));
        jLabel1.setText("CRMC Mapping and Information System");
        TopPanel.add(jLabel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 20, 550, 50));

        jButton1.setFont(new java.awt.Font("Segoe UI Light", 0, 18)); // NOI18N
        jButton1.setForeground(new java.awt.Color(255, 255, 255));
        jButton1.setText("RETURN");
        jButton1.setBorderPainted(false);
        jButton1.setContentAreaFilled(false);
        jButton1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton1ActionPerformed(evt);
            }
        });
        TopPanel.add(jButton1, new org.netbeans.lib.awtextra.AbsoluteConstraints(1230, 30, 120, 30));

        WholePanel.add(TopPanel, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 1380, 100));

        ContainerPanel.setBackground(new java.awt.Color(29, 118, 90));
        ContainerPanel.setMaximumSize(new java.awt.Dimension(1370, 570));
        ContainerPanel.setMinimumSize(new java.awt.Dimension(1370, 570));
        ContainerPanel.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        MenuPanel.setBackground(new java.awt.Color(29, 118, 90));
        MenuPanel.setMinimumSize(new java.awt.Dimension(1370, 570));
        MenuPanel.setName(""); // NOI18N
        MenuPanel.setPreferredSize(new java.awt.Dimension(1370, 570));
        MenuPanel.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        SearchRoomLabel.setBackground(new java.awt.Color(41, 150, 116));
        SearchRoomLabel.setFont(new java.awt.Font("Segoe UI Light", 0, 24)); // NOI18N
        SearchRoomLabel.setForeground(new java.awt.Color(255, 255, 255));
        SearchRoomLabel.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        SearchRoomLabel.setText("PREVIEW MAP");
        SearchRoomLabel.setOpaque(true);
        MenuPanel.add(SearchRoomLabel, new org.netbeans.lib.awtextra.AbsoluteConstraints(430, 100, 252, 60));

        TransactionLabel.setBackground(new java.awt.Color(41, 150, 116));
        TransactionLabel.setFont(new java.awt.Font("Segoe UI Light", 0, 18)); // NOI18N
        TransactionLabel.setForeground(new java.awt.Color(255, 255, 255));
        TransactionLabel.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        TransactionLabel.setText("TRANSACTION INFORMATION");
        TransactionLabel.setOpaque(true);
        MenuPanel.add(TransactionLabel, new org.netbeans.lib.awtextra.AbsoluteConstraints(780, 100, 252, 60));

        WelcomeUser.setFont(new java.awt.Font("Segoe UI Light", 0, 28)); // NOI18N
        WelcomeUser.setForeground(new java.awt.Color(255, 255, 255));
        WelcomeUser.setText("WELCOME USER");
        MenuPanel.add(WelcomeUser, new org.netbeans.lib.awtextra.AbsoluteConstraints(604, 24, 208, 44));

        btnMap.setBackground(new java.awt.Color(38, 136, 105));
        btnMap.setIcon(new javax.swing.ImageIcon(getClass().getResource("/icon/mapicon.png"))); // NOI18N
        btnMap.setBorder(null);
        btnMap.setBorderPainted(false);
        btnMap.setCursor(new java.awt.Cursor(java.awt.Cursor.DEFAULT_CURSOR));
        btnMap.setFocusPainted(false);
        btnMap.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnMapActionPerformed(evt);
            }
        });
        MenuPanel.add(btnMap, new org.netbeans.lib.awtextra.AbsoluteConstraints(430, 100, 252, 312));

        btnTransaction.setBackground(new java.awt.Color(38, 136, 105));
        btnTransaction.setIcon(new javax.swing.ImageIcon(getClass().getResource("/icon/bookicon.png"))); // NOI18N
        btnTransaction.setBorder(null);
        btnTransaction.setBorderPainted(false);
        btnTransaction.setFocusPainted(false);
        btnTransaction.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnTransactionActionPerformed(evt);
            }
        });
        MenuPanel.add(btnTransaction, new org.netbeans.lib.awtextra.AbsoluteConstraints(780, 100, 252, 312));

        ContainerPanel.add(MenuPanel, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 100, 1370, 630));

        MapPanel.setBackground(new java.awt.Color(29, 118, 90));
        MapPanel.setMinimumSize(new java.awt.Dimension(1370, 570));
        MapPanel.setName(""); // NOI18N
        MapPanel.setPreferredSize(new java.awt.Dimension(1370, 570));
        MapPanel.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        contentPanel.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        Floorone.setBackground(new java.awt.Color(0, 66, 38));
        Floorone.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        afa_office.setText("AFA BUILDING");
        buttonGroup1.add(afa_office);
        afa_office.setFocusPainted(false);
        afa_office.setFocusable(false);
        Floorone.add(afa_office, new org.netbeans.lib.awtextra.AbsoluteConstraints(190, 36, 236, 80));

        chemlabroom.setText("Chemistry Lab Classroom");
        chemlabroom.setFocusPainted(false);
        chemlabroom.setFocusable(false);
        Floorone.add(chemlabroom, new org.netbeans.lib.awtextra.AbsoluteConstraints(1060, 373, 110, 138));

        skulbox_canteen.setText("SKULBOX(CANTTEN)");
        skulbox_canteen.setFocusPainted(false);
        skulbox_canteen.setFocusable(false);
        Floorone.add(skulbox_canteen, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 0, 190, 39));

        entrancetosh.setText("Entrance to SH BLDG");
        entrancetosh.setFocusPainted(false);
        entrancetosh.setFocusable(false);
        Floorone.add(entrancetosh, new org.netbeans.lib.awtextra.AbsoluteConstraints(508, 253, 145, 50));

        canteen.setText("CANTEEN");
        canteen.setFocusPainted(false);
        canteen.setFocusable(false);
        Floorone.add(canteen, new org.netbeans.lib.awtextra.AbsoluteConstraints(403, 390, 130, 90));

        tle.setText("TLE/FOOD");
        tle.setFocusPainted(false);
        tle.setFocusable(false);
        Floorone.add(tle, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 36, 140, 110));

        registrar_office.setText("REGISTRAR");
        buttonGroup1.add(registrar_office);
        registrar_office.setFocusPainted(false);
        registrar_office.setFocusable(false);
        Floorone.add(registrar_office, new org.netbeans.lib.awtextra.AbsoluteConstraints(170, 390, 100, 90));

        cashier_office.setText("CASHIER");
        buttonGroup1.add(cashier_office);
        cashier_office.setFocusPainted(false);
        cashier_office.setFocusable(false);
        Floorone.add(cashier_office, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 332, 110, 91));

        president_office.setText("PRESIDENT/ VP");
        buttonGroup1.add(president_office);
        president_office.setFocusPainted(false);
        president_office.setFocusable(false);
        Floorone.add(president_office, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 143, 140, 100));

        guidance_room.setText("GUIDANCE ROOM");
        guidance_room.setFocusPainted(false);
        guidance_room.setFocusable(false);
        guidance_room.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                guidance_roomActionPerformed(evt);
            }
        });
        Floorone.add(guidance_room, new org.netbeans.lib.awtextra.AbsoluteConstraints(887, 420, 176, 60));

        guidance.setText("GUIDANCE");
        guidance.setFocusPainted(false);
        guidance.setFocusable(false);
        guidance.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                guidanceActionPerformed(evt);
            }
        });
        Floorone.add(guidance, new org.netbeans.lib.awtextra.AbsoluteConstraints(887, 373, 99, 50));

        accounting_office.setText("ACCOUNTING");
        buttonGroup1.add(accounting_office);
        accounting_office.setFocusPainted(false);
        accounting_office.setFocusable(false);
        Floorone.add(accounting_office, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 240, 140, 95));

        seniorhigh.setText("SENIOR HIGH");
        seniorhigh.setFocusPainted(false);
        seniorhigh.setFocusable(false);
        seniorhigh.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                seniorhighActionPerformed(evt);
            }
        });
        Floorone.add(seniorhigh, new org.netbeans.lib.awtextra.AbsoluteConstraints(780, 180, 163, 75));

        stage.setText("STAGE");
        stage.setFocusPainted(false);
        stage.setFocusable(false);
        Floorone.add(stage, new org.netbeans.lib.awtextra.AbsoluteConstraints(230, 113, 180, 50));

        cr1_male.setText("CR1(MALE)");
        cr1_male.setFocusPainted(false);
        cr1_male.setFocusable(false);
        Floorone.add(cr1_male, new org.netbeans.lib.awtextra.AbsoluteConstraints(423, 25, 230, 40));

        skulbox_schoolsupplies.setFont(new java.awt.Font("Tahoma", 0, 10)); // NOI18N
        skulbox_schoolsupplies.setText("SKULBOX SCHOOL SUPPLIES");
        skulbox_schoolsupplies.setFocusPainted(false);
        skulbox_schoolsupplies.setFocusable(false);
        skulbox_schoolsupplies.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                skulbox_schoolsuppliesActionPerformed(evt);
            }
        });
        Floorone.add(skulbox_schoolsupplies, new org.netbeans.lib.awtextra.AbsoluteConstraints(473, 99, 180, 60));

        cafeteria.setText("CAFETERIA");
        cafeteria.setFocusPainted(false);
        cafeteria.setFocusable(false);
        cafeteria.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                cafeteriaActionPerformed(evt);
            }
        });
        Floorone.add(cafeteria, new org.netbeans.lib.awtextra.AbsoluteConstraints(473, 156, 180, 100));

        stairs.setIcon(new javax.swing.ImageIcon(getClass().getResource("/icon/stairs.png"))); // NOI18N
        stairs.setBorderPainted(false);
        stairs.setFocusPainted(false);
        stairs.setFocusable(false);
        Floorone.add(stairs, new org.netbeans.lib.awtextra.AbsoluteConstraints(-2, 420, 120, 60));

        clinic.setText("CLINIC");
        clinic.setFocusPainted(false);
        clinic.setFocusable(false);
        Floorone.add(clinic, new org.netbeans.lib.awtextra.AbsoluteConstraints(983, 373, 80, 50));

        registrar_stockroom.setFont(new java.awt.Font("Segoe UI Semilight", 0, 9)); // NOI18N
        registrar_stockroom.setText("Registrars Stockroom");
        registrar_stockroom.setFocusPainted(false);
        registrar_stockroom.setFocusable(false);
        Floorone.add(registrar_stockroom, new org.netbeans.lib.awtextra.AbsoluteConstraints(650, 266, 120, 50));

        maingate.setText("MAIN GATE");
        maingate.setFocusPainted(false);
        maingate.setFocusable(false);
        Floorone.add(maingate, new org.netbeans.lib.awtextra.AbsoluteConstraints(260, 470, 150, 35));

        hslibrary.setText("HS LIBRARY");
        hslibrary.setFocusPainted(false);
        hslibrary.setFocusable(false);
        Floorone.add(hslibrary, new org.netbeans.lib.awtextra.AbsoluteConstraints(530, 390, 360, 90));

        cr2_female.setText("CR2()FEMALE");
        cr2_female.setFocusPainted(false);
        cr2_female.setFocusable(false);
        Floorone.add(cr2_female, new org.netbeans.lib.awtextra.AbsoluteConstraints(473, 62, 180, 40));

        second_floor.setText("2ND FLOOR");
        second_floor.setFocusPainted(false);
        second_floor.setFocusable(false);
        Floorone.add(second_floor, new org.netbeans.lib.awtextra.AbsoluteConstraints(556, 300, 100, 60));

        library_extension.setFont(new java.awt.Font("Tahoma", 0, 12)); // NOI18N
        library_extension.setText("LIBRARY EXTENSION");
        library_extension.setFocusPainted(false);
        library_extension.setFocusable(false);
        Floorone.add(library_extension, new org.netbeans.lib.awtextra.AbsoluteConstraints(650, 313, 240, 80));

        rented_space.setText("RENTED SPACE");
        rented_space.setFocusPainted(false);
        rented_space.setFocusable(false);
        Floorone.add(rented_space, new org.netbeans.lib.awtextra.AbsoluteConstraints(930, 280, 130, 80));

        stair_outside.setIcon(new javax.swing.ImageIcon(getClass().getResource("/icon/stairs.png"))); // NOI18N
        stair_outside.setBorderPainted(false);
        stair_outside.setContentAreaFilled(false);
        stair_outside.setFocusPainted(false);
        stair_outside.setFocusable(false);
        Floorone.add(stair_outside, new org.netbeans.lib.awtextra.AbsoluteConstraints(890, 480, 60, 30));

        tato.setText("T.A.T.O");
        tato.setFocusPainted(false);
        tato.setFocusable(false);
        Floorone.add(tato, new org.netbeans.lib.awtextra.AbsoluteConstraints(940, 191, 120, 50));

        custodian_stockroom.setFont(new java.awt.Font("Segoe UI Semilight", 0, 9)); // NOI18N
        custodian_stockroom.setText("Custodian's Stockroom");
        custodian_stockroom.setFocusPainted(false);
        custodian_stockroom.setFocusable(false);
        custodian_stockroom.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                custodian_stockroomActionPerformed(evt);
            }
        });
        Floorone.add(custodian_stockroom, new org.netbeans.lib.awtextra.AbsoluteConstraints(770, 266, 130, 50));

        stairs2.setIcon(new javax.swing.ImageIcon(getClass().getResource("/icon/stairs.png"))); // NOI18N
        stairs2.setText("STAIRS");
        stairs2.setBorderPainted(false);
        stairs2.setContentAreaFilled(false);
        stairs2.setFocusPainted(false);
        stairs2.setFocusable(false);
        Floorone.add(stairs2, new org.netbeans.lib.awtextra.AbsoluteConstraints(508, 300, 51, 60));

        quadrangle.setFont(new java.awt.Font("Segoe UI Historic", 1, 11)); // NOI18N
        quadrangle.setForeground(new java.awt.Color(255, 255, 255));
        quadrangle.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        quadrangle.setText("QUADRANGLE / ACTIVITY CENTER");
        quadrangle.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(255, 255, 255)));
        quadrangle.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        Floorone.add(quadrangle, new org.netbeans.lib.awtextra.AbsoluteConstraints(170, 180, 280, 190));

        fe1.setBackground(new java.awt.Color(255, 255, 255));
        fe1.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        fe1.setText("FE");
        fe1.setFocusable(false);
        fe1.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        fe1.setOpaque(true);
        Floorone.add(fe1, new org.netbeans.lib.awtextra.AbsoluteConstraints(1030, 240, 50, 50));

        fe2.setBackground(new java.awt.Color(255, 255, 255));
        fe2.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        fe2.setText("FE");
        fe2.setFocusable(false);
        fe2.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        fe2.setOpaque(true);
        Floorone.add(fe2, new org.netbeans.lib.awtextra.AbsoluteConstraints(420, 70, 30, 40));

        line1.setBackground(new java.awt.Color(255, 255, 255));
        line1.setFocusable(false);
        line1.setInheritsPopupMenu(false);
        line1.setOpaque(true);
        Floorone.add(line1, new org.netbeans.lib.awtextra.AbsoluteConstraints(1050, 280, 5, 100));

        line2.setBackground(new java.awt.Color(255, 255, 255));
        line2.setFocusable(false);
        line2.setInheritsPopupMenu(false);
        line2.setOpaque(true);
        Floorone.add(line2, new org.netbeans.lib.awtextra.AbsoluteConstraints(940, 240, 90, 5));

        line3.setBackground(new java.awt.Color(255, 255, 255));
        line3.setFocusable(false);
        line3.setInheritsPopupMenu(false);
        line3.setOpaque(true);
        Floorone.add(line3, new org.netbeans.lib.awtextra.AbsoluteConstraints(932, 282, 5, 100));

        line4.setBackground(new java.awt.Color(255, 255, 255));
        line4.setFocusable(false);
        line4.setInheritsPopupMenu(false);
        line4.setOpaque(true);
        Floorone.add(line4, new org.netbeans.lib.awtextra.AbsoluteConstraints(118, 474, 60, 5));

        line5.setBackground(new java.awt.Color(255, 255, 255));
        line5.setFocusable(false);
        line5.setInheritsPopupMenu(false);
        line5.setOpaque(true);
        Floorone.add(line5, new org.netbeans.lib.awtextra.AbsoluteConstraints(650, 240, 140, 5));

        contentPanel.add(Floorone, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 1170, 510));

        Floortwo.setBackground(new java.awt.Color(0, 66, 38));
        Floortwo.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jButton36.setText("jButton35");
        Floortwo.add(jButton36, new org.netbeans.lib.awtextra.AbsoluteConstraints(519, 67, 230, 78));

        jButton37.setText("jButton35");
        jButton37.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton37ActionPerformed(evt);
            }
        });
        Floortwo.add(jButton37, new org.netbeans.lib.awtextra.AbsoluteConstraints(1020, 360, 150, 150));

        jButton38.setText("IV-GRAPES");
        jButton38.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton38ActionPerformed(evt);
            }
        });
        Floortwo.add(jButton38, new org.netbeans.lib.awtextra.AbsoluteConstraints(228, 400, 140, 110));

        jButton39.setText("jButton35");
        jButton39.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton39ActionPerformed(evt);
            }
        });
        Floortwo.add(jButton39, new org.netbeans.lib.awtextra.AbsoluteConstraints(365, 400, 140, 110));

        jButton40.setText("jButton35");
        jButton40.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton40ActionPerformed(evt);
            }
        });
        Floortwo.add(jButton40, new org.netbeans.lib.awtextra.AbsoluteConstraints(502, 400, 140, 110));

        jButton41.setText("jButton35");
        jButton41.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton41ActionPerformed(evt);
            }
        });
        Floortwo.add(jButton41, new org.netbeans.lib.awtextra.AbsoluteConstraints(639, 400, 110, 110));

        jButton42.setText("jButton35");
        jButton42.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton42ActionPerformed(evt);
            }
        });
        Floortwo.add(jButton42, new org.netbeans.lib.awtextra.AbsoluteConstraints(746, 400, 140, 110));

        jButton43.setText("jButton35");
        jButton43.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton43ActionPerformed(evt);
            }
        });
        Floortwo.add(jButton43, new org.netbeans.lib.awtextra.AbsoluteConstraints(883, 400, 140, 110));

        jButton45.setText("jButton35");
        Floortwo.add(jButton45, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 343, 150, 120));

        jButton46.setText("jButton35");
        Floortwo.add(jButton46, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 216, 150, 130));

        jButton49.setText("jButton35");
        Floortwo.add(jButton49, new org.netbeans.lib.awtextra.AbsoluteConstraints(559, 293, 190, 70));

        jButton50.setText("jButton35");
        Floortwo.add(jButton50, new org.netbeans.lib.awtextra.AbsoluteConstraints(519, 219, 230, 77));

        jButton51.setText("jButton35");
        jButton51.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton51ActionPerformed(evt);
            }
        });
        Floortwo.add(jButton51, new org.netbeans.lib.awtextra.AbsoluteConstraints(519, 142, 230, 80));

        jButton52.setText("jButton35");
        Floortwo.add(jButton52, new org.netbeans.lib.awtextra.AbsoluteConstraints(1090, 70, -1, -1));

        jButton53.setText("jButton35");
        Floortwo.add(jButton53, new org.netbeans.lib.awtextra.AbsoluteConstraints(620, 0, 130, 70));

        jButton54.setText("jButton35");
        Floortwo.add(jButton54, new org.netbeans.lib.awtextra.AbsoluteConstraints(493, 0, 130, 70));

        jButton55.setText("jButton35");
        Floortwo.add(jButton55, new org.netbeans.lib.awtextra.AbsoluteConstraints(1020, 163, 150, 200));

        jButton56.setText("HS COMLAB 1");
        Floortwo.add(jButton56, new org.netbeans.lib.awtextra.AbsoluteConstraints(923, 163, 100, 199));

        jButton57.setText("COC Dean's Office");
        Floortwo.add(jButton57, new org.netbeans.lib.awtextra.AbsoluteConstraints(746, 262, 180, 100));

        jButton58.setText("jButton35");
        Floortwo.add(jButton58, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, -1, 220, 220));

        jButton59.setIcon(new javax.swing.ImageIcon(getClass().getResource("/icon/stairs.png"))); // NOI18N
        Floortwo.add(jButton59, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 460, 110, 50));

        jButton60.setText("FE");
        Floortwo.add(jButton60, new org.netbeans.lib.awtextra.AbsoluteConstraints(746, 242, 50, -1));

        jButton61.setText("jButton35");
        Floortwo.add(jButton61, new org.netbeans.lib.awtextra.AbsoluteConstraints(1090, 100, -1, 60));

        jButton63.setText("jButton35");
        Floortwo.add(jButton63, new org.netbeans.lib.awtextra.AbsoluteConstraints(923, 133, 110, 27));

        jButton64.setText("jButton35");
        Floortwo.add(jButton64, new org.netbeans.lib.awtextra.AbsoluteConstraints(923, 70, 100, 40));

        jButton65.setText("FE");
        Floortwo.add(jButton65, new org.netbeans.lib.awtextra.AbsoluteConstraints(450, 120, 50, -1));

        jLabel10.setBackground(new java.awt.Color(255, 255, 255));
        jLabel10.setFocusable(false);
        jLabel10.setInheritsPopupMenu(false);
        jLabel10.setOpaque(true);
        Floortwo.add(jLabel10, new org.netbeans.lib.awtextra.AbsoluteConstraints(495, 67, 2, 300));

        jLabel11.setBackground(new java.awt.Color(255, 255, 255));
        jLabel11.setFocusable(false);
        jLabel11.setInheritsPopupMenu(false);
        jLabel11.setOpaque(true);
        Floortwo.add(jLabel11, new org.netbeans.lib.awtextra.AbsoluteConstraints(215, 365, 280, 2));

        jLabel12.setBackground(new java.awt.Color(255, 255, 255));
        jLabel12.setFocusable(false);
        jLabel12.setInheritsPopupMenu(false);
        jLabel12.setOpaque(true);
        Floortwo.add(jLabel12, new org.netbeans.lib.awtextra.AbsoluteConstraints(213, 218, 2, 149));

        jLabel13.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(255, 255, 255), 2));
        Floortwo.add(jLabel13, new org.netbeans.lib.awtextra.AbsoluteConstraints(926, 60, 250, 110));

        contentPanel.add(Floortwo, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 1170, 510));

        Floorthree.setBackground(new java.awt.Color(0, 66, 38));
        Floorthree.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jButton113.setText("jButton34");
        Floorthree.add(jButton113, new org.netbeans.lib.awtextra.AbsoluteConstraints(910, 203, 262, 170));

        jButton111.setBackground(new java.awt.Color(255, 153, 0));
        jButton111.setText("jButton34");
        Floorthree.add(jButton111, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 23, 180, 140));

        jButton123.setText("jButton34");
        Floorthree.add(jButton123, new org.netbeans.lib.awtextra.AbsoluteConstraints(840, 420, 133, 90));

        jButton124.setText("jButton34");
        Floorthree.add(jButton124, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 232, 130, 190));

        jButton120.setText("CR 1");
        Floorthree.add(jButton120, new org.netbeans.lib.awtextra.AbsoluteConstraints(626, 0, 90, 50));

        jButton121.setText("jButton34");
        Floorthree.add(jButton121, new org.netbeans.lib.awtextra.AbsoluteConstraints(608, 333, 108, 40));

        jButton129.setText("jButton34");
        Floorthree.add(jButton129, new org.netbeans.lib.awtextra.AbsoluteConstraints(609, 296, 55, 40));

        jButton130.setText("jButton34");
        Floorthree.add(jButton130, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 160, 130, 75));

        jButton132.setText("CR 2");
        Floorthree.add(jButton132, new org.netbeans.lib.awtextra.AbsoluteConstraints(530, 0, 100, 50));

        jButton133.setText("jButton34");
        Floorthree.add(jButton133, new org.netbeans.lib.awtextra.AbsoluteConstraints(541, 333, 70, 40));

        jButton134.setText("jButton34");
        Floorthree.add(jButton134, new org.netbeans.lib.awtextra.AbsoluteConstraints(126, 270, 40, -1));

        jButton153.setText("jButton34");
        Floorthree.add(jButton153, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 420, 130, 90));

        jButton154.setText("jButton34");
        Floorthree.add(jButton154, new org.netbeans.lib.awtextra.AbsoluteConstraints(190, 420, 133, 90));

        jButton155.setText("jButton34");
        Floorthree.add(jButton155, new org.netbeans.lib.awtextra.AbsoluteConstraints(320, 420, 133, 90));

        jButton156.setText("jButton34");
        Floorthree.add(jButton156, new org.netbeans.lib.awtextra.AbsoluteConstraints(450, 420, 133, 90));

        jButton157.setText("jButton34");
        Floorthree.add(jButton157, new org.netbeans.lib.awtextra.AbsoluteConstraints(580, 420, 133, 90));

        jButton158.setText("jButton34");
        Floorthree.add(jButton158, new org.netbeans.lib.awtextra.AbsoluteConstraints(710, 420, 133, 90));

        jButton115.setText("jButton34");
        Floorthree.add(jButton115, new org.netbeans.lib.awtextra.AbsoluteConstraints(713, 250, 200, 123));

        jButton160.setText("jButton34");
        Floorthree.add(jButton160, new org.netbeans.lib.awtextra.AbsoluteConstraints(460, 400, 40, -1));

        jButton161.setText("jButton34");
        Floorthree.add(jButton161, new org.netbeans.lib.awtextra.AbsoluteConstraints(930, 400, 40, -1));

        jButton162.setText("jButton34");
        Floorthree.add(jButton162, new org.netbeans.lib.awtextra.AbsoluteConstraints(720, 400, 40, -1));

        jButton116.setText("jButton34");
        Floorthree.add(jButton116, new org.netbeans.lib.awtextra.AbsoluteConstraints(971, 370, 200, 140));

        jButton159.setText("jButton34");
        jButton159.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton159ActionPerformed(evt);
            }
        });
        Floorthree.add(jButton159, new org.netbeans.lib.awtextra.AbsoluteConstraints(661, 296, 55, 40));

        jButton118.setText("jButton34");
        jButton118.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton118ActionPerformed(evt);
            }
        });
        Floorthree.add(jButton118, new org.netbeans.lib.awtextra.AbsoluteConstraints(530, 47, 186, 90));

        jButton119.setText("jButton34");
        Floorthree.add(jButton119, new org.netbeans.lib.awtextra.AbsoluteConstraints(530, 209, 186, 90));

        jButton122.setText("jButton34");
        Floorthree.add(jButton122, new org.netbeans.lib.awtextra.AbsoluteConstraints(530, 134, 186, 78));

        contentPanel.add(Floorthree, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 1170, 510));

        Floorfour.setBackground(new java.awt.Color(0, 66, 38));
        Floorfour.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jButton135.setText("jButton34");
        Floorfour.add(jButton135, new org.netbeans.lib.awtextra.AbsoluteConstraints(805, 400, 90, 110));

        jButton136.setText("jButton34");
        Floorfour.add(jButton136, new org.netbeans.lib.awtextra.AbsoluteConstraints(607, 310, 100, 40));

        jButton137.setText("jButton34");
        Floorfour.add(jButton137, new org.netbeans.lib.awtextra.AbsoluteConstraints(517, 75, 190, 201));

        jButton112.setText("jButton34");
        Floorfour.add(jButton112, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 116, 137, 140));

        jButton138.setText("jButton34");
        Floorfour.add(jButton138, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 400, 137, 110));

        jButton139.setText("jButton34");
        Floorfour.add(jButton139, new org.netbeans.lib.awtextra.AbsoluteConstraints(454, 400, 135, 110));

        jButton140.setText("jButton34");
        Floorfour.add(jButton140, new org.netbeans.lib.awtextra.AbsoluteConstraints(134, 180, 40, -1));

        jButton141.setText("jButton34");
        Floorfour.add(jButton141, new org.netbeans.lib.awtextra.AbsoluteConstraints(718, 400, 90, 110));

        jButton142.setText("jButton34");
        Floorfour.add(jButton142, new org.netbeans.lib.awtextra.AbsoluteConstraints(322, 400, 135, 110));

        jButton143.setText("jButton34");
        Floorfour.add(jButton143, new org.netbeans.lib.awtextra.AbsoluteConstraints(466, 0, 140, 50));

        jButton144.setText("jButton34");
        Floorfour.add(jButton144, new org.netbeans.lib.awtextra.AbsoluteConstraints(586, 400, 135, 110));

        jButton145.setText("CR 1");
        Floorfour.add(jButton145, new org.netbeans.lib.awtextra.AbsoluteConstraints(640, 37, 66, 40));

        jButton146.setText("jButton34");
        Floorfour.add(jButton146, new org.netbeans.lib.awtextra.AbsoluteConstraints(892, 400, 90, 110));

        jButton147.setText("jButton34");
        Floorfour.add(jButton147, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 253, 137, 149));

        jButton148.setText("jButton34");
        Floorfour.add(jButton148, new org.netbeans.lib.awtextra.AbsoluteConstraints(540, 273, 167, 40));

        jButton114.setText("jButton34");
        Floorfour.add(jButton114, new org.netbeans.lib.awtextra.AbsoluteConstraints(979, 340, 192, 170));

        jButton149.setText("jButton34");
        Floorfour.add(jButton149, new org.netbeans.lib.awtextra.AbsoluteConstraints(190, 400, 135, 110));

        jButton150.setText("jButton34");
        Floorfour.add(jButton150, new org.netbeans.lib.awtextra.AbsoluteConstraints(540, 310, 70, 40));

        jButton151.setText("CR 2");
        Floorfour.add(jButton151, new org.netbeans.lib.awtextra.AbsoluteConstraints(640, 0, 66, 40));

        jButton152.setText("jButton34");
        Floorfour.add(jButton152, new org.netbeans.lib.awtextra.AbsoluteConstraints(390, 380, 40, -1));

        contentPanel.add(Floorfour, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 1170, 510));

        FloorFifth.setBackground(new java.awt.Color(0, 66, 38));
        FloorFifth.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jButton81.setText("jButton81");
        FloorFifth.add(jButton81, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 96, 130, 160));

        jButton82.setText("jButton81");
        FloorFifth.add(jButton82, new org.netbeans.lib.awtextra.AbsoluteConstraints(723, 410, 260, 100));

        jButton84.setText("jButton81");
        FloorFifth.add(jButton84, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 253, 130, 160));

        jButton85.setText("jButton81");
        jButton85.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton85ActionPerformed(evt);
            }
        });
        FloorFifth.add(jButton85, new org.netbeans.lib.awtextra.AbsoluteConstraints(820, 386, 30, 30));

        jButton86.setText("jButton81");
        FloorFifth.add(jButton86, new org.netbeans.lib.awtextra.AbsoluteConstraints(182, 410, 120, 100));

        jButton87.setText("jButton81");
        jButton87.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton87ActionPerformed(evt);
            }
        });
        FloorFifth.add(jButton87, new org.netbeans.lib.awtextra.AbsoluteConstraints(480, 0, 230, 360));

        jButton88.setText("jButton81");
        FloorFifth.add(jButton88, new org.netbeans.lib.awtextra.AbsoluteConstraints(446, 410, 280, 100));

        jButton89.setText("jButton81");
        FloorFifth.add(jButton89, new org.netbeans.lib.awtextra.AbsoluteConstraints(299, 410, 150, 100));

        jButton90.setText("jButton81");
        FloorFifth.add(jButton90, new org.netbeans.lib.awtextra.AbsoluteConstraints(980, 350, 190, 160));

        jButton91.setText("jButton81");
        FloorFifth.add(jButton91, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 410, 130, 100));

        jButton92.setText("jButton81");
        jButton92.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton92ActionPerformed(evt);
            }
        });
        FloorFifth.add(jButton92, new org.netbeans.lib.awtextra.AbsoluteConstraints(125, 140, 30, 30));

        jButton93.setText("jButton81");
        jButton93.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton93ActionPerformed(evt);
            }
        });
        FloorFifth.add(jButton93, new org.netbeans.lib.awtextra.AbsoluteConstraints(390, 386, 30, 30));

        contentPanel.add(FloorFifth, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 1170, 510));

        MapPanel.add(contentPanel, new org.netbeans.lib.awtextra.AbsoluteConstraints(116, 90, 1170, 510));

        btn1.setFont(new java.awt.Font("Segoe UI Light", 0, 12)); // NOI18N
        btn1.setForeground(new java.awt.Color(255, 255, 255));
        btn1.setText("1ST FLOOR");
        btn1.setContentAreaFilled(false);
        btn1.setFocusPainted(false);
        btn1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn1ActionPerformed(evt);
            }
        });
        MapPanel.add(btn1, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 190, 100, 25));

        btn2.setFont(new java.awt.Font("Segoe UI Light", 0, 12)); // NOI18N
        btn2.setForeground(new java.awt.Color(255, 255, 255));
        btn2.setText("2ND FLOOR");
        btn2.setContentAreaFilled(false);
        btn2.setFocusPainted(false);
        btn2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn2ActionPerformed(evt);
            }
        });
        MapPanel.add(btn2, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 230, 100, 25));

        btn5.setFont(new java.awt.Font("Segoe UI Light", 0, 12)); // NOI18N
        btn5.setForeground(new java.awt.Color(255, 255, 255));
        btn5.setText("5TH FLOOR");
        btn5.setContentAreaFilled(false);
        btn5.setFocusPainted(false);
        btn5.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn5ActionPerformed(evt);
            }
        });
        MapPanel.add(btn5, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 350, 100, 25));

        btn3.setFont(new java.awt.Font("Segoe UI Light", 0, 12)); // NOI18N
        btn3.setForeground(new java.awt.Color(255, 255, 255));
        btn3.setText("3RD FLOOR");
        btn3.setContentAreaFilled(false);
        btn3.setFocusPainted(false);
        btn3.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn3ActionPerformed(evt);
            }
        });
        MapPanel.add(btn3, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 270, 100, 25));

        btn4.setFont(new java.awt.Font("Segoe UI Light", 0, 12)); // NOI18N
        btn4.setForeground(new java.awt.Color(255, 255, 255));
        btn4.setText("4TH FLOOR");
        btn4.setContentAreaFilled(false);
        btn4.setFocusPainted(false);
        btn4.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn4ActionPerformed(evt);
            }
        });
        MapPanel.add(btn4, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 310, 100, 25));

        WelcomeUser1.setFont(new java.awt.Font("Segoe UI Light", 0, 28)); // NOI18N
        WelcomeUser1.setForeground(new java.awt.Color(255, 255, 255));
        WelcomeUser1.setText("PREVIEW OF MAP");
        MapPanel.add(WelcomeUser1, new org.netbeans.lib.awtextra.AbsoluteConstraints(600, 20, 220, 30));

        searchbtn.setIcon(new javax.swing.ImageIcon(getClass().getResource("/icon/search.png"))); // NOI18N
        searchbtn.setBorderPainted(false);
        searchbtn.setContentAreaFilled(false);
        searchbtn.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                searchbtnActionPerformed(evt);
            }
        });
        MapPanel.add(searchbtn, new org.netbeans.lib.awtextra.AbsoluteConstraints(1270, 6, 50, 40));

        searchtext.setFont(new java.awt.Font("Segoe UI", 0, 12)); // NOI18N
        MapPanel.add(searchtext, new org.netbeans.lib.awtextra.AbsoluteConstraints(960, 6, 360, 40));

        jButton2.setText("VIEW ");
        jButton2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton2ActionPerformed(evt);
            }
        });
        MapPanel.add(jButton2, new org.netbeans.lib.awtextra.AbsoluteConstraints(40, 30, 80, -1));

        ContainerPanel.add(MapPanel, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 100, 1370, 630));

        SearchTransaction.setBackground(new java.awt.Color(29, 118, 90));
        SearchTransaction.setMinimumSize(new java.awt.Dimension(1370, 570));
        SearchTransaction.setName(""); // NOI18N
        SearchTransaction.setPreferredSize(new java.awt.Dimension(1370, 570));
        SearchTransaction.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        SearchTransactionLabel.setFont(new java.awt.Font("Segoe UI Light", 0, 28)); // NOI18N
        SearchTransactionLabel.setForeground(new java.awt.Color(255, 255, 255));
        SearchTransactionLabel.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        SearchTransactionLabel.setText("SEARCH TRANSACTION INFORMATION");
        SearchTransaction.add(SearchTransactionLabel, new org.netbeans.lib.awtextra.AbsoluteConstraints(470, 30, 500, 44));

        ContainerPanel.add(SearchTransaction, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 100, 1370, 630));

        WholePanel.add(ContainerPanel, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, -1, 730));

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(WholePanel, javax.swing.GroupLayout.PREFERRED_SIZE, 1370, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(WholePanel, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
        );

        pack();
        setLocationRelativeTo(null);
    }// </editor-fold>//GEN-END:initComponents

    private void jButton1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton1ActionPerformed
     if(MapPanel.isVisible() || SearchTransaction.isVisible()){
         MapPanel.setVisible(false);
        SearchTransaction.setVisible(false);
        MenuPanel.setVisible(true);
      
     }
     else{
        this.dispose(); 
      UI UD = new UI();
      UD.setVisible(true);
     }
    }//GEN-LAST:event_jButton1ActionPerformed

    private void btnMapActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnMapActionPerformed

       MapPanel.setVisible(true);
       MenuPanel.setVisible(false);
        Floorone.setVisible(true);
        Floortwo.setVisible(false);
        Floorthree.setVisible(false);
        Floorfour.setVisible(false);
        FloorFifth.setVisible(false);
    }//GEN-LAST:event_btnMapActionPerformed

    private void btn1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn1ActionPerformed
         
        Floorone.setVisible(true);
        Floortwo.setVisible(false);
        Floorthree.setVisible(false);
        Floorfour.setVisible(false);
        FloorFifth.setVisible(false);
    }//GEN-LAST:event_btn1ActionPerformed

    private void btn2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn2ActionPerformed
         
        Floorone.setVisible(false);
        Floortwo.setVisible(true);
        Floorthree.setVisible(false);
        Floorfour.setVisible(false);
        FloorFifth.setVisible(false);
    }//GEN-LAST:event_btn2ActionPerformed

    private void btn3ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn3ActionPerformed
        Floorone.setVisible(false);
        Floortwo.setVisible(false);
        Floorthree.setVisible(true);
        Floorfour.setVisible(false);
        FloorFifth.setVisible(false);
    }//GEN-LAST:event_btn3ActionPerformed

    private void btn4ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn4ActionPerformed
        Floorone.setVisible(false);
        Floortwo.setVisible(false);
        Floorthree.setVisible(false);
        Floorfour.setVisible(true);
        FloorFifth.setVisible(false);
    }//GEN-LAST:event_btn4ActionPerformed

    private void btn5ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn5ActionPerformed
         Floorone.setVisible(false);
        Floortwo.setVisible(false);
        Floorthree.setVisible(false);
        Floorfour.setVisible(false);
        FloorFifth.setVisible(true);
    }//GEN-LAST:event_btn5ActionPerformed

    private void btnTransactionActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnTransactionActionPerformed
       MenuPanel.setVisible(false);
       SearchTransaction.setVisible(true);
       
    }//GEN-LAST:event_btnTransactionActionPerformed

    private void seniorhighActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_seniorhighActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_seniorhighActionPerformed

    private void skulbox_schoolsuppliesActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_skulbox_schoolsuppliesActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_skulbox_schoolsuppliesActionPerformed

    private void cafeteriaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_cafeteriaActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_cafeteriaActionPerformed

    private void jButton37ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton37ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jButton37ActionPerformed

    private void jButton38ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton38ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jButton38ActionPerformed

    private void jButton39ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton39ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jButton39ActionPerformed

    private void jButton40ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton40ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jButton40ActionPerformed

    private void jButton41ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton41ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jButton41ActionPerformed

    private void jButton42ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton42ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jButton42ActionPerformed

    private void jButton43ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton43ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jButton43ActionPerformed

    private void jButton87ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton87ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jButton87ActionPerformed

    private void jButton85ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton85ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jButton85ActionPerformed

    private void jButton92ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton92ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jButton92ActionPerformed

    private void jButton93ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton93ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jButton93ActionPerformed

    private void guidanceActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_guidanceActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_guidanceActionPerformed

    private void guidance_roomActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_guidance_roomActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_guidance_roomActionPerformed

    private void custodian_stockroomActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_custodian_stockroomActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_custodian_stockroomActionPerformed

    private void jButton51ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton51ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jButton51ActionPerformed

    private void jButton159ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton159ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jButton159ActionPerformed

    private void jButton118ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton118ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jButton118ActionPerformed

    private void searchbtnActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_searchbtnActionPerformed
            
        List<AbstractButton> listRadioButton = Collections.list(buttonGroup1.getElements());      
        String search = searchtext.getText().trim();
        
        
         for (AbstractButton button : listRadioButton) {

                        if (((JButton) button).getBackground()==Color.YELLOW) {

                            System.out.println("Search element : " + ((JButton) button).getText());
                            ((JButton) button).setBackground(Color.WHITE);
                        }
                        
                    }   
        
        if(!search.isEmpty()){
            
              try {
            Class.forName(classfor);
            con = DriverManager.getConnection(connect,username,password);
            
           
              //  String ss = "SELECT * FROM room WHERE nickname= '"+nc+"';";
                String ss = "SELECT * FROM room WHERE roomname = '" + search + "' OR abbreviation = '" + search + "';";
                st = con.createStatement();
                ResultSet rs = st.executeQuery(ss);

                if (rs.first()) {
                    
                    
                    String room = rs.getString("uniqure_room").trim();
                    System.out.print(room);
                    for (AbstractButton button : listRadioButton) {

                        if (((JButton) button).getName().matches(room)) {

                            System.out.println("Search element : " + ((JButton) button).getText());
                            ((JButton) button).setBackground(Color.yellow);
                        }
                    }   
                } else {
                    System.out.println("NO DATA");
                         searchteacher();

                }
            } catch (ClassNotFoundException | SQLException ex) {
                Logger.getLogger(UserDashboard.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
            
 
        else{
            System.out.println("NO ROOM WITH THIS NAME");
}
      
    }//GEN-LAST:event_searchbtnActionPerformed

    private void jButton2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton2ActionPerformed
       
        popup_details  pd =  new popup_details();
        pd.setVisible(true);
     
        
    }//GEN-LAST:event_jButton2ActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {    UIManager.setLookAndFeel(new FlatIntelliJLaf ());
       }
       catch (Exception e) {
           e.printStackTrace ();
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new UserDashboard().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JPanel ContainerPanel;
    private javax.swing.JPanel FloorFifth;
    private javax.swing.JPanel Floorfour;
    private javax.swing.JPanel Floorone;
    private javax.swing.JPanel Floorthree;
    private javax.swing.JPanel Floortwo;
    private javax.swing.JPanel MapPanel;
    private javax.swing.JPanel MenuPanel;
    private javax.swing.JLabel SearchRoomLabel;
    private javax.swing.JPanel SearchTransaction;
    private javax.swing.JLabel SearchTransactionLabel;
    private javax.swing.JPanel TopPanel;
    private javax.swing.JLabel TransactionLabel;
    private javax.swing.JLabel WelcomeUser;
    private javax.swing.JLabel WelcomeUser1;
    private javax.swing.JPanel WholePanel;
    private javax.swing.JButton accounting_office;
    private javax.swing.JButton afa_office;
    private javax.swing.JButton btn1;
    private javax.swing.JButton btn2;
    private javax.swing.JButton btn3;
    private javax.swing.JButton btn4;
    private javax.swing.JButton btn5;
    private javax.swing.JButton btnMap;
    private javax.swing.JButton btnTransaction;
    private javax.swing.ButtonGroup buttonGroup1;
    private javax.swing.JButton cafeteria;
    private javax.swing.JButton canteen;
    private javax.swing.JButton cashier_office;
    private javax.swing.JButton chemlabroom;
    private javax.swing.JButton clinic;
    private javax.swing.JPanel contentPanel;
    private javax.swing.JButton cr1_male;
    private javax.swing.JButton cr2_female;
    private javax.swing.JButton custodian_stockroom;
    private javax.swing.JButton entrancetosh;
    private javax.swing.JLabel fe1;
    private javax.swing.JLabel fe2;
    private javax.swing.JButton guidance;
    private javax.swing.JButton guidance_room;
    private javax.swing.JButton hslibrary;
    private javax.swing.JButton jButton1;
    private javax.swing.JButton jButton111;
    private javax.swing.JButton jButton112;
    private javax.swing.JButton jButton113;
    private javax.swing.JButton jButton114;
    private javax.swing.JButton jButton115;
    private javax.swing.JButton jButton116;
    private javax.swing.JButton jButton118;
    private javax.swing.JButton jButton119;
    private javax.swing.JButton jButton120;
    private javax.swing.JButton jButton121;
    private javax.swing.JButton jButton122;
    private javax.swing.JButton jButton123;
    private javax.swing.JButton jButton124;
    private javax.swing.JButton jButton129;
    private javax.swing.JButton jButton130;
    private javax.swing.JButton jButton132;
    private javax.swing.JButton jButton133;
    private javax.swing.JButton jButton134;
    private javax.swing.JButton jButton135;
    private javax.swing.JButton jButton136;
    private javax.swing.JButton jButton137;
    private javax.swing.JButton jButton138;
    private javax.swing.JButton jButton139;
    private javax.swing.JButton jButton140;
    private javax.swing.JButton jButton141;
    private javax.swing.JButton jButton142;
    private javax.swing.JButton jButton143;
    private javax.swing.JButton jButton144;
    private javax.swing.JButton jButton145;
    private javax.swing.JButton jButton146;
    private javax.swing.JButton jButton147;
    private javax.swing.JButton jButton148;
    private javax.swing.JButton jButton149;
    private javax.swing.JButton jButton150;
    private javax.swing.JButton jButton151;
    private javax.swing.JButton jButton152;
    private javax.swing.JButton jButton153;
    private javax.swing.JButton jButton154;
    private javax.swing.JButton jButton155;
    private javax.swing.JButton jButton156;
    private javax.swing.JButton jButton157;
    private javax.swing.JButton jButton158;
    private javax.swing.JButton jButton159;
    private javax.swing.JButton jButton160;
    private javax.swing.JButton jButton161;
    private javax.swing.JButton jButton162;
    private javax.swing.JButton jButton2;
    private javax.swing.JButton jButton36;
    private javax.swing.JButton jButton37;
    private javax.swing.JButton jButton38;
    private javax.swing.JButton jButton39;
    private javax.swing.JButton jButton40;
    private javax.swing.JButton jButton41;
    private javax.swing.JButton jButton42;
    private javax.swing.JButton jButton43;
    private javax.swing.JButton jButton45;
    private javax.swing.JButton jButton46;
    private javax.swing.JButton jButton49;
    private javax.swing.JButton jButton50;
    private javax.swing.JButton jButton51;
    private javax.swing.JButton jButton52;
    private javax.swing.JButton jButton53;
    private javax.swing.JButton jButton54;
    private javax.swing.JButton jButton55;
    private javax.swing.JButton jButton56;
    private javax.swing.JButton jButton57;
    private javax.swing.JButton jButton58;
    private javax.swing.JButton jButton59;
    private javax.swing.JButton jButton60;
    private javax.swing.JButton jButton61;
    private javax.swing.JButton jButton63;
    private javax.swing.JButton jButton64;
    private javax.swing.JButton jButton65;
    private javax.swing.JButton jButton81;
    private javax.swing.JButton jButton82;
    private javax.swing.JButton jButton84;
    private javax.swing.JButton jButton85;
    private javax.swing.JButton jButton86;
    private javax.swing.JButton jButton87;
    private javax.swing.JButton jButton88;
    private javax.swing.JButton jButton89;
    private javax.swing.JButton jButton90;
    private javax.swing.JButton jButton91;
    private javax.swing.JButton jButton92;
    private javax.swing.JButton jButton93;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel10;
    private javax.swing.JLabel jLabel11;
    private javax.swing.JLabel jLabel12;
    private javax.swing.JLabel jLabel13;
    private javax.swing.JButton library_extension;
    private javax.swing.JLabel line1;
    private javax.swing.JLabel line2;
    private javax.swing.JLabel line3;
    private javax.swing.JLabel line4;
    private javax.swing.JLabel line5;
    private javax.swing.JButton maingate;
    private javax.swing.JButton president_office;
    private javax.swing.JLabel quadrangle;
    private javax.swing.JButton registrar_office;
    private javax.swing.JButton registrar_stockroom;
    private javax.swing.JButton rented_space;
    private javax.swing.JButton searchbtn;
    private javax.swing.JTextField searchtext;
    private javax.swing.JButton second_floor;
    private javax.swing.JButton seniorhigh;
    private javax.swing.JButton skulbox_canteen;
    private javax.swing.JButton skulbox_schoolsupplies;
    private javax.swing.JButton stage;
    private javax.swing.JButton stair_outside;
    private javax.swing.JButton stairs;
    private javax.swing.JButton stairs2;
    private javax.swing.JButton tato;
    private javax.swing.JButton tle;
    // End of variables declaration//GEN-END:variables
public void startup(){
    MapPanel.setVisible(false);
   
    SearchTransaction.setVisible(false);
    setbuttonnames();
}


 public void alert(String msg) {
        JOptionPane.showMessageDialog(rootPane, msg);
    }

public  void searchteacher(){
      List<AbstractButton> listRadioButton = Collections.list(buttonGroup1.getElements());      
        String search = searchtext.getText().trim();
        
        
         for (AbstractButton button : listRadioButton) {

                        if (((JButton) button).getBackground()==Color.YELLOW) {

                            System.out.println("Search element : " + ((JButton) button).getText());
                            ((JButton) button).setBackground(Color.WHITE);
                        }
                        
                    }   
        
        if(!search.isEmpty()){
            
              try {
            Class.forName(classfor);
            con = DriverManager.getConnection(connect,username,password);
            
              //  String ss = "SELECT * FROM room WHERE nickname= '"+nc+"';";
                String ss = "SELECT CONCAT(staff.stafffn,' ',staff.staffln) AS 'staffname', room.roomname,room.uniqure_room FROM staff INNER JOIN room ON staff.roomid = room.roomid WHERE CONCAT(staff.stafffn,' ',staff.staffln) LIKE '"+search+"%';";
                st = con.createStatement();
                ResultSet rs = st.executeQuery(ss);

                if (rs.first()) {
                    
                    
                    String room = rs.getString("uniqure_room").trim();
                    System.out.print(room);
                    for (AbstractButton button : listRadioButton) {

                        if (((JButton) button).getName().matches(room)) {

                            System.out.println("Search element : " + ((JButton) button).getText());
                            ((JButton) button).setBackground(Color.yellow);
                        }
                    }   
                } else {
                    System.out.println("NO DATA");

                }
            } catch (ClassNotFoundException | SQLException ex) {
                Logger.getLogger(UserDashboard.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
            
 
        else{
            System.out.println("NO ROOM WITH THIS NAME");
}
}
 
 public void setbuttonnames(){
     president_office.setName("ROOM 1");
     accounting_office.setName("ROOM 2");
     registrar_office.setName("ROOM 3");
     cashier_office.setName("ROOM 4");
     afa_office.setName("ROOM 5");
     tle.setName("ROOM 6");
     skulbox_canteen.setName("ROOM 7");
     stage.setName("ROOM 8");
     cr1_male.setName("ROOM 9");
     cr2_female.setName("ROOM 10");
     skulbox_schoolsupplies.setName("ROOM 11");
     cafeteria.setName("ROOM 12");
     canteen.setName("ROOM 13");
     hslibrary.setName("ROOM 13");
     library_extension.setName("ROOM 14");
     registrar_stockroom.setName("ROOM 15");
     custodian_stockroom.setName("ROOM 16");
     guidance.setName("ROOM 17");
     guidance_room.setName("ROOM 18");
     clinic.setName("ROOM 19");
     chemlabroom.setName("ROOM 20");
     tato.setName("ROOM 21");
     rented_space.setName("ROOM 22");
     
 }
 
 public void fetchall(){
   fetchpresroom();
   fetchaccroom();
   fetchregistraroffice();
   fetchcashieroffice();
 }
 
 public void fetchpresroom(){
        try {
            Class.forName(classfor);
            con = DriverManager.getConnection(connect,username,password);
            
             String name = president_office.getName();
              //  String ss = "SELECT * FROM room WHERE nickname= '"+nc+"';";
            String ss = "SELECT * FROM room WHERE uniqure_room = '"+name+"';";
            st = con.createStatement();
            ResultSet rs = st.executeQuery(ss);
             
            if (rs.first()) {
                System.out.println(rs.getString("roomname"));
                president_office.setText(rs.getString("roomname"));
            }
            else{
                                System.out.println("NO DATA");

            }
        }catch (ClassNotFoundException | SQLException ex) {
            Logger.getLogger(UserDashboard.class.getName()).log(Level.SEVERE, null, ex);
        }
     
     
     
     
 }
 
 
  public void fetchaccroom(){
        try {
            Class.forName(classfor);
            con = DriverManager.getConnection(connect,username,password);
            
             String name = accounting_office.getName();
              //  String ss = "SELECT * FROM room WHERE nickname= '"+nc+"';";
            String ss = "SELECT * FROM room WHERE uniqure_room = '"+name+"';";
            st = con.createStatement();
            ResultSet rs = st.executeQuery(ss);
             
            if (rs.first()) {
                System.out.println(rs.getString("roomname"));
                accounting_office.setText(rs.getString("roomname"));
            }
            else{
                                System.out.println("NO DATA");

            }
        }catch (ClassNotFoundException | SQLException ex) {
            Logger.getLogger(UserDashboard.class.getName()).log(Level.SEVERE, null, ex);
        }
    
  }
  
 
  
   public void fetchregistraroffice(){
        try {
            Class.forName(classfor);
            con = DriverManager.getConnection(connect,username,password);
            
             String name = registrar_office.getName();
              //  String ss = "SELECT * FROM room WHERE nickname= '"+nc+"';";
            String ss = "SELECT * FROM room WHERE uniqure_room = '"+name+"';";
            st = con.createStatement();
            ResultSet rs = st.executeQuery(ss);
             
            if (rs.first()) {
                System.out.println(rs.getString("roomname"));
                registrar_office.setText(rs.getString("roomname"));
            }
            else{
                                System.out.println("NO DATA");

            }
        }catch (ClassNotFoundException | SQLException ex) {
            Logger.getLogger(UserDashboard.class.getName()).log(Level.SEVERE, null, ex);
        }
   }
 
   
  public void fetchcashieroffice(){
        try {
            Class.forName(classfor);
            con = DriverManager.getConnection(connect,username,password);
            
             String name = cashier_office.getName();
              //  String ss = "SELECT * FROM room WHERE nickname= '"+nc+"';";
            String ss = "SELECT * FROM room WHERE uniqure_room = '"+name+"';";
            st = con.createStatement();
            ResultSet rs = st.executeQuery(ss);
             
            if (rs.first()) {
                System.out.println(rs.getString("roomname"));
                cashier_office.setText(rs.getString("roomname"));
            }
            else{
                                System.out.println("NO DATA");

            }
        }catch (ClassNotFoundException | SQLException ex) {
            Logger.getLogger(UserDashboard.class.getName()).log(Level.SEVERE, null, ex);
        }
   } 
 
   public void fetchafaoffice(){
        try {
            Class.forName(classfor);
            con = DriverManager.getConnection(connect,username,password);
            
             String name = afa_office.getName();
              //  String ss = "SELECT * FROM room WHERE nickname= '"+nc+"';";
            String ss = "SELECT * FROM room WHERE uniqure_room = '"+name+"';";
            st = con.createStatement();
            ResultSet rs = st.executeQuery(ss);
             
            if (rs.first()) {
                System.out.println(rs.getString("roomname"));
                afa_office.setText(rs.getString("roomname"));
            }
            else{
                                System.out.println("NO DATA");

            }
        }catch (ClassNotFoundException | SQLException ex) {
            Logger.getLogger(UserDashboard.class.getName()).log(Level.SEVERE, null, ex);
        }
   } 
  
  
  
}
